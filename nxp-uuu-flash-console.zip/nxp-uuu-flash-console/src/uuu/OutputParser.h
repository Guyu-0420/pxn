#pragma once

#include "task/TaskRecord.h"

struct LineEffect {
    bool matched = false;
    TaskStage stage = TaskStage::WaitDevice;
    bool hasPercent = false;
    int percent = 0;
    bool successEvidence = false;
    bool failureEvidence = false;
};

class OutputParser {
public:
    static QVector<DeviceInfo> parseLsusb(const QString& text);
    static LineEffect parseLine(const QString& line);
    static int stageStartPercent(TaskStage stage);
};
