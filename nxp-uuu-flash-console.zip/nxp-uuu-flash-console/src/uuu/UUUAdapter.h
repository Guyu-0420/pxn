#pragma once

#include "task/TaskRecord.h"

#include <QObject>
#include <QProcess>
#include <QString>

class UUUAdapter : public QObject {
    Q_OBJECT
public:
    explicit UUUAdapter(QObject* parent = nullptr);

    void setExecutable(const QString& path);
    QString executable() const;
    bool executableFound() const;

    void listDevices();
    void start(const DeviceInfo& device, const FlashRequest& request);
    void cancel();
    bool isRunning() const;

signals:
    void devicesReady(QVector<DeviceInfo> devices, QString error);
    void output(QString line);
    void stageChanged(TaskStage stage, int percent);
    void finished(int exitCode, bool success);

private:
    enum class Mode { Idle, List, Flash };

    QString resolveExecutable() const;
    void drain();
    void handleLine(const QString& line);
    void onFinished(int exitCode, QProcess::ExitStatus status);
    void onError(QProcess::ProcessError error);

    QString m_override;
    QProcess* m_proc = nullptr;
    Mode m_mode = Mode::Idle;
    QString m_buffer;
    QString m_listText;
    bool m_cancel = false;
    bool m_successEvidence = false;
    bool m_failureEvidence = false;
    int m_runId = 0;
};
