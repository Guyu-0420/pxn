#include "uuu/UUUAdapter.h"

#include "uuu/OutputParser.h"

#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QProcessEnvironment>
#include <QStandardPaths>
#include <QTimer>

#if defined(Q_OS_UNIX)
#include <signal.h>
#include <unistd.h>
#endif

#if defined(Q_OS_WIN)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace {

QString toolFileName()
{
#if defined(Q_OS_WIN)
    return QStringLiteral("uuu.exe");
#else
    return QStringLiteral("uuu");
#endif
}

QString missingToolText()
{
#if defined(Q_OS_WIN)
    return QStringLiteral("未找到 uuu.exe");
#else
    return QStringLiteral("未找到 uuu");
#endif
}

} // namespace

UUUAdapter::UUUAdapter(QObject* parent)
    : QObject(parent)
    , m_proc(new QProcess(this))
{
    m_proc->setProcessChannelMode(QProcess::MergedChannels);
#if defined(Q_OS_WIN)
    m_proc->setCreateProcessArgumentsModifier([](QProcess::CreateProcessArguments* args) {
        args->flags |= CREATE_NEW_PROCESS_GROUP;
    });
#endif
    connect(m_proc, &QProcess::readyRead, this, &UUUAdapter::drain);
    connect(m_proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &UUUAdapter::onFinished);
    connect(m_proc, &QProcess::errorOccurred, this, &UUUAdapter::onError);
}

void UUUAdapter::setExecutable(const QString& path)
{
    m_override = path;
}

QString UUUAdapter::executable() const
{
    return resolveExecutable();
}

bool UUUAdapter::executableFound() const
{
    return !resolveExecutable().isEmpty();
}

QString UUUAdapter::resolveExecutable() const
{
    if (!m_override.isEmpty())
        return QFileInfo::exists(m_override) ? QFileInfo(m_override).absoluteFilePath() : QString();

    const QString name = toolFileName();
    const QString local = QDir(QCoreApplication::applicationDirPath()).filePath(name);
    if (QFileInfo::exists(local))
        return local;

    const QString env = qEnvironmentVariable("UUU_PATH");
    if (!env.isEmpty() && QFileInfo::exists(env))
        return QFileInfo(env).absoluteFilePath();

#if !defined(Q_OS_WIN)
    if (QFileInfo::exists(QStringLiteral("/usr/bin/uuu")))
        return QStringLiteral("/usr/bin/uuu");
#endif
    return QStandardPaths::findExecutable(name);
}

void UUUAdapter::listDevices()
{
    if (isRunning())
        return;
    const QString exe = resolveExecutable();
    if (exe.isEmpty()) {
        emit devicesReady({}, missingToolText());
        return;
    }
    ++m_runId;
    m_mode = Mode::List;
    m_buffer.clear();
    m_listText.clear();
    m_cancel = false;
    m_proc->setProgram(exe);
    m_proc->setArguments({QStringLiteral("-lsusb")});
    m_proc->setWorkingDirectory(QDir::tempPath());
    m_proc->start();
}

void UUUAdapter::start(const DeviceInfo& device, const FlashRequest& request)
{
    Q_UNUSED(device);
    if (isRunning())
        return;
    const QString exe = resolveExecutable();
    if (exe.isEmpty()) {
        emit output(missingToolText());
        emit finished(-1, false);
        return;
    }
    ++m_runId;
    m_mode = Mode::Flash;
    m_buffer.clear();
    m_cancel = false;
    m_successEvidence = false;
    m_failureEvidence = false;
    m_proc->setProgram(exe);
    m_proc->setArguments({
        QStringLiteral("-b"),
        QStringLiteral("sd_all"),
        request.bootloaderPath,
        request.linuxImagePath
    });
    m_proc->setWorkingDirectory(QFileInfo(request.linuxImagePath).absolutePath());
    m_proc->start();
}

void UUUAdapter::cancel()
{
    if (!isRunning() || m_mode != Mode::Flash)
        return;
    m_cancel = true;
    const int runId = m_runId;
    const qint64 pid = m_proc->processId();
#if defined(Q_OS_WIN)
    bool sent = false;
    if (pid > 0 && AttachConsole(static_cast<DWORD>(pid))) {
        SetConsoleCtrlHandler(nullptr, TRUE);
        sent = GenerateConsoleCtrlEvent(CTRL_BREAK_EVENT, static_cast<DWORD>(pid));
        FreeConsole();
    }
    if (!sent)
        m_proc->terminate();
#elif defined(Q_OS_UNIX)
    if (pid > 0)
        ::kill(static_cast<pid_t>(pid), SIGINT);
    else
        m_proc->terminate();
#else
    m_proc->terminate();
#endif
    QTimer::singleShot(2000, this, [this, runId] {
        if (runId == m_runId && isRunning())
            m_proc->kill();
    });
}

bool UUUAdapter::isRunning() const
{
    return m_proc->state() != QProcess::NotRunning;
}

void UUUAdapter::drain()
{
    m_buffer += QString::fromLocal8Bit(m_proc->readAll());
    m_buffer.replace(QStringLiteral("\r\n"), QStringLiteral("\n"));
    m_buffer.replace(QLatin1Char('\r'), QLatin1Char('\n'));
    int pos = 0;
    while ((pos = m_buffer.indexOf(QLatin1Char('\n'))) >= 0) {
        const QString line = m_buffer.left(pos).trimmed();
        m_buffer.remove(0, pos + 1);
        if (!line.isEmpty())
            handleLine(line);
    }
}

void UUUAdapter::handleLine(const QString& line)
{
    if (m_mode == Mode::List) {
        m_listText += line;
        m_listText += QLatin1Char('\n');
        return;
    }
    if (m_mode != Mode::Flash)
        return;

    emit output(line);
    const LineEffect effect = OutputParser::parseLine(line);
    if (effect.failureEvidence)
        m_failureEvidence = true;
    if (effect.successEvidence)
        m_successEvidence = true;
    if (!effect.matched)
        return;
    const int percent = effect.hasPercent ? effect.percent : OutputParser::stageStartPercent(effect.stage);
    emit stageChanged(effect.stage, percent);
}

void UUUAdapter::onFinished(int exitCode, QProcess::ExitStatus status)
{
    drain();
    if (!m_buffer.trimmed().isEmpty()) {
        handleLine(m_buffer.trimmed());
        m_buffer.clear();
    }

    const Mode mode = m_mode;
    const bool cancelled = m_cancel;
    const bool successEvidence = m_successEvidence;
    const bool failureEvidence = m_failureEvidence;
    m_mode = Mode::Idle;
    m_cancel = false;

    if (mode == Mode::List) {
        const QVector<DeviceInfo> devices = OutputParser::parseLsusb(m_listText);
        m_listText.clear();
        QString error;
        if ((status != QProcess::NormalExit || exitCode != 0) && devices.isEmpty())
            error = QStringLiteral("检测失败");
        emit devicesReady(devices, error);
        return;
    }
    if (mode == Mode::Flash) {
        const bool ok = !cancelled && status == QProcess::NormalExit && exitCode == 0
            && successEvidence && !failureEvidence;
        emit finished(exitCode, ok);
    }
}

void UUUAdapter::onError(QProcess::ProcessError error)
{
    if (error != QProcess::FailedToStart || m_mode == Mode::Idle)
        return;
    const Mode mode = m_mode;
    m_mode = Mode::Idle;
    if (mode == Mode::List) {
        m_listText.clear();
        emit devicesReady({}, QStringLiteral("无法启动 uuu"));
        return;
    }
    emit output(QStringLiteral("无法启动 uuu"));
    emit finished(-1, false);
}
