#include "uuu/OutputParser.h"

#include <QRegularExpression>

namespace {

QStringList columns(const QString& line)
{
    return line.trimmed().split(QRegularExpression(QStringLiteral("\\s+")), Qt::SkipEmptyParts);
}

int columnIndex(const QStringList& header, const QString& name, int fallback)
{
    const int index = header.indexOf(name);
    return index >= 0 ? index : fallback;
}

} // namespace

QVector<DeviceInfo> OutputParser::parseLsusb(const QString& text)
{
    int pathCol = 0;
    int chipCol = 1;
    int proCol = 2;
    int vidCol = 3;
    int pidCol = 4;
    bool headerFound = false;
    QVector<DeviceInfo> devices;
    const QRegularExpression pathRe(QStringLiteral("^\\d+:\\d+$"));
    const QStringList lines = text.split(QRegularExpression(QStringLiteral("[\\r\\n]+")), Qt::SkipEmptyParts);

    for (const QString& rawLine : lines) {
        const QString line = rawLine.trimmed();
        if (line.isEmpty() || line.startsWith(QLatin1Char('=')))
            continue;
        const QStringList cols = columns(line);
        if (cols.isEmpty())
            continue;

        if (!headerFound) {
            QStringList lower;
            lower.reserve(cols.size());
            for (const QString& col : cols)
                lower << col.toLower();
            if (lower.contains(QStringLiteral("path")) && lower.contains(QStringLiteral("chip"))
                && lower.contains(QStringLiteral("pro"))) {
                pathCol = columnIndex(lower, QStringLiteral("path"), 0);
                chipCol = columnIndex(lower, QStringLiteral("chip"), 1);
                proCol = columnIndex(lower, QStringLiteral("pro"), 2);
                vidCol = columnIndex(lower, QStringLiteral("vid"), 3);
                pidCol = columnIndex(lower, QStringLiteral("pid"), 4);
                headerFound = true;
                continue;
            }
        }

        const int need = qMax(pathCol, qMax(chipCol, qMax(proCol, qMax(vidCol, pidCol))));
        if (cols.size() <= need || !pathRe.match(cols.at(pathCol)).hasMatch())
            continue;
        if (!cols.at(chipCol).at(0).isLetter())
            continue;

        DeviceInfo device;
        device.usbPath = cols.at(pathCol);
        device.chip = cols.at(chipCol);
        device.protocol = cols.at(proCol);
        device.vid = cols.at(vidCol);
        device.pid = cols.at(pidCol);
        device.raw = line;
        devices.push_back(device);
    }
    return devices;
}

LineEffect OutputParser::parseLine(const QString& line)
{
    LineEffect effect;
    const QString text = line.trimmed();
    if (text.isEmpty())
        return effect;

    static const QRegularExpression summary(
        QStringLiteral("Success\\s+(\\d+)\\s+Failure\\s+(\\d+)"),
        QRegularExpression::CaseInsensitiveOption);
    const QRegularExpressionMatch sum = summary.match(text);
    if (sum.hasMatch()) {
        const int successCount = sum.captured(1).toInt();
        const int failureCount = sum.captured(2).toInt();
        if (failureCount == 0 && successCount >= 1) {
            effect.matched = true;
            effect.successEvidence = true;
            effect.stage = TaskStage::Finish;
            effect.hasPercent = true;
            effect.percent = 100;
        } else {
            effect.failureEvidence = true;
        }
        return effect;
    }

    static const QRegularExpression percentRe(QStringLiteral("(\\d{1,3})\\s*%"));
    const QRegularExpressionMatch percent = percentRe.match(text);
    if (percent.hasMatch()) {
        effect.hasPercent = true;
        effect.percent = qBound(0, percent.captured(1).toInt(), 100);
    }

    const bool fb = text.contains(QStringLiteral("FB:"), Qt::CaseInsensitive);
    const bool sdp = text.contains(QStringLiteral("SDPS:"), Qt::CaseInsensitive)
        || text.contains(QStringLiteral("SDPV:"), Qt::CaseInsensitive)
        || text.contains(QRegularExpression(QStringLiteral("\\bSDP:"), QRegularExpression::CaseInsensitiveOption));

    if (fb && text.contains(QRegularExpression(QStringLiteral("\\bdone\\b"), QRegularExpression::CaseInsensitiveOption))) {
        effect.matched = true;
        effect.successEvidence = true;
        effect.stage = TaskStage::Finish;
        effect.hasPercent = true;
        effect.percent = 100;
        return effect;
    }
    if (fb && text.contains(QStringLiteral("flash"), Qt::CaseInsensitive)) {
        effect.matched = true;
        effect.stage = TaskStage::FlashImage;
        return effect;
    }
    if (sdp) {
        effect.matched = true;
        effect.stage = TaskStage::LoadBootloader;
        return effect;
    }
    if (!fb && text.contains(QStringLiteral("wait"), Qt::CaseInsensitive)) {
        effect.matched = true;
        effect.stage = TaskStage::WaitFastboot;
        return effect;
    }
    return effect;
}

int OutputParser::stageStartPercent(TaskStage stage)
{
    switch (stage) {
    case TaskStage::LoadBootloader: return 0;
    case TaskStage::WaitFastboot: return 30;
    case TaskStage::FlashImage: return 45;
    case TaskStage::Finish: return 100;
    case TaskStage::WaitDevice: return 0;
    }
    return 0;
}
