#pragma once

#include "task/TaskRecord.h"

#include <QDialog>

class TaskHistoryDialog : public QDialog {
    Q_OBJECT
public:
    explicit TaskHistoryDialog(const QVector<TaskRecord>& records, QWidget* parent = nullptr);
};
