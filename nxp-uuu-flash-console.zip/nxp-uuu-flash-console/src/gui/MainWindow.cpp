#include "gui/MainWindow.h"

#include "gui/TaskHistoryDialog.h"

#include <QCheckBox>
#include <QDateTime>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QFrame>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QMenuBar>
#include <QMessageBox>
#include <QSettings>
#include <QSignalBlocker>
#include <QVBoxLayout>

namespace {

QString durationText(const QDateTime& start, const QDateTime& end)
{
    qint64 seconds = start.secsTo(end);
    if (seconds < 0)
        seconds = 0;
    return QStringLiteral("%1分%2秒").arg(seconds / 60).arg(seconds % 60);
}

QWidget* fieldPair(const QString& name, QLabel** value)
{
    auto box = new QWidget;
    auto layout = new QHBoxLayout(box);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(6);
    auto title = new QLabel(name);
    title->setStyleSheet(QStringLiteral("color:#667085;"));
    *value = new QLabel(QStringLiteral("—"));
    (*value)->setStyleSheet(QStringLiteral("font-weight:600;"));
    layout->addWidget(title);
    layout->addWidget(*value);
    return box;
}

void paintStep(QLabel* label, const QString& title, const QString& mode)
{
    QString text = title;
    QString style = QStringLiteral("color:#98a2b3;background:#f2f4f7;border-radius:4px;padding:6px 8px;");
    if (mode == QLatin1String("done")) {
        text = QStringLiteral("✓ ") + title;
        style = QStringLiteral("color:#067647;background:#ecfdf3;border-radius:4px;padding:6px 8px;");
    } else if (mode == QLatin1String("current")) {
        style = QStringLiteral("color:#0f6b4c;background:#e8f6f0;border-radius:4px;padding:6px 8px;font-weight:600;");
    } else if (mode == QLatin1String("failed")) {
        text = QStringLiteral("× ") + title;
        style = QStringLiteral("color:#b42318;background:#fef3f2;border-radius:4px;padding:6px 8px;font-weight:600;");
    }
    label->setText(text);
    label->setStyleSheet(style);
}

} // namespace

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
{
    setWindowTitle(QStringLiteral("NXP UUU Flash Console"));
    resize(1100, 760);
    buildUi();
    loadSettings();

    connect(&m_tasks, &TaskManager::taskChanged, this, &MainWindow::onTask);
    connect(&m_tasks, &TaskManager::logLine, this, &MainWindow::onLog);
    connect(&m_tasks, &TaskManager::devicesChanged, this, [this] { updateUi(); });
    connect(&m_tasks, &TaskManager::activityChanged, this, [this] { updateUi(); });
    connect(m_detectBtn, &QPushButton::clicked, this, &MainWindow::detect);
    connect(m_startBtn, &QPushButton::clicked, this, &MainWindow::startFlash);
    connect(m_cancelBtn, &QPushButton::clicked, this, [this] { m_tasks.cancel(m_task.id); });
    connect(m_bootBrowse, &QPushButton::clicked, this, &MainWindow::chooseBootloader);
    connect(m_linuxBrowse, &QPushButton::clicked, this, &MainWindow::chooseLinux);
    connect(m_bootEdit, &QLineEdit::textChanged, this, [this] { saveFiles(); updateUi(); });
    connect(m_linuxEdit, &QLineEdit::textChanged, this, [this] { saveFiles(); updateUi(); });
    connect(m_bootCheck, &QCheckBox::toggled, this, [this](bool checked) {
        if (!m_task.id.isEmpty())
            m_tasks.setBootChecked(m_task.id, checked);
    });

    updateStages(TaskStage::WaitDevice, TaskState::Idle);
    updateResult(m_task);
    updateUi();
    m_tasks.detect();
}

void MainWindow::buildUi()
{
    auto menu = menuBar()->addMenu(QStringLiteral("菜单"));
    menu->addAction(QStringLiteral("任务记录"), this, &MainWindow::openHistory);
    menu->addAction(QStringLiteral("UUU 路径"), this, &MainWindow::chooseUuu);
    menu->addAction(QStringLiteral("关于"), this, &MainWindow::about);

    auto central = new QWidget(this);
    auto root = new QVBoxLayout(central);
    root->setContentsMargins(16, 12, 16, 16);
    root->setSpacing(10);
    setCentralWidget(central);
    setStyleSheet(QStringLiteral(
        "QMainWindow, QWidget { background:#f3f4f6; color:#1f2933; font-size:13px; }"
        "QGroupBox { background:#ffffff; border:1px solid #d9dee7; border-radius:8px; margin-top:14px; padding:12px; font-weight:600; }"
        "QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 4px; }"
        "QLineEdit, QPlainTextEdit { background:#ffffff; border:1px solid #cfd6e0; border-radius:4px; padding:4px 6px; font-weight:400; }"
        "QPushButton { background:#ffffff; border:1px solid #c5ced9; border-radius:4px; padding:6px 12px; font-weight:400; }"
        "QPushButton:disabled { color:#98a2b3; background:#f2f4f7; }"
        "QPushButton#startButton { background:#0f6b4c; color:#ffffff; border:none; font-weight:600; }"
        "QPushButton#startButton:disabled { background:#d8e5df; color:#6b7c75; }"
        "QProgressBar { border:1px solid #d9dee7; border-radius:4px; background:#eef1f5; text-align:center; height:18px; }"
        "QProgressBar::chunk { background:#0f6b4c; }"
        "QCheckBox { font-weight:400; }"
        "QMenuBar { background:#f3f4f6; }"
        "QMenu { background:#ffffff; }"));

    m_banner = new QLabel(QStringLiteral("未连接"));
    m_banner->setMinimumHeight(36);
    m_banner->setAlignment(Qt::AlignVCenter | Qt::AlignLeft);
    m_banner->setContentsMargins(12, 0, 12, 0);
    root->addWidget(m_banner);

    auto deviceBox = new QGroupBox(QStringLiteral("设备连接"));
    auto deviceLayout = new QVBoxLayout(deviceBox);
    auto deviceRow = new QHBoxLayout;
    m_dot = new QLabel;
    m_dot->setFixedSize(10, 10);
    deviceRow->addWidget(m_dot, 0, Qt::AlignVCenter);
    deviceRow->addWidget(fieldPair(QStringLiteral("芯片"), &m_chip));
    deviceRow->addSpacing(16);
    deviceRow->addWidget(fieldPair(QStringLiteral("协议"), &m_protocol));
    deviceRow->addSpacing(16);
    deviceRow->addWidget(fieldPair(QStringLiteral("USB"), &m_usb));
    deviceRow->addStretch(1);
    m_detectBtn = new QPushButton(QStringLiteral("检测设备"));
    deviceRow->addWidget(m_detectBtn);
    deviceLayout->addLayout(deviceRow);
    m_hint = new QLabel;
    m_hint->setWordWrap(true);
    m_hint->setStyleSheet(QStringLiteral("color:#b42318;font-weight:400;"));
    deviceLayout->addWidget(m_hint);
    root->addWidget(deviceBox);

    auto middle = new QHBoxLayout;
    middle->setSpacing(10);

    auto configBox = new QGroupBox(QStringLiteral("烧录配置"));
    auto configForm = new QFormLayout(configBox);
    configForm->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    configForm->setHorizontalSpacing(10);
    configForm->setVerticalSpacing(8);

    auto bootRow = new QHBoxLayout;
    m_bootEdit = new QLineEdit;
    m_bootBrowse = new QPushButton(QStringLiteral("浏览"));
    bootRow->addWidget(m_bootEdit, 1);
    bootRow->addWidget(m_bootBrowse);
    m_bootMissing = new QLabel;
    m_bootMissing->setStyleSheet(QStringLiteral("color:#b42318;font-weight:400;"));
    auto bootWrap = new QVBoxLayout;
    bootWrap->setSpacing(2);
    bootWrap->addLayout(bootRow);
    bootWrap->addWidget(m_bootMissing);
    configForm->addRow(QStringLiteral("Bootloader"), bootWrap);

    auto linuxRow = new QHBoxLayout;
    m_linuxEdit = new QLineEdit;
    m_linuxBrowse = new QPushButton(QStringLiteral("浏览"));
    linuxRow->addWidget(m_linuxEdit, 1);
    linuxRow->addWidget(m_linuxBrowse);
    m_linuxMissing = new QLabel;
    m_linuxMissing->setStyleSheet(QStringLiteral("color:#b42318;font-weight:400;"));
    auto linuxWrap = new QVBoxLayout;
    linuxWrap->setSpacing(2);
    linuxWrap->addLayout(linuxRow);
    linuxWrap->addWidget(m_linuxMissing);
    configForm->addRow(QStringLiteral("Linux 镜像"), linuxWrap);

    auto target = new QLabel(QStringLiteral("SD 卡"));
    target->setStyleSheet(QStringLiteral("font-weight:600;"));
    configForm->addRow(QStringLiteral("目标介质"), target);
    middle->addWidget(configBox, 3);

    auto taskBox = new QGroupBox(QStringLiteral("烧录任务"));
    auto taskLayout = new QVBoxLayout(taskBox);
    auto actions = new QHBoxLayout;
    m_startBtn = new QPushButton(QStringLiteral("开始烧录"));
    m_startBtn->setObjectName(QStringLiteral("startButton"));
    m_cancelBtn = new QPushButton(QStringLiteral("取消"));
    actions->addWidget(m_startBtn);
    actions->addWidget(m_cancelBtn);
    actions->addStretch(1);
    taskLayout->addLayout(actions);

    auto steps = new QHBoxLayout;
    steps->setSpacing(6);
    const QStringList titles = {
        QStringLiteral("加载 Bootloader"),
        QStringLiteral("等待 Fastboot"),
        QStringLiteral("写入 SD"),
        QStringLiteral("完成")
    };
    for (const QString& title : titles) {
        auto label = new QLabel(title);
        label->setAlignment(Qt::AlignCenter);
        m_steps.push_back(label);
        steps->addWidget(label, 1);
    }
    taskLayout->addLayout(steps);

    m_progress = new QProgressBar;
    m_progress->setRange(0, 100);
    m_progress->setValue(0);
    m_progress->setFormat(QStringLiteral("总进度 %p%"));
    taskLayout->addWidget(m_progress);

    m_result = new QLabel(QStringLiteral("—"));
    m_result->setWordWrap(true);
    m_result->setStyleSheet(QStringLiteral("font-weight:400;"));
    taskLayout->addWidget(m_result);

    m_bootCheck = new QCheckBox(QStringLiteral("已断电，从 SD 卡启动，串口能进入系统"));
    m_bootCheck->setVisible(false);
    taskLayout->addWidget(m_bootCheck);
    taskLayout->addStretch(1);
    middle->addWidget(taskBox, 2);
    root->addLayout(middle);

    auto logBox = new QGroupBox(QStringLiteral("实时日志"));
    auto logLayout = new QVBoxLayout(logBox);
    auto logActions = new QHBoxLayout;
    logActions->addStretch(1);
    auto clearBtn = new QPushButton(QStringLiteral("清空"));
    auto exportBtn = new QPushButton(QStringLiteral("导出"));
    logActions->addWidget(clearBtn);
    logActions->addWidget(exportBtn);
    logLayout->addLayout(logActions);
    m_log = new QPlainTextEdit;
    m_log->setReadOnly(true);
    m_log->setMaximumBlockCount(5000);
    m_log->setStyleSheet(QStringLiteral("font-family:Menlo,Consolas,monospace;font-size:12px;"));
    logLayout->addWidget(m_log, 1);
    root->addWidget(logBox, 1);

    connect(clearBtn, &QPushButton::clicked, m_log, &QPlainTextEdit::clear);
    connect(exportBtn, &QPushButton::clicked, this, &MainWindow::exportLog);
}

void MainWindow::loadSettings()
{
    QSettings settings;
    const QString exe = settings.value(QStringLiteral("uuu/executable")).toString();
    if (!exe.isEmpty())
        m_tasks.setExecutable(exe);
    m_bootEdit->setText(settings.value(QStringLiteral("files/bootloader")).toString());
    m_linuxEdit->setText(settings.value(QStringLiteral("files/linux")).toString());
}

void MainWindow::saveFiles()
{
    QSettings settings;
    settings.setValue(QStringLiteral("files/bootloader"), m_bootEdit->text());
    settings.setValue(QStringLiteral("files/linux"), m_linuxEdit->text());
    const QString bootDir = QFileInfo(m_bootEdit->text()).absolutePath();
    const QString linuxDir = QFileInfo(m_linuxEdit->text()).absolutePath();
    if (!m_bootEdit->text().isEmpty())
        settings.setValue(QStringLiteral("paths/bootloaderDir"), bootDir);
    if (!m_linuxEdit->text().isEmpty())
        settings.setValue(QStringLiteral("paths/linuxDir"), linuxDir);
}

void MainWindow::detect()
{
    m_holdResult = false;
    m_tasks.detect();
}

void MainWindow::startFlash()
{
    FlashRequest request;
    request.bootloaderPath = m_bootEdit->text();
    request.linuxImagePath = m_linuxEdit->text();
    request.target = QStringLiteral("SD");
    m_log->clear();
    m_holdResult = false;
    m_tasks.submit(request);
}

void MainWindow::chooseBootloader()
{
    const QString path = browseFile(QStringLiteral("选择 Bootloader"), m_bootEdit->text(),
                                    QStringLiteral("Bootloader (*.bin)"));
    if (!path.isEmpty())
        m_bootEdit->setText(path);
}

void MainWindow::chooseLinux()
{
    const QString path = browseFile(QStringLiteral("选择 Linux 镜像"), m_linuxEdit->text(),
                                    QStringLiteral("Linux 镜像 (*.wic)"));
    if (!path.isEmpty())
        m_linuxEdit->setText(path);
}

QString MainWindow::browseFile(const QString& title, const QString& current, const QString& filter)
{
    QString dir = QFileInfo(current).absolutePath();
    if (current.isEmpty() || !QFileInfo::exists(dir)) {
        QSettings settings;
        const QString key = title.contains(QStringLiteral("Linux"))
            ? QStringLiteral("paths/linuxDir")
            : QStringLiteral("paths/bootloaderDir");
        dir = settings.value(key).toString();
    }
    return QFileDialog::getOpenFileName(this, title, dir, filter);
}

void MainWindow::chooseUuu()
{
#if defined(Q_OS_WIN)
    const QString filter = QStringLiteral("uuu (uuu.exe)");
#else
    const QString filter = QStringLiteral("uuu (*)");
#endif
    const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("选择 uuu"), QString(), filter);
    if (path.isEmpty())
        return;
    QSettings settings;
    settings.setValue(QStringLiteral("uuu/executable"), path);
    m_tasks.setExecutable(path);
    m_holdResult = false;
    m_tasks.detect();
}

void MainWindow::exportLog()
{
    const QString suggested = m_task.id.isEmpty()
        ? QStringLiteral("uuu-log.txt")
        : m_task.id + QStringLiteral(".txt");
    const QString path = QFileDialog::getSaveFileName(this, QStringLiteral("导出日志"), suggested,
                                                      QStringLiteral("Text (*.txt)"));
    if (path.isEmpty())
        return;

    QString content;
    if (!m_task.logPath.isEmpty() && QFileInfo::exists(m_task.logPath)) {
        QFile file(m_task.logPath);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text))
            content = QString::fromUtf8(file.readAll());
    } else {
        content = m_log->toPlainText();
    }
    QFile out(path);
    if (!out.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    out.write(content.toUtf8());
}

void MainWindow::openHistory()
{
    TaskHistoryDialog dialog(m_tasks.history(), this);
    dialog.exec();
}

void MainWindow::about()
{
    QMessageBox::about(this, QStringLiteral("关于"),
                       QStringLiteral("NXP UUU Flash Console\n通过 uuu -b sd_all 烧录 i.MX 95 的 SD 卡。"));
}

void MainWindow::onTask(const TaskRecord& task)
{
    m_task = task;
    if (task.state == TaskState::Succeeded || task.state == TaskState::Failed || task.state == TaskState::Cancelled)
        m_holdResult = true;
    updateStages(task.stage, task.state);
    updateResult(task);
    m_progress->setValue(task.state == TaskState::Idle ? 0 : task.percent);
    updateUi();
    if (m_tasks.isQuitting() && !m_tasks.isFlashing())
        close();
}

void MainWindow::onLog(const QString& taskId, const QString& text)
{
    Q_UNUSED(taskId);
    m_log->appendPlainText(text);
}

void MainWindow::updateStages(TaskStage stage, TaskState state)
{
    if (m_steps.size() != 4)
        return;
    const QStringList titles = {
        QStringLiteral("加载 Bootloader"),
        QStringLiteral("等待 Fastboot"),
        QStringLiteral("写入 SD"),
        QStringLiteral("完成")
    };
    int current = -1;
    switch (stage) {
    case TaskStage::LoadBootloader: current = 0; break;
    case TaskStage::WaitFastboot: current = 1; break;
    case TaskStage::FlashImage: current = 2; break;
    case TaskStage::Finish: current = 3; break;
    case TaskStage::WaitDevice: current = -1; break;
    }
    for (int i = 0; i < 4; ++i) {
        QString mode = QStringLiteral("pending");
        if (state == TaskState::Succeeded) {
            mode = QStringLiteral("done");
        } else if (state == TaskState::Failed || state == TaskState::Cancelled) {
            const int failedAt = current < 0 ? 0 : current;
            if (i < failedAt)
                mode = QStringLiteral("done");
            else if (i == failedAt)
                mode = QStringLiteral("failed");
        } else if (state == TaskState::Running) {
            const int active = current < 0 ? 0 : current;
            if (i < active)
                mode = QStringLiteral("done");
            else if (i == active)
                mode = QStringLiteral("current");
        }
        paintStep(m_steps.at(i), titles.at(i), mode);
    }
}

void MainWindow::updateResult(const TaskRecord& task)
{
    if (task.state == TaskState::Succeeded) {
        m_result->setText(QStringLiteral("成功，退出码 %1，耗时 %2")
                              .arg(task.exitCode)
                              .arg(durationText(task.startedAt, task.endedAt)));
        m_bootCheck->setVisible(true);
        const QSignalBlocker blocker(m_bootCheck);
        m_bootCheck->setChecked(task.bootChecked);
    } else if (task.state == TaskState::Failed) {
        m_result->setText(QStringLiteral("失败，退出码 %1，%2").arg(task.exitCode).arg(task.message));
        m_bootCheck->setVisible(false);
    } else if (task.state == TaskState::Cancelled) {
        m_result->setText(QStringLiteral("已取消"));
        m_bootCheck->setVisible(false);
    } else if (task.state == TaskState::Running) {
        m_result->setText(QStringLiteral("烧录中"));
        m_bootCheck->setVisible(false);
    } else {
        m_result->setText(QStringLiteral("—"));
        m_bootCheck->setVisible(false);
    }
}

void MainWindow::updateUi()
{
    const bool flashing = m_tasks.isFlashing();
    const bool detecting = m_tasks.isDetecting();
    const QVector<DeviceInfo> devices = m_tasks.devices();
    const QString error = m_tasks.detectError();
    const bool toolMissing = error.contains(QStringLiteral("未找到"));

    m_detectBtn->setEnabled(!flashing && !detecting);
    m_cancelBtn->setEnabled(flashing);
    m_bootEdit->setEnabled(!flashing);
    m_linuxEdit->setEnabled(!flashing);
    m_bootBrowse->setEnabled(!flashing);
    m_linuxBrowse->setEnabled(!flashing);

    const auto markMissing = [](QLabel* label, const QString& path) {
        if (!path.isEmpty() && !QFileInfo::exists(path))
            label->setText(QStringLiteral("文件不存在"));
        else
            label->clear();
    };
    markMissing(m_bootMissing, m_bootEdit->text());
    markMissing(m_linuxMissing, m_linuxEdit->text());

    QString chip = QStringLiteral("—");
    QString protocol = QStringLiteral("—");
    QString usb = QStringLiteral("—");
    QString hint;
    QString banner = QStringLiteral("未连接");
    QString bannerBg = QStringLiteral("#eef2f6");
    QString bannerFg = QStringLiteral("#344054");
    QString dot = QStringLiteral("#98a2b3");

    if (flashing && !m_task.device.usbPath.isEmpty()) {
        chip = m_task.device.chip;
        protocol = m_task.device.protocol;
        usb = m_task.device.usbPath;
    } else if (devices.size() == 1) {
        chip = devices.first().chip;
        protocol = devices.first().protocol;
        usb = devices.first().usbPath;
    }

    if (toolMissing) {
        banner = error;
        hint = error;
        bannerBg = QStringLiteral("#fef3f2");
        bannerFg = QStringLiteral("#b42318");
        dot = QStringLiteral("#f04438");
    } else if (flashing) {
        banner = QStringLiteral("烧录中");
        bannerBg = QStringLiteral("#fffaeb");
        bannerFg = QStringLiteral("#b54708");
        dot = QStringLiteral("#f79009");
    } else if (devices.isEmpty()) {
        if (!error.isEmpty()) {
            banner = error;
            hint = error;
            bannerBg = QStringLiteral("#fef3f2");
            bannerFg = QStringLiteral("#b42318");
            dot = QStringLiteral("#f04438");
        }
    } else if (devices.size() > 1) {
        banner = QStringLiteral("第一阶段只支持单板");
        QStringList rows;
        for (const DeviceInfo& device : devices)
            rows << device.raw;
        rows << QStringLiteral("第一阶段只支持单板");
        hint = rows.join(QLatin1Char('\n'));
        bannerBg = QStringLiteral("#fffaeb");
        bannerFg = QStringLiteral("#b54708");
        dot = QStringLiteral("#f79009");
    } else if (!isFlashableDevice(devices.first())) {
        banner = QStringLiteral("当前不是 MX95 串行下载");
        hint = devices.first().raw + QStringLiteral("\n当前不是 MX95 串行下载");
        bannerBg = QStringLiteral("#fef3f2");
        bannerFg = QStringLiteral("#b42318");
        dot = QStringLiteral("#f04438");
    } else {
        banner = QStringLiteral("已连接可烧录");
        bannerBg = QStringLiteral("#ecfdf3");
        bannerFg = QStringLiteral("#067647");
        dot = QStringLiteral("#12b76a");
    }

    if (!flashing && m_holdResult) {
        if (m_task.state == TaskState::Succeeded) {
            banner = QStringLiteral("烧录成功");
            bannerBg = QStringLiteral("#ecfdf3");
            bannerFg = QStringLiteral("#067647");
            dot = QStringLiteral("#12b76a");
        } else if (m_task.state == TaskState::Failed) {
            banner = QStringLiteral("烧录失败");
            bannerBg = QStringLiteral("#fef3f2");
            bannerFg = QStringLiteral("#b42318");
            dot = QStringLiteral("#f04438");
        } else if (m_task.state == TaskState::Cancelled) {
            banner = QStringLiteral("已取消");
            bannerBg = QStringLiteral("#eef2f6");
            bannerFg = QStringLiteral("#344054");
            dot = QStringLiteral("#98a2b3");
        }
    }

    m_chip->setText(chip);
    m_protocol->setText(protocol);
    m_usb->setText(usb);
    m_hint->setText(hint);
    m_banner->setText(QStringLiteral("  ") + banner);
    m_banner->setStyleSheet(QStringLiteral("background:%1;color:%2;border-radius:6px;font-weight:600;")
                                .arg(bannerBg, bannerFg));
    m_dot->setStyleSheet(QStringLiteral("background:%1;border-radius:5px;").arg(dot));

    const bool filesOk = QFileInfo::exists(m_bootEdit->text()) && QFileInfo::exists(m_linuxEdit->text());
    const bool deviceOk = devices.size() == 1 && isFlashableDevice(devices.first());
    m_startBtn->setEnabled(!flashing && !detecting && !toolMissing && deviceOk && filesOk);
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    if (m_tasks.isFlashing()) {
        event->ignore();
        m_tasks.beginQuit();
        return;
    }
    event->accept();
}
