#pragma once

#include "task/TaskManager.h"

#include <QCloseEvent>
#include <QLabel>
#include <QLineEdit>
#include <QMainWindow>
#include <QPlainTextEdit>
#include <QProgressBar>
#include <QPushButton>
#include <QCheckBox>
#include <QVector>

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    void buildUi();
    void loadSettings();
    void saveFiles();
    void detect();
    void startFlash();
    void chooseBootloader();
    void chooseLinux();
    void chooseUuu();
    void exportLog();
    void openHistory();
    void about();
    void onTask(const TaskRecord& task);
    void onLog(const QString& taskId, const QString& text);
    void updateUi();
    void updateStages(TaskStage stage, TaskState state);
    void updateResult(const TaskRecord& task);
    QString browseFile(const QString& title, const QString& current, const QString& filter);

    TaskManager m_tasks;
    TaskRecord m_task;
    bool m_holdResult = false;

    QLabel* m_banner = nullptr;
    QLabel* m_dot = nullptr;
    QLabel* m_chip = nullptr;
    QLabel* m_protocol = nullptr;
    QLabel* m_usb = nullptr;
    QLabel* m_hint = nullptr;
    QPushButton* m_detectBtn = nullptr;

    QLineEdit* m_bootEdit = nullptr;
    QLineEdit* m_linuxEdit = nullptr;
    QLabel* m_bootMissing = nullptr;
    QLabel* m_linuxMissing = nullptr;
    QPushButton* m_bootBrowse = nullptr;
    QPushButton* m_linuxBrowse = nullptr;

    QPushButton* m_startBtn = nullptr;
    QPushButton* m_cancelBtn = nullptr;
    QVector<QLabel*> m_steps;
    QProgressBar* m_progress = nullptr;
    QLabel* m_result = nullptr;
    QCheckBox* m_bootCheck = nullptr;

    QPlainTextEdit* m_log = nullptr;
};
