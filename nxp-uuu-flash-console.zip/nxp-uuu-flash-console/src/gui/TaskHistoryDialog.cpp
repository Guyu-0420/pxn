#include "gui/TaskHistoryDialog.h"

#include <QFile>
#include <QFileInfo>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QLabel>
#include <QPlainTextEdit>
#include <QSplitter>
#include <QTableWidget>
#include <QVBoxLayout>

namespace {

QString resultText(TaskState state)
{
    switch (state) {
    case TaskState::Succeeded: return QStringLiteral("成功");
    case TaskState::Failed: return QStringLiteral("失败");
    case TaskState::Cancelled: return QStringLiteral("已取消");
    default: return QStringLiteral("—");
    }
}

} // namespace

TaskHistoryDialog::TaskHistoryDialog(const QVector<TaskRecord>& records, QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(QStringLiteral("任务记录"));
    resize(860, 520);

    auto layout = new QVBoxLayout(this);
    auto table = new QTableWidget(records.size(), 5);
    table->setHorizontalHeaderLabels({
        QStringLiteral("时间"),
        QStringLiteral("USB 路径"),
        QStringLiteral("镜像文件名"),
        QStringLiteral("结果"),
        QStringLiteral("启动验证")
    });
    table->verticalHeader()->setVisible(false);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
    table->horizontalHeader()->setStretchLastSection(true);
    table->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);

    for (int row = 0; row < records.size(); ++row) {
        const TaskRecord& task = records.at(row);
        auto time = new QTableWidgetItem(task.startedAt.toString(QStringLiteral("yyyy-MM-dd HH:mm:ss")));
        time->setData(Qt::UserRole, task.logPath);
        table->setItem(row, 0, time);
        table->setItem(row, 1, new QTableWidgetItem(task.device.usbPath));
        table->setItem(row, 2, new QTableWidgetItem(QFileInfo(task.linuxImagePath).fileName()));
        table->setItem(row, 3, new QTableWidgetItem(resultText(task.state)));
        table->setItem(row, 4, new QTableWidgetItem(task.bootChecked ? QStringLiteral("是") : QStringLiteral("否")));
    }

    auto log = new QPlainTextEdit;
    log->setReadOnly(true);
    log->setPlaceholderText(records.isEmpty() ? QStringLiteral("无记录") : QStringLiteral("选择一条记录查看日志"));
    log->setStyleSheet(QStringLiteral("font-family:Menlo,Consolas,monospace;font-size:12px;"));

    auto splitter = new QSplitter(Qt::Vertical);
    splitter->addWidget(table);
    splitter->addWidget(log);
    splitter->setStretchFactor(0, 3);
    splitter->setStretchFactor(1, 2);
    layout->addWidget(splitter);

    connect(table, &QTableWidget::currentCellChanged, this, [table, log](int row) {
        if (row < 0 || !table->item(row, 0))
            return;
        const QString path = table->item(row, 0)->data(Qt::UserRole).toString();
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            log->setPlainText(QStringLiteral("日志文件不存在"));
            return;
        }
        log->setPlainText(QString::fromUtf8(file.readAll()));
    });

    if (records.isEmpty()) {
        auto empty = new QLabel(QStringLiteral("无记录"));
        empty->setAlignment(Qt::AlignCenter);
        layout->insertWidget(0, empty);
    } else {
        table->selectRow(0);
    }
}
