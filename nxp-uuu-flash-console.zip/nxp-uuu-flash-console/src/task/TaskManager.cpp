#include "task/TaskManager.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QStandardPaths>

namespace {

QJsonObject toJson(const TaskRecord& task)
{
    QJsonObject obj;
    obj.insert(QStringLiteral("id"), task.id);
    obj.insert(QStringLiteral("startedAt"), task.startedAt.toString(Qt::ISODate));
    obj.insert(QStringLiteral("endedAt"), task.endedAt.toString(Qt::ISODate));
    obj.insert(QStringLiteral("usbPath"), task.device.usbPath);
    obj.insert(QStringLiteral("chip"), task.device.chip);
    obj.insert(QStringLiteral("protocol"), task.device.protocol);
    obj.insert(QStringLiteral("vid"), task.device.vid);
    obj.insert(QStringLiteral("pid"), task.device.pid);
    obj.insert(QStringLiteral("bootloaderPath"), task.bootloaderPath);
    obj.insert(QStringLiteral("linuxImagePath"), task.linuxImagePath);
    obj.insert(QStringLiteral("target"), task.target);
    obj.insert(QStringLiteral("state"), taskStateName(task.state));
    obj.insert(QStringLiteral("stage"), static_cast<int>(task.stage));
    obj.insert(QStringLiteral("percent"), task.percent);
    obj.insert(QStringLiteral("exitCode"), task.exitCode);
    obj.insert(QStringLiteral("message"), task.message);
    obj.insert(QStringLiteral("bootChecked"), task.bootChecked);
    obj.insert(QStringLiteral("logPath"), task.logPath);
    return obj;
}

TaskRecord fromJson(const QJsonObject& obj)
{
    TaskRecord task;
    task.id = obj.value(QStringLiteral("id")).toString();
    task.startedAt = QDateTime::fromString(obj.value(QStringLiteral("startedAt")).toString(), Qt::ISODate);
    task.endedAt = QDateTime::fromString(obj.value(QStringLiteral("endedAt")).toString(), Qt::ISODate);
    task.device.usbPath = obj.value(QStringLiteral("usbPath")).toString();
    task.device.chip = obj.value(QStringLiteral("chip")).toString();
    task.device.protocol = obj.value(QStringLiteral("protocol")).toString();
    task.device.vid = obj.value(QStringLiteral("vid")).toString();
    task.device.pid = obj.value(QStringLiteral("pid")).toString();
    task.bootloaderPath = obj.value(QStringLiteral("bootloaderPath")).toString();
    task.linuxImagePath = obj.value(QStringLiteral("linuxImagePath")).toString();
    task.target = obj.value(QStringLiteral("target")).toString(QStringLiteral("SD"));
    task.state = taskStateFromName(obj.value(QStringLiteral("state")).toString());
    task.stage = static_cast<TaskStage>(obj.value(QStringLiteral("stage")).toInt());
    task.percent = obj.value(QStringLiteral("percent")).toInt();
    task.exitCode = obj.value(QStringLiteral("exitCode")).toInt(-1);
    task.message = obj.value(QStringLiteral("message")).toString();
    task.bootChecked = obj.value(QStringLiteral("bootChecked")).toBool();
    task.logPath = obj.value(QStringLiteral("logPath")).toString();
    return task;
}

QString formatStamp()
{
    return QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss "));
}

} // namespace

TaskManager::TaskManager(QObject* parent)
    : QObject(parent)
{
    connect(&m_uuu, &UUUAdapter::devicesReady, this, &TaskManager::onDevices);
    connect(&m_uuu, &UUUAdapter::output, this, &TaskManager::onOutput);
    connect(&m_uuu, &UUUAdapter::stageChanged, this, &TaskManager::onStage);
    connect(&m_uuu, &UUUAdapter::finished, this, &TaskManager::onFinished);
    load();
}

void TaskManager::detect()
{
    if (isFlashing() || m_uuu.isRunning())
        return;
    m_detecting = true;
    emit activityChanged();
    m_uuu.listDevices();
}

QString TaskManager::submit(const FlashRequest& request)
{
    if (isFlashing() || m_uuu.isRunning() || !m_uuu.executableFound())
        return {};
    if (m_devices.size() != 1 || !isFlashableDevice(m_devices.first()))
        return {};
    const QString bootloader = QFileInfo(request.bootloaderPath).absoluteFilePath();
    const QString image = QFileInfo(request.linuxImagePath).absoluteFilePath();
    if (!QFileInfo::exists(bootloader) || !QFileInfo::exists(image))
        return {};

    TaskRecord task;
    task.id = QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd_HHmmss_zzz"));
    task.startedAt = QDateTime::currentDateTime();
    task.device = m_devices.first();
    task.bootloaderPath = bootloader;
    task.linuxImagePath = image;
    task.target = QStringLiteral("SD");
    task.state = TaskState::Running;
    task.stage = TaskStage::WaitDevice;
    task.percent = 0;
    task.logPath = QDir(storageDir()).filePath(QStringLiteral("logs/") + task.id + QStringLiteral(".log"));
    QDir().mkpath(QFileInfo(task.logPath).absolutePath());

    if (m_log.isOpen())
        m_log.close();
    m_log.setFileName(task.logPath);
    if (!m_log.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text))
        m_lastOutput = QStringLiteral("无法写入日志");

    m_current = task;
    m_lastOutput.clear();
    m_cancelRequested = false;
    m_history.prepend(task);
    persist();
    emit taskChanged(task);

    FlashRequest command = request;
    command.bootloaderPath = bootloader;
    command.linuxImagePath = image;
    command.target = QStringLiteral("SD");
    m_uuu.start(task.device, command);
    return task.id;
}

void TaskManager::cancel(const QString& taskId)
{
    if (!m_current || m_current->id != taskId || m_current->state != TaskState::Running)
        return;
    m_cancelRequested = true;
    m_uuu.cancel();
}

void TaskManager::setBootChecked(const QString& taskId, bool checked)
{
    for (TaskRecord& task : m_history) {
        if (task.id != taskId || task.state != TaskState::Succeeded)
            continue;
        task.bootChecked = checked;
        if (m_current && m_current->id == taskId)
            m_current->bootChecked = checked;
        persist();
        emit taskChanged(task);
        return;
    }
}

void TaskManager::setExecutable(const QString& path)
{
    m_uuu.setExecutable(path);
}

void TaskManager::beginQuit()
{
    m_quitting = true;
    if (m_current && m_current->state == TaskState::Running)
        cancel(m_current->id);
}

QVector<TaskRecord> TaskManager::history() const
{
    return m_history;
}

QVector<DeviceInfo> TaskManager::devices() const
{
    return m_devices;
}

QString TaskManager::detectError() const
{
    return m_detectError;
}

bool TaskManager::isDetecting() const
{
    return m_detecting;
}

bool TaskManager::isFlashing() const
{
    return m_current && m_current->state == TaskState::Running;
}

bool TaskManager::isQuitting() const
{
    return m_quitting;
}

QString TaskManager::storageDir() const
{
    const QString appDir = QCoreApplication::applicationDirPath();
    if (QFileInfo(appDir).isWritable())
        return appDir;
    const QString fallback = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(fallback);
    return fallback;
}

void TaskManager::load()
{
    QFile file(QDir(storageDir()).filePath(QStringLiteral("tasks.json")));
    if (!file.open(QIODevice::ReadOnly))
        return;
    const QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    if (!doc.isArray())
        return;
    bool dirty = false;
    for (const QJsonValue& value : doc.array()) {
        if (!value.isObject())
            continue;
        TaskRecord task = fromJson(value.toObject());
        if (task.id.isEmpty())
            continue;
        if (task.state == TaskState::Running) {
            task.state = TaskState::Failed;
            task.message = QStringLiteral("未完成");
            if (!task.endedAt.isValid())
                task.endedAt = QDateTime::currentDateTime();
            dirty = true;
        }
        m_history.push_back(task);
    }
    if (dirty)
        persist();
}

void TaskManager::persist()
{
    QJsonArray array;
    for (const TaskRecord& task : m_history)
        array.append(toJson(task));
    QSaveFile file(QDir(storageDir()).filePath(QStringLiteral("tasks.json")));
    if (!file.open(QIODevice::WriteOnly))
        return;
    file.write(QJsonDocument(array).toJson(QJsonDocument::Indented));
    file.commit();
}

void TaskManager::replaceHistory(const TaskRecord& task)
{
    for (TaskRecord& item : m_history) {
        if (item.id == task.id) {
            item = task;
            return;
        }
    }
    m_history.prepend(task);
}

void TaskManager::onDevices(QVector<DeviceInfo> devices, QString error)
{
    m_detecting = false;
    m_devices = devices;
    m_detectError = error;
    emit devicesChanged(devices);
    emit activityChanged();
}

void TaskManager::onOutput(const QString& line)
{
    if (!m_current || m_current->state != TaskState::Running)
        return;
    m_lastOutput = line;
    const QString stamped = formatStamp() + line;
    if (m_log.isOpen()) {
        m_log.write(stamped.toUtf8());
        m_log.write("\n", 1);
        m_log.flush();
    }
    emit logLine(m_current->id, stamped);
}

void TaskManager::onStage(TaskStage stage, int percent)
{
    if (!m_current || m_current->state != TaskState::Running)
        return;
    m_current->stage = stage;
    m_current->percent = percent;
    replaceHistory(*m_current);
    emit taskChanged(*m_current);
}

void TaskManager::onFinished(int exitCode, bool success)
{
    if (!m_current || m_current->state != TaskState::Running)
        return;
    m_current->endedAt = QDateTime::currentDateTime();
    m_current->exitCode = exitCode;
    if (m_cancelRequested) {
        m_current->state = TaskState::Cancelled;
        m_current->message = QStringLiteral("已取消");
    } else if (success) {
        m_current->state = TaskState::Succeeded;
        m_current->stage = TaskStage::Finish;
        m_current->percent = 100;
        m_current->message.clear();
    } else {
        m_current->state = TaskState::Failed;
        m_current->message = m_lastOutput.isEmpty() ? QStringLiteral("烧录失败") : m_lastOutput;
    }
    if (m_log.isOpen())
        m_log.close();
    m_cancelRequested = false;
    replaceHistory(*m_current);
    persist();
    const TaskRecord done = *m_current;
    emit taskChanged(done);
    if (!m_quitting)
        detect();
}
