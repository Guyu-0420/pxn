#pragma once

#include <QDateTime>
#include <QMetaType>
#include <QString>
#include <QVector>

enum class TaskState {
    Idle,
    Detecting,
    Ready,
    Running,
    Succeeded,
    Failed,
    Cancelled
};

enum class TaskStage {
    WaitDevice,
    LoadBootloader,
    WaitFastboot,
    FlashImage,
    Finish
};

struct DeviceInfo {
    QString usbPath;
    QString chip;
    QString protocol;
    QString vid;
    QString pid;
    QString raw;
};

struct FlashRequest {
    QString bootloaderPath;
    QString linuxImagePath;
    QString target = QStringLiteral("SD");
};

struct TaskRecord {
    QString id;
    QDateTime startedAt;
    QDateTime endedAt;
    DeviceInfo device;
    QString bootloaderPath;
    QString linuxImagePath;
    QString target = QStringLiteral("SD");
    TaskState state = TaskState::Idle;
    TaskStage stage = TaskStage::WaitDevice;
    int percent = 0;
    int exitCode = -1;
    QString message;
    bool bootChecked = false;
    QString logPath;
};

inline bool isFlashableDevice(const DeviceInfo& device)
{
    return device.chip.contains(QStringLiteral("MX95"), Qt::CaseInsensitive)
        && device.protocol.compare(QStringLiteral("SDPS"), Qt::CaseInsensitive) == 0;
}

inline QString taskStateName(TaskState state)
{
    switch (state) {
    case TaskState::Idle: return QStringLiteral("Idle");
    case TaskState::Detecting: return QStringLiteral("Detecting");
    case TaskState::Ready: return QStringLiteral("Ready");
    case TaskState::Running: return QStringLiteral("Running");
    case TaskState::Succeeded: return QStringLiteral("Succeeded");
    case TaskState::Failed: return QStringLiteral("Failed");
    case TaskState::Cancelled: return QStringLiteral("Cancelled");
    }
    return QStringLiteral("Idle");
}

inline TaskState taskStateFromName(const QString& name)
{
    if (name == QLatin1String("Detecting")) return TaskState::Detecting;
    if (name == QLatin1String("Ready")) return TaskState::Ready;
    if (name == QLatin1String("Running")) return TaskState::Running;
    if (name == QLatin1String("Succeeded")) return TaskState::Succeeded;
    if (name == QLatin1String("Failed")) return TaskState::Failed;
    if (name == QLatin1String("Cancelled")) return TaskState::Cancelled;
    return TaskState::Idle;
}

Q_DECLARE_METATYPE(DeviceInfo)
Q_DECLARE_METATYPE(TaskRecord)
Q_DECLARE_METATYPE(QVector<DeviceInfo>)
