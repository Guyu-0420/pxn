#pragma once

#include "task/TaskRecord.h"
#include "uuu/UUUAdapter.h"

#include <QFile>
#include <QObject>
#include <optional>

class TaskManager : public QObject {
    Q_OBJECT
public:
    explicit TaskManager(QObject* parent = nullptr);

    void detect();
    QString submit(const FlashRequest& request);
    void cancel(const QString& taskId);
    void setBootChecked(const QString& taskId, bool checked);
    void setExecutable(const QString& path);
    void beginQuit();

    QVector<TaskRecord> history() const;
    QVector<DeviceInfo> devices() const;
    QString detectError() const;
    bool isDetecting() const;
    bool isFlashing() const;
    bool isQuitting() const;

signals:
    void devicesChanged(QVector<DeviceInfo> devices);
    void taskChanged(TaskRecord task);
    void logLine(QString taskId, QString text);
    void activityChanged();

private:
    QString storageDir() const;
    void load();
    void persist();
    void replaceHistory(const TaskRecord& task);
    void onDevices(QVector<DeviceInfo> devices, QString error);
    void onOutput(const QString& line);
    void onStage(TaskStage stage, int percent);
    void onFinished(int exitCode, bool success);

    UUUAdapter m_uuu;
    QVector<TaskRecord> m_history;
    QVector<DeviceInfo> m_devices;
    std::optional<TaskRecord> m_current;
    QFile m_log;
    QString m_detectError;
    QString m_lastOutput;
    bool m_detecting = false;
    bool m_cancelRequested = false;
    bool m_quitting = false;
};
