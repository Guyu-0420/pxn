#include "gui/MainWindow.h"

#include <QApplication>
#include <QVector>

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    QApplication::setOrganizationName(QStringLiteral("UUUFlashConsole"));
    QApplication::setApplicationName(QStringLiteral("UUUFlashConsole"));
    qRegisterMetaType<DeviceInfo>();
    qRegisterMetaType<TaskRecord>();
    qRegisterMetaType<QVector<DeviceInfo>>();

    MainWindow window;
    window.show();
    return app.exec();
}
