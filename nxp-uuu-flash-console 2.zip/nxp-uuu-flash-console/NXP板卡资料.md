# NXP 板卡资料（公开信息整理）

来源：NXP 官网各板卡页与 NXP 文档站、uuu（nxp-imx/mfgtools）源码与 wiki、用户提供的板卡总表。
抓取日期：2026-11-13。凡标注「实测」的来自本项目已有记录，其余为官网公开信息。
说明：本文件只汇总**公开**资料，供程序补资料时引用；程序实际读取的仍是 `<chip>-config.cfg`，本文件不参与运行。

---

## 1. FRDM 开发板总表（25 块）

板卡页统一为 `https://www.nxp.com/design/design-center/development-boards-and-designs/<MPN>`，
入门指南统一为 `https://www.nxp.com/document/guide/<guide>`（下表 guide 列已含 `GS-` 编号）。

| 系列 | 板卡 | 芯片 | 板卡页 | 入门指南（GS） |
| --- | --- | --- | --- | --- |
| MCX C（入门 MCU） | FRDM-MCXC041 | MCX C041 | FRDM-MCXC041 | GS-FRDM-MCXC041 |
| MCX C | FRDM-MCXC162 | MCX C162 | FRDM-MCXC162 | GS-FRDM-MCXC162 |
| MCX C | FRDM-MCXC242 | MCX C242 | FRDM-MCXC242 | GS-FRDM-MCXC242 |
| MCX C | FRDM-MCXC444 | MCX C444 | FRDM-MCXC444 | GS-FRDM-MCXC444 |
| MCX A（主流 MCU） | FRDM-MCXA153 | MCX A14x/A15x | FRDM-MCXA153 | GS-FRDM-MCXAXX |
| MCX A | FRDM-MCXA156 | MCX A144/A154/A156 | FRDM-MCXA156 | GS-FRDM-MCXA156 |
| MCX A | FRDM-MCXA174 | MCX A173/A174 | FRDM-MCXA174 | GS-FRDM-MCXA174 |
| MCX A | FRDM-MCXA266 | MCX A175/A176/A185/A186/A255/A256/A265/A266 | FRDM-MCXA266 | GS-FRDM-MCXA266 |
| MCX A | FRDM-MCXA344 | MCX A343/A344 | FRDM-MCXA344 | GS-FRDM-MCXA344 |
| MCX A | FRDM-MCXA346 | MCX A345/A346 | FRDM-MCXA346 | GS-FRDM-MCXA346 |
| MCX A | FRDM-MCXA366 | MCX A355/A356/A365/A366 | FRDM-MCXA366 | GS-FRDM-MCXA366 |
| MCX E（主流 MCU） | FRDM-MCXE247 | MCX E245/E246/E247 | FRDM-MCXE247 | GS-FRDM-MCXE247 |
| MCX E | FRDM-MCXE31B | MCX E31 | FRDM-MCXE31B | GS-FRDM-MCXE31B |
| MCX N（高阶 MCU） | FRDM-MCXN236 | MCX N23x | FRDM-MCXN236 | GS-FRDM-MCXN236 |
| MCX N | FRDM-MCXN947 | MCX N94x/N54x | FRDM-MCXN947 | GS-FRDM-MCXN947 |
| i.MX RT（实时 MCU） | FRDM-IMXRT1186 | i.MX RT1186 | FRDM-IMXRT1186 | GS-FRDM-IMXRT1186 |
| MCX W（连接 MCU） | FRDM-MCXW23 | MCX W23 | FRDM-MCXW23 | GS-FRDM-MCXW23 |
| MCX W | FRDM-MCXW71 | MCX W71 | FRDM-MCXW71 | GS-FRDM-MCXW71 |
| MCX W | FRDM-MCXW72 | MCX W72 | FRDM-MCXW72 | GS-FRDM-MCXW72 |
| RW612（连接 MCU） | FRDM-RW612 | RW612 | FRDM-RW612 | GS-FRDM-RW612 |
| i.MX 91（入门 MPU） | FRDM-IMX91 | i.MX 91 | FRDM-IMX91 | GS-FRDM-IMX91 |
| i.MX 91 | FRDM-IMX91S | i.MX 91 | FRDM-IMX91S | GS-FRDM-IMX91S |
| i.MX 93（主流 MPU） | FRDM-IMX93 | i.MX 93 | FRDM-IMX93 | GS-FRDM-IMX93 |
| i.MX 8M Plus（高阶 MPU） | FRDM-IMX8MPLUS | i.MX 8M Plus | FRDM-IMX8MPLUS | GS-FRDM-IMX8MPLUS |
| i.MX 95（高阶 MPU） | FRDM-IMX95 | i.MX 95 | FRDM-IMX95 | GS-FRDM-IMX95 |

说明：
- 板卡页 slug 与 MPN 一致；入门指南的 slug 与 MPN 不一定一致，完整 slug 见下表（官方 JSON-LD 抓取原值）。
- 入门指南完整链接：`https://www.nxp.com/document/guide/<slug>`。

| 板卡 | 入门指南 slug |
| --- | --- |
| FRDM-MCXC041 | getting-started-with-frdm-mcxc041:GS-FRDM-MCXC041 |
| FRDM-MCXC162 | getting-started-with-frdm-mcxc162:GS-FRDM-MCXC162 |
| FRDM-MCXC242 | getting-started-with-frdm-mcxc242:GS-FRDM-MCXC242 |
| FRDM-MCXC444 | getting-started-with-frdm-mcxc444:GS-FRDM-MCXC444 |
| FRDM-MCXA153 | getting-started-with-frdm-mcxa153:GS-FRDM-MCXAXX |
| FRDM-MCXA156 | getting-started-with-frdm-mcxa156:GS-FRDM-MCXA156 |
| FRDM-MCXA174 | getting-started-with-frdm-mcxa174:GS-FRDM-MCXA174 |
| FRDM-MCXA266 | getting-started-with-frdm-mcxa266:GS-FRDM-MCXA266 |
| FRDM-MCXA344 | getting-started-with-frdm-mcxa344:GS-FRDM-MCXA344 |
| FRDM-MCXA346 | getting-started-with-frdm-mcxa346:GS-FRDM-MCXA346 |
| FRDM-MCXA366 | getting-started-with-frdm-mcxa366:GS-FRDM-MCXA366 |
| FRDM-MCXE247 | getting-started-with-the-frdm-mcxe247-board:GS-FRDM-MCXE247 |
| FRDM-MCXE31B | getting-started-with-the-frdm-mcxe31b-board:GS-FRDM-MCXE31B |
| FRDM-MCXN236 | getting-started-with-frdm-mcxn236:GS-FRDM-MCXN236 |
| FRDM-MCXN947 | getting-started-with-frdm-mcxn947:GS-FRDM-MCXN947 |
| FRDM-IMXRT1186 | getting-started-with-frdm-imxrt1186:GS-FRDM-IMXRT1186 |
| FRDM-MCXW23 | getting-started-with-frdm-mcxw23:GS-FRDM-MCXW23 |
| FRDM-MCXW71 | getting-started-with-frdm-mcxw71:GS-FRDM-MCXW71 |
| FRDM-MCXW72 | getting-started-with-frdm-mcxw72:GS-FRDM-MCXW72 |
| FRDM-RW612 | getting-started-with-frdm-rw612:GS-FRDM-RW612 |
| FRDM-IMX91 | getting-started-with-frdm-imx91-development-board:GS-FRDM-IMX91 |
| FRDM-IMX91S | getting-started-with-frdm-imx91s:GS-FRDM-IMX91S |
| FRDM-IMX93 | getting-started-with-frdm-imx93:GS-FRDM-IMX93 |
| FRDM-IMX8MPLUS | getting-started-with-frdm-imx8mplus:GS-FRDM-IMX8MPLUS |
| FRDM-IMX95 | getting-started-with-frdm-imx95:GS-FRDM-IMX95 |

---

## 2. 各系列说明与定位（官网公开信息）

### 2.1 MCX C（Entry MCU，入门）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-MCXC041 | 传感器节点、电动工具 | Arm Cortex-M0+，32 kB Flash，2 kB RAM，UART，SPI，I²C |
| FRDM-MCXC162 | 传感器节点、电动工具、电机控制 | Arm Cortex-M23，64 kB Flash，12 kB SRAM，16-bit ADC，DAC，OpAmp，FlexPWM，RTC，LPUART，LPSPI，LPI²C |
| FRDM-MCXC242 | 传感器节点、电动工具 | Arm Cortex-M0+，256 kB Flash，32 kB RAM，FS USB |
| FRDM-MCXC444 | 传感器节点、电动工具、基础显示 | Arm Cortex-M0+，256 kB Flash，32 kB RAM，FS USB，SLCD，可见光传感器 |

### 2.2 MCX A（Mainstream MCU，主流）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-MCXA153 | 智能传感节点、电机控制 | Arm Cortex-M33，128 kB Flash，32 kB RAM，FS USB，1x 16b ADC |
| FRDM-MCXA156 | 智能传感节点、电机控制、工业 HMI | Arm Cortex-M33，1 MB Flash，128 kB RAM，FlexIO，CAN FD，FS USB，2x 16b ADC |
| FRDM-MCXA174 | 智能传感节点、电机控制 | Arm Cortex-M33，256 kB Flash，FS USB，ADC，CAN-FD，Smart DMA |
| FRDM-MCXA266 | 智能传感节点、电机控制、工业 HMI | Arm Cortex-M33，1 MB Flash，FS USB，SLCD，CAN-FD，高级安全，FlexIO |
| FRDM-MCXA344 | 智能传感节点、电机控制 | Arm Cortex-M33，256 kB Flash，ADC，CAN-FD |
| FRDM-MCXA346 | 高级电机控制 | Arm Cortex-M33，1 MB Flash，2x FlexPWM，数学加速单元 |
| FRDM-MCXA366 | 智能传感节点、电机控制、工业 HMI | Arm Cortex-M33，1 MB Flash，FS USB，SLCD，CAN-FD，高级安全，FlexIO |

### 2.3 MCX E（Mainstream MCU，主流）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-MCXE247 | 电机驱动、热泵、HVAC、电动工具 | Arm Cortex-M4F，2 MB Flash + 8 MB 外扩，5/3.3 V，Ethernet，3x CAN FD |
| FRDM-MCXE31B | 工厂自动化功能安全 | Arm Cortex-M7，4 MB Flash + 8 MB 外扩，5/3.3 V，Ethernet，3x CAN FD |

### 2.4 MCX N（Advanced MCU，高阶）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-MCXN236 | HMI、电机控制 | Arm Cortex-M33，1 MB Flash，HS USB，CAN-FD，并口显示与摄像头，外扩 Flash |
| FRDM-MCXN947 | TinyML、工厂自动化 | Arm Cortex-M33，2 MB Flash + NPU，Ethernet，HS USB，CAN-FD，并口显示与摄像头，外扩 Flash |

### 2.5 i.MX RT（Real-Time MCU，跨界 MCU）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-IMXRT1186 | 工厂自动化工业网络 | Arm Cortex-M7 + Arm Cortex-M33 至 300 MHz，256 Mbit HyperRAM，512 Mbit HyperFlash + 128 Mbit QSPI Flash，2x Ethernet(TSN)，2x EtherCAT 或 TSN Switch，USB Type-C，CAN 收发器，电机控制排针 |

### 2.6 MCX W（Connectivity MCU，连接）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-MCXW23 | 便携医疗、智能传感、资产追踪 | Arm Cortex-M33，1 MB Flash，小尺寸，Buck DCDC，电池接口 |
| FRDM-MCXW71 | 智能照明、计量、传感 | Arm Cortex-M33，多协议连接 Bluetooth LE 5.3 与 802.15.4，USB，RF 接口，PCB 天线 |
| FRDM-MCXW72 | Matter 智能家居终端 | Arm Cortex-M33，2 MB Flash，256 kB 应用 RAM，Bluetooth Channel Sounding，CAN，EdgeLock SE |

### 2.7 RW612（Connectivity MCU，连接）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-RW612 | Matter 智能家居边界路由器 | Arm Cortex-M33，板载 QSPI Flash 与 PSRAM，无内置 Flash，Ethernet，PCB 天线，HS USB |

### 2.8 i.MX 91（Entry MPU，入门）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-IMX91 | 网关、工业 HMI | Arm Cortex-A55，IW610，1 GB DRAM，8 GB eMMC，SD 卡，2x Ethernet，M.2(Key E)，需返工，并口显示与摄像头 |
| FRDM-IMX91S | 网关、工业 HMI、Linux 精简版 | Arm Cortex-A55，IW610，512 MB DRAM，256 MB eMMC，SD 卡，1x Ethernet，并口显示与摄像头 |

### 2.9 i.MX 93（Mainstream MPU，主流）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-IMX93 | 网关、工业 HMI、工业视觉 | 双核 Arm Cortex-A55 + Arm Cortex-M33，Neutron NPU，IW612，2x Ethernet，HDMI，MIPI-CSI/DSI，LPDDR4X 16b 2 GB，eMMC 32 GB，MicroSD |

### 2.10 i.MX 8M Plus（Advanced MPU，高阶）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-IMX8MPLUS | 高阶工业视觉、HMI | 多核 Arm Cortex-A53 + Cortex-M7，Neutron NPU，IW612，2x Ethernet，LVDS，HDMI，MIPI CSI/DSI，LPDDR4 16b 4 GB，eMMC 32 GB，MicroSD |

### 2.11 i.MX 95（Advanced MPU，高阶）

| 板卡 | 目标应用 | 关键特性 |
| --- | --- | --- |
| FRDM-IMX95 | 边缘生成式 AI 与视觉 | 多核 Cortex-A55 + M7 + M33，15x15 封装，NXP eIQ Neutron NPU，IW612 M.2 模块，2x Ethernet，LVDS，LVDS 转 HDMI，MIPI CSI/DSI，MIPI CSI，LPDDR5 16b 8 GB，eMMC 32 GB，MicroSD，M.2 Key E，M.2 Key M(ML 加速)，PMIC |

---

## 3. i.MX Linux BSP 镜像包（官网公开）

i.MX 官方 Linux BSP 以 Yocto 镜像包发布，命名 `LF_v<版本>_images_<板卡>.zip`，包内含
`imx-boot-*`（Bootloader）与 `imx-image-*.wic`（整卡镜像）。下载入口为
`https://www.nxp.com/webapp/Download?colCode=<colCode>&appType=license`（需 NXP 账号）。

抓取到各 FRDM 板卡页公开列出的 BSP 包（版本 LF_v6.6.36-2.1.0）：

| 板卡 | 镜像包名 | colCode |
| --- | --- | --- |
| FRDM-IMX91 | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX91 | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX91 |
| FRDM-IMX91 | LF_v6.6.36-2.1.0_images_FRDM_2.0_iMX91 | LF_v6.6.36-2.1.0_images_FRDM_2.0_iMX91 |
| FRDM-IMX91S | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX91S | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX91S |
| FRDM-IMX93 | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX93 | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX93 |
| FRDM-IMX93 | LF_v6.6.36-2.1.0_images_FRDM_2.0_i.MX93 | LF_v6.6.36-2.1.0_images_FRDM_2.0_i.MX93 |
| FRDM-IMX93 | LF_v6.6.36-2.1.0_images_FRDM_1.0_i.MX93 | LF_v6.6.36-2.1.0_images_FRDM_1.0_i.MX93 |
| FRDM-IMX8MPLUS | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX8MPLUS | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX8MPLUS |

注：
- FRDM-IMX95 板卡页未列出 LF_v 镜像包；本项目实测用的是 `LF_v6.18.20-2.0.0`（对应 `IMX95EVK`），
  与 6.6.36 不是同一版本线。
- FRDM-IMXRT1186、MCX 系列、RW612 是 MCU，不走 Yocto Linux BSP，用 MCUXpresso / LinkServer 下载。
- 下载包内的具体文件名（`imx-boot-*`、`imx-image-*.wic`）需下载后确认；下载页需登录，脚本抓不到清单。

---

## 3.1 已建芯片配置 cfg（程序启动时读取）

程序读 exe 同目录的 `<chip>-config.cfg`，按 `uuu -lsusb` 检测到的芯片名选。已建：

| 文件 | 芯片名（uuu 识别名） | 脚本（每种介质一行） | 板型 | 下载页 |
| --- | --- | --- | --- | --- |
| imx95-config.cfg | MX95 | sd_all / emmc_all / nand / qspi / spi_nand / nvme_all | FRDM i.MX 95 PRO / i.MX 95 EVK（19x19 / 15x15） | LF_v6.18.37-2.1.0_MX95 |
| imx91-config.cfg | MX91 | sd_all / emmc_all / nand / qspi / spi_nand / nvme_all | FRDM i.MX 91 / FRDM i.MX 91S / i.MX 91 EVK（11x11） | LF_v6.6.36-2.1.0_images_FRDM_4.0_IMX91 |
| imx93-config.cfg | MX93 | sd_all / emmc_all / nand / qspi / spi_nand / nvme_all | FRDM i.MX 93 / i.MX 93 EVK | IMXLINUX（具体包名待确认） |
| imx8mplus-config.cfg | MX865 | sd_all / emmc_all / nand / qspi / spi_nand / nvme_all | FRDM i.MX 8M Plus / i.MX 8M Plus EVK | LF-V6636-210-IMAGES-FRDM-30-IMX8MP |

各板 `[board]` 除程序读的 `id`/`name`/`bootloader` 外，另存了该板的拨码与端口（程序暂未读取，供后续用）。
数据来源为 NXP 官方入门指南（2026-11-13 抓取）：

| 板型 | switchDownload | switchSd | downloadPort | debugUart |
| --- | --- | --- | --- | --- |
| FRDM i.MX 91（11x11） | SW1 = 0 0 0 1 | SW1 = 0 0 1 1 | P2（USB 2.0 Type-C） | P16（CH342F，两路 COM） |
| FRDM i.MX 91S | SW1 = 0 0 0 1 | SW1 = 0 0 1 1 | J5（USB1） | J11（CH342F，两路 COM） |
| FRDM i.MX 93 | SW1 = 0 0 0 1 | SW1 = 0 0 1 1 | P2（USB1，USB 2.0 Type-C） | P16（CH342F，两路 COM） |
| FRDM i.MX 8M Plus | SW5 = 0 0 0 1 | SW5 = 0 0 1 1 | J3（USB3.0 OTG） | J19（CH342F，两路 COM：A53 + 1） |
| FRDM i.MX 95（15x15） | SW1 = x 0 0 1 | SW1[1:2] = 1 1 | J3（USB1） | J1（CH344，四路 COM：A55/M33/M7 + 1） |
| FRDM i.MX 95 PRO（19x19，程序默认板型） | SW4 = x 0 0 1（待确认） | SW4[1:2] = 1 1（待确认） | ? | CH344 |

说明：
- 拨码 `0` = OFF、`1` = ON。i.MX 91/91S/93 的拨码表按 `SW1[4-1]` 顺序（SW1-4 在最左）；i.MX 8M Plus 按 `SW5[1-4]`；i.MX 95 只用到 `SW1[1-2]`（`x` 表示无关）。i.MX 95 FRDM 的 `SW5` 是电源开关，与拨码无关。
- `b*.bootloader`（包内 `imx-boot-*` 全名）允许留空：NXP 入门指南只给 `uuu -b sd_all <wic>` 这种写法，没有列出 `imx-boot-*` 全名，且文件名随版本变。留空时「从官方 zip 提取」会列出包内全部 `imx-boot*`：只有一个就自动选，多个就让操作员搜索或手输（见 `开发文档.md` §7.2）。

## 3.2 FRDM-IMX95 官方入门指南（2026-11-16 抓取）

来源：https://www.nxp.com/document/guide/getting-started-with-frdm-imx95:GS-FRDM-IMX95

- 板卡：FRDM i.MX 95 Development Board（FRDM-IMX95）
- 配件：Type-C to Type-C 线、Type-C to Type-A 线；2EL M.2 模块（IW612，Wi-Fi / 蓝牙 / 802.15.4）；eMMC 预装 Linux BSP 镜像；快速入门指南
- 默认启动：eMMC（板子预装 Linux 镜像）
- 调试口：`J1`（Type-C to Type-A），出现**四路** COM（A55 / M33 / M7 + 1）；Linux 下装 CH344 驱动（github.com/WCHSoftGroup/ch343ser_linux）
- 启动拨码 `SW1[1-2]`：串行下载 `x 0 0 1`；USDHC1 8-bit eMMC 5.1 `x 0 1 0`；USDHC2 4-bit SD3.0 `x 0 1 1`；默认 eMMC/uSDHC1
- HDMI：`J17`
- 电源：`J25`（USB-PD 适配器，Type-C to Type-C），电源开关 `SW5`

## 3.3 FRDM-IMX8MPLUS 官方入门指南（2026-11-16 抓取）

来源：https://www.nxp.com/document/guide/getting-started-with-frdm-imx8mplus:GS-FRDM-IMX8MPLUS

- 板卡：FRDM-IMX8MPLUS board（板载 u-blox MAYA-W276-00B / IW612，Wi-Fi 6 三频）
- 配件：USB 3.0 Type-C to Type-A 线、USB 3.0 Type-C to Type-C 线；eMMC 预装 Linux BSP 镜像；快速入门指南
- 默认启动：eMMC（板子预装 Linux 镜像）
- 调试口：`J19`（Type-C to Type-A），出现**两路** COM（第一路为 A53）；Linux 下装 CH342F 驱动（github.com/WCHSoftGroup/ch343ser_linux）
- 启动拨码 `SW5[1-4]`：内部熔丝 `0000`；USB 串行下载 `0001`；uSDHC3 8-bit eMMC 5.1 `0010`；uSDHC2 4-bit SD3.0 `0011`；NAND 8-bit 单设备 256 page `0100`；NAND 8-bit 单设备 512 page `0101`；QSPI 3B Read `0110`；QSPI Hyperflash 3.3V `0111`；ecSPI Boot `1000`；默认 eMMC/uSDHC3
- HDMI：`J16`
- 电源：`J2`（USB-PD 适配器，Type-C to Type-C）

## 4. 与 UUU 的关系（哪些能用 uuu 烧录）

uuu 只认 USB 的 VID/PID（见 `开发文档.md` 第 14 章）。按芯片分两类：

| 类别 | 芯片 | 烧录工具 | 本程序 |
| --- | --- | --- | --- |
| i.MX 应用处理器 | i.MX 6/7/8/8M/8ULP/91/93/95 等 | **uuu（SDPS/SDP + FB）** | 可做（`<chip>-config.cfg`） |
| i.MX RT 跨界 MCU | i.MX RT106x（uuu 表内 MXRT106X） | uuu 或 MCUXpresso | uuu 支持，本项目未做 |
| MCX C/A/E/N/W、RW612 | — | MCUXpresso IDE / LinkServer / blhost | 不走 uuu，本程序不支持 |

即：用户表里能进本程序范围的只有 i.MX 91 / 93 / 8M Plus / 95（以及 i.MX RT 视情况）。
MCX 系列与 RW612 属 MCU 生态，用 MCUXpresso 开发，与 uuu 无关。

各 i.MX 芯片在 uuu 里的识别名（`-lsusb` 的 Chip 列）见 `开发文档.md` 第 14 章，例如：
i.MX 8M Plus 显示为 **MX865**，i.MX 91 为 **MX91**，i.MX 93 为 **MX93**，i.MX 95 为 **MX95**。

---

## 5. 板卡页公开文档（Quick Start / User Guide）

各板卡页列出的公开文档（colCode）：

| 板卡 | 快速入门 | 板卡用户手册 | i.MX FRDM 软件文档 |
| --- | --- | --- | --- |
| FRDM-IMX91 | FRDM-IMX91-QSG | UM12262 | UG10345 / UG10195 |
| FRDM-IMX91S | — | UM12349 | UG10345 / UG10195 |
| FRDM-IMX93 | FRDM-IMX93-QSG | UM12181 | UG10345 / UG10195 |
| FRDM-IMX8MPLUS | GS-FRDM-IMX8MPLUS（在线入门指南） | UM12340 | UG10244 / UG10345 / UG10195 |
| FRDM-IMX95 | GS-FRDM-IMX95（在线入门指南） | UM12472 | UG10244 |
| FRDM-IMXRT1186 | — | UM12450 | — |
| FRDM-MCXA153 | — | — | UG10345 / UG10195 |

文档链接：`https://www.nxp.com/webapp/Download?colCode=<colCode>`。

---

## 6. 待补充（需下载 BSP 包后确认）

- 各 i.MX 板卡 BSP 包里 `imx-boot-*` 的**确切文件名**：可选，不强制。
  - NXP 入门指南只写 `uuu -b sd_all <wic>`，没有公开 `imx-boot-*` 全名；文件名还随版本变（如 i.MX 95 指南用 `...-flash_all`）。
  - 程序策略：`b*.bootloader` 只是「预选提示」，留空或对不上就由「从官方 zip 提取」列候选让操作员选/搜（见 `开发文档.md` §7.2）。
  - 若以后下载到某版本 zip，可把确认过的全名补进 `<chip>-config.cfg`，匹配上就能少点一次。
- 各板卡启动的**拨码设置**与**下载口位置**：FRDM i.MX 91 / 91S / 93 / 8M Plus / 95 已从官方入门指南补全（见 3.1 / 3.2）；EVK 板型与 FRDM i.MX 95 PRO（19x19）待补。
- i.MX 93 的 BSP 包名与下载 colCode 待确认（当前用通用 i.MX Linux 下载页兜底）。
- 后续如需扩展，按 `支持范围讨论清单.md` 第 7 节：每款芯片一个 `<chip>-config.cfg`，每块板一行。
- **板级硬件改动（rework）**：某些启动介质要先动板子才能用（如 i.MX 93 EVK 的 QSPI NOR 要 DNP R922 + 装 R950），见 `维修方案知识库.md`。

### 6.1 每块板 × 每种介质要补的三样

1. **启动拨码**：只能从板子的「硬件用户手册 / 入门指南」的 *Boot Devices* / *Boot Switch* 表，或原理图里拿。现在 cfg 只存了「串行下载 + SD」两组（见 3.1）；eMMC / NAND / QSPI / SPI NAND / NVMe 的拨码**整块都缺**，EVK 板型也缺。
   - 查法：搜 `<板卡名> hardware user guide` → Boot Devices / Boot configuration；或板卡页里的 `UM#####`（见第 5 节 colCode 表）。
2. **该介质有没有整卡 wic 镜像**：下载 BSP 包（`LF_v*_images_<板子>.zip`）后看包内有没有 `imx-image-*.wic`；有就能整卡烧，没有就只烧 Bootloader。一般 QSPI NOR 没有（太小），NAND / SPI NAND 看 BSP 有没有给 UBI 镜像。
   - 查法：NXP 官方 BSP 下载页（第 6 节链接）→ 下包 → 看包内文件名。
3. **该介质的 uuu 脚本名**：uuu 内置 10 个通用脚本（`emmc`/`emmc_all`/`fat_write`/`nand`/`nvme_all`/`qspi`/`sd`/`sd_all`/`spi_nand`/`spl`），按介质直接选，**没有哪块板子自带内置脚本**（见 `uuu功能说明.md` §2）。板子特有的流程由 BSP 包附带外部脚本，用 `-b <文件>` 跑。

---

## 7. 每块板 × 每种介质总表

说明：`?` = 待补；拨码 `0` = OFF、`1` = ON、`x` = 无关。拨码 / 端口来自 NXP 官方入门指南（2026-11-13 抓取）与本项目实测；rework 详见 `维修方案知识库.md`。后续每拿到一块板的数据就补一行。

### 7.1 启动拨码

| 板卡 | 芯片 | 串行下载 | SD | eMMC | NAND | QSPI NOR | SPI NAND | NVMe |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FRDM i.MX 95 PRO（19x19） | MX95 | x001 | x011 | x010 | ? | ? | ? | ? |
| i.MX 95 EVK（19x19） | MX95 | ? | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 95（15x15） | MX95 | x001 | x011 | x010 | ? | ? | ? | ? |
| i.MX 95 EVK（15x15） | MX95 | ? | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 91（11x11） | MX91 | 0001 | 0011 | ? | ? | ? | ? | ? |
| FRDM i.MX 91S | MX91 | 0001 | 0011 | ? | ? | ? | 0101 | ? |
| i.MX 91 EVK（11x11） | MX91 | ? | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 93 | MX93 | 0001 | 0011 | ? | ? | ? | ? | ? |
| i.MX 93 EVK | MX93 | ? | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 8M Plus | MX865 | 0001 | 0011 | 0010 | 0100 / 0101 | 0110 / 0111 | —（ecSPI Boot 1000） | — |
| i.MX 8M Plus EVK | MX865 | ? | ? | ? | ? | ? | ? | ? |

注：
- 拨码块：i.MX 91 / 91S / 93 用 `SW1[4-1]`；i.MX 8M Plus 用 `SW5[1-4]`；FRDM i.MX 95（15x15）只用 `SW1[1-2]`（`SW1-1`=`BOOT_MODE1`、`SW1-2`=`BOOT_MODE0`，`x` 表示无关位）；FRDM i.MX 95 PRO（19x19）程序按 `SW4` 提示，待板子手册确认。`SW5` 是电源开关。
- 表内 4 位短写与 `SW1 = x 0 0 1` 等价，顺序为拨码块从高位到低位。

### 7.2 下载口 / 调试口 / 电源 / rework

| 板卡 | 芯片 | 下载口 | 调试串口 | 电源 | rework |
| --- | --- | --- | --- | --- | --- |
| FRDM i.MX 95 PRO（19x19） | MX95 | J3（USB1） | J1（CH344，四路 COM，待确认） | J25 | ? |
| i.MX 95 EVK（19x19） | MX95 | ? | ? | ? | ? |
| FRDM i.MX 95（15x15） | MX95 | J3（USB1） | J1（CH344，四路 COM） | J25（USB-PD，开关 SW5） | ? |
| i.MX 95 EVK（15x15） | MX95 | ? | ? | ? | ? |
| FRDM i.MX 91（11x11） | MX91 | P2（USB 2.0 Type-C） | P16（CH342F，两路 COM） | ? | 板卡页标 Rework Needed（M.2 Key E / 显示 / 摄像头，详见板卡页） |
| FRDM i.MX 91S | MX91 | J5（USB1） | J11（CH342F，两路 COM） | J1 | ? |
| i.MX 91 EVK（11x11） | MX91 | ? | ? | ? | ? |
| FRDM i.MX 93 | MX93 | P2（USB1，USB 2.0 Type-C） | P16（CH342F，两路 COM） | P1 | 无（QSPI 启动需改基础板，见 `维修方案知识库.md` §1） |
| i.MX 93 EVK | MX93 | ? | ? | ? | QSPI NOR 启动需 DNP R922 + 装 R950（见 `维修方案知识库.md` §1） |
| FRDM i.MX 8M Plus | MX865 | J3（USB3.0 OTG） | J19（CH342F，两路 COM） | J2（USB-PD） | ? |
| i.MX 8M Plus EVK | MX865 | ? | ? | ? | ? |

### 7.3 整卡 wic 可用性

块设备（SD / eMMC / NVMe）一般有整卡 wic，可整卡烧；QSPI NOR 一般没有（太小），只烧 Bootloader；NAND / SPI NAND 看 BSP 有没有给 UBI 镜像。

| 板卡 | 芯片 | SD | eMMC | NAND | QSPI NOR | SPI NAND | NVMe |
| --- | --- | --- | --- | --- | --- | --- | --- |
| FRDM i.MX 95 PRO（19x19） | MX95 | ✅（实测） | ? | ? | ? | ? | ? |
| i.MX 95 EVK（19x19） | MX95 | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 95（15x15） | MX95 | ? | ? | ? | ? | ? | ? |
| i.MX 95 EVK（15x15） | MX95 | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 91（11x11） | MX91 | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 91S | MX91 | ? | ? | ? | ? | ? | ? |
| i.MX 91 EVK（11x11） | MX91 | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 93 | MX93 | ? | ? | ? | ? | ? | ? |
| i.MX 93 EVK | MX93 | ? | ? | ? | ? | ? | ? |
| FRDM i.MX 8M Plus | MX865 | ? | ? | ? | ? | ? | ? |
| i.MX 8M Plus EVK | MX865 | ? | ? | ? | ? | ? | ? |

注：`✅` = 官方 BSP 包里有 `imx-image-*.wic`（可整卡烧）；`?` = 待下包确认；`—` = 该介质不适用。
