# uuu 功能说明（读源码整理）

来源：NXP 官方 uuu 源码（github.com/nxp-imx/mfgtools，master），对照本机 `uuu.exe -H` 输出。
本机版本：`libuuu_1.5.243-0-g230f1b1`。
说明：本文只写 uuu 自己支持的功能，以及哪些参数是动态的（运行时才确定）。引用处均为 uuu 源码或 uuu 自身帮助文本。

---

## 1. 命令行参数

| 参数 | uuu 官方说明 | 我们程序是否使用 |
| --- | --- | --- |
| `<bootloader\|cmdlists\|cmd>` | 位置参数：bootloader 文件 / 命令表文件或目录或 zip / 单条命令 | 不使用（我们用 -b） |
| `-b` / `-brun <script> arg...` | 运行内置脚本，或用外部 .lst 文件当脚本 | 使用：`-b sd_all <bootloader> <wic>`、`-b scripts/verify_sd.lst <wic>` |
| `-bshow <script>` | 打印内置脚本内容 | 不使用 |
| `-lsusb` | 列出已连接的已知设备 | 使用（检测设备） |
| `-d` | 守护模式，永久等待 | 不使用 |
| `-v` / `-V` | 详细输出 / 加 libusb 错误信息 | 不使用（输出已足够） |
| `-dry` | 试运行：只检查脚本或命令是否正确，不动硬件 | 开发时用过（校验脚本语法） |
| `-t <秒>` | 等待「已知 USB 设备出现」的超时 | 使用（配置里的 timeout） |
| `-T <秒>` | 等待「下一个已知 USB 设备出现」的超时（阶段切换） | 使用（与 -t 同值） |
| `-e <key=value>` | 设置环境变量 | 不使用 |
| `-m <usbpath>` | 只监视指定 USB 路径（如 -m 1:2） | 不使用 |
| `-ms <serial>` | 只监视指定序列号前缀的设备 | 不使用 |
| `-pp <ms>` | USB 轮询周期 | 不使用 |
| `-dm` | 关闭小内存模式 | 不使用 |
| `-s` | shell 交互模式 | 不使用 |
| `-bmap` / `-no-bmap` | 强制使用 / 忽略 .bmap 文件 | 不使用（我们整卡镜像，不用 bmap） |
| `-force-ctrl` | 强制 HID 用控制端点传输 | 不使用 |
| `-udev` | Linux：打印 udev 规则（免 sudo） | 不使用（我们只做 Windows） |
| `-IgSerNum` | Windows：设置注册表忽略 USB 序列号 | 不使用 |
| `-h` / `-H` | 帮助 / 帮助+命令详情 | 不使用 |
| `-autocomplete` | PowerShell 命令补全（隐藏参数） | 不使用 |

---

## 2. 内置脚本（uuu -b <名字>）

uuu 自带 10 个内置脚本，`uuu -b <名字> arg...` 直接调用，`uuu -bshow <名字>` 可打印内容：

| 脚本 | 作用 | 参数 |
| --- | --- | --- |
| `sd_all` | 把整卡镜像烧到 SD 卡 | arg0 `_flash.bin` Bootloader；arg1 `_image` wic 镜像（可选，默认与 arg0 相同） |
| `emmc_all` | 把整卡镜像烧到 eMMC | 同上 |
| `nvme_all` | 把整卡镜像烧到 NVMe | 同上 |
| `sd` | 只把 Bootloader 烧到 SD 卡 | arg0 `_flash.bin`；arg1 `_image` 可选 |
| `emmc` | 只把 Bootloader 烧到 eMMC boot 分区 | 同上 |
| `nand` | 只把 Bootloader 烧到 NAND | 同上 |
| `qspi` | 只把 Bootloader 烧到 QSPI NOR | arg0 `_flexspi.bin`；arg1 可选 |
| `spi_nand` | 只把 Bootloader 烧到 SPI NAND | 同上 |
| `fat_write` | 更新 FAT 分区里的一个文件（需板子已在 Fastboot） | arg0 文件；arg1 设备（mmc/sata）；arg2 分区号；arg3 目标文件名（可选） |
| `spl` | 只引导 SPL 和 U-Boot（不写存储） | arg0 `_flash.bin` |

我们用的就是按介质选的内置脚本（`sd_all` / `emmc_all` / `nand` …，以及写 FAT 分区单文件的 `fat_write`）和我们自己写的 `verify_sd.lst` / `verify_emmc.lst` / `list_parts.lst`（见第 5 节）。

补充：uuu 内置脚本是**按芯片族通用**的，没有任何一块板子自带内置脚本。板子特有的流程（如 Android 的 `uuu_imx_android_flash.bat`、NAND UBI）由 BSP 包另外附带外部脚本，用 `-b <外部文件>` 也能跑。

### 2.1 sd_all 脚本实际内容（uuu -bshow sd_all，本机实测输出）

```
SDP: boot -f _flash.bin -scanlimited 0x800000
SDPS: boot -scanterm -f _flash.bin -scanlimited 0x800000
SDPU: delay 1000
SDPU: write -f _flash.bin -offset 0x57c00 -scanlimited 0x800000
SDPU: jump -scanlimited 0x800000
SDPV: delay 1000
SDPV: write -f _flash.bin -skipspl -scanterm -scanlimited 0x800000
SDPV: jump -scanlimited 0x800000
FB: ucmd setenv fastboot_dev mmc
FB: ucmd setenv mmcdev ${sd_dev}
FB: ucmd mmc dev ${sd_dev}
FB: flash -raw2sparse all _image
FB: flash -scanterm -scanlimited 0x800000 bootloader _flash.bin
FB: done
```

要点：
- 前 4 组（SDP/SDPS/SDPU/SDPV）都是「把 Bootloader 送进内存并跳转」，按芯片自动跳过不支持的协议。i.MX95 走 SDPS/SDPV。
- `-scanlimited 0x800000`：只在前 8MB 里扫描 Bootloader 容器，写到它内部记录的偏移。
- `FB: flash -raw2sparse all _image`：把整卡镜像按稀疏格式写到存储的 0 号位置（整盘）。
- **脚本最后没有重启命令**：烧完板子停在 Fastboot，这就是我们「读回校验」「重启设备」两个按钮的适用状态。

---

## 3. 协议与命令（uuu -H 输出整理）

### ALL（所有协议都支持）

| 命令 | 说明 |
| --- | --- |
| `done` | 整个流程的最后一条命令 |
| `delay <ms>` | 延时 |
| `sh` / `shell <命令>` | 执行主机 shell 命令 |
| `< <命令>` | 用主机 shell 命令的输出当 uuu 命令（量产写序列号等） |

### CFG（按 vid/pid 配置设备）

`SDPS|SDP|FB|Fastboot|FBK -chip <名字> -pid <pid> -vid <vid> [-bcdversion <版本>]`

### SDPS（MX8QXPB0 之后的流下载）

`boot -f <文件> [-offset 0x0000]`

### SDP（iMX6/iMX7 HID 下载协议）

`dcd -f <文件>`；`write -f <文件> [-addr 0x000000] [-ivt 0]`；`jump -f <文件> [-ivt 0]`；`boot -f <文件> [-nojump]`；`rdmem -addr <地址> -format <8|16|32>`；`wrmem -addr <地址> -format <8|16|32> -value <值>`

### FB[-t 超时ms]（Android Fastboot 协议）

| 命令 | 说明 |
| --- | --- |
| `getvar <变量>` | 读板子变量 |
| `ucmd <u-boot 命令>` | 在板子上执行 u-boot 命令并等它结束 |
| `acmd <不会返回的 u-boot 命令>` | 如 booti、reboot；不等结果 |
| `flash [-raw2sparse [{-no-bmap\|-bmap <bmap文件}]] <分区> <文件>` | 烧写；-raw2sparse = 原始镜像转稀疏格式 |
| `flash -scanterm -scanlimited 0x800000 bootloader <文件>` | 按 Bootloader 容器内部偏移烧写（前 8MB 内扫描） |
| `download -f <文件>` | 把文件传到板子内存 |
| `crc -f <文件> [-format "mmc read $loadaddr"] [-blksz 512] [-each 0x4000000] [-seek 0] [-skip 0] [-nostop]` | 从存储读回，逐段比对 CRC32；seek = 跳过存储的字节数，skip = 跳过文件的字节数，each = 每次比对大小，nostop = 不一致也继续 |
| `write -f <文件> [-format "mmc write $loadaddr"] [-blksz 512] [-each 0x4000000] [-seek 0] [-skip 0] [-nostop]` | 把文件写到存储（download + mmc write 的封装） |
| `reboot` | 让板子重启（fastboot 协议 reboot） |
| `oem ...`、`set_active`、`boot`、`continue`、`update-super`、`create/delete/resize-logical-partition` | Android 相关，我们不用 |

### FBK（社区内核的 fastboot 变体，不兼容 fastboot 工具）

`ucmd <内核命令>`（等结束）；`acmd <内核命令>`（不等）；`sync`（等 acmd 结束）；`ucp <源> <目标>`（传文件，T: 前缀表示板子侧）。

---

## 4. 哪些参数是动态的（运行时才确定）

| 动态参数 | 怎么来的 | 例子 |
| --- | --- | --- |
| 脚本位置参数 `_flash.bin`、`_image` | 命令行按顺序替换脚本里的占位名 | `uuu -b sd_all flash.bin image.wic` |
| 可选参数 `[_flash.bin]` | 脚本里写 `# @_image [_flash.bin]`，不传时用 `_flash.bin` 的值 | sd_all 的 arg1 可选 |
| 环境变量 `${sd_dev}`、`${emmc_dev}` | 不是 uuu 替换，是传给板子后由 u-boot 自己展开 | `FB: ucmd mmc dev ${sd_dev}` → 板子上变成 `mmc dev 1` |
| `-e key=value` | 主机侧设置环境变量给 uuu 用 | `uuu -e x=1 ...` |
| `@off`、`@size` | `FB: crc` / `FB: write` 内部循环时替换成块偏移和块数 | 源码 `FBLoop::build_cmd` |
| `$loadaddr` | u-boot 自己的变量（内存地址） | `mmc read $loadaddr` |
| 超时 `-t`、`-T` | 命令行传入，单位秒 | 我们配置默认 30 |
| 外部脚本文件路径 | `-b` 后面不是内置名时按文件加载 | 我们写 `scripts/verify_sd.lst` |

---

## 5. 外部脚本文件格式（我们自己写的 verify_<介质>.lst）

uuu 对 `-b` 的处理（源码 `uuu.cpp`）：先查内置脚本，找不到就把参数当文件读，读到的内容做参数替换后执行。格式：

```
uuu_version 1.5.243

# @_image                | wic image to verify (read back and compare CRC32)

FB: ucmd setenv fastboot_dev mmc
FB: ucmd setenv mmcdev ${sd_dev}
FB: ucmd mmc dev ${sd_dev}
FB: crc -f _image -seek 0x800000 -skip 0x800000
FB: done
```

读回校验目前只做 mmc 块设备：SD 用 `verify_sd.lst`（`${sd_dev}`），eMMC 用 `verify_emmc.lst`（`${emmc_dev}`）；NAND / QSPI / SPI NAND / NVMe 暂不支持读回。

界面「脚本」下拉就基于这个机制：默认用 cfg 里该介质的内置脚本，也可以选「自定义脚本文件…」指定外部 `.lst`（如 NAND 整包 UBI/UBIFS 脚本），`-b` 后按脚本声明的参数顺序传文件。

- 第一行 `uuu_version` 是脚本要求的最低 uuu 版本。
- `# @_image | 描述` 声明一个位置参数，运行时用命令行第一个参数替换。
- `#` 开头是注释。
- 其余每行是一条命令，格式 `协议: 命令 参数`。

---

## 6. 我们程序实际用到的 uuu 功能

| 我们界面上的功能 | 实际执行的 uuu | 说明 |
| --- | --- | --- |
| 检测设备 | `uuu -lsusb` | 输出解析成 芯片/协议/Vid/Pid |
| 开始烧录 | `uuu -t 30 -T 30 -b <脚本> <bootloader> [<wic>]` | 按介质选内置脚本（sd_all/emmc_all/nand/…），见 2.1 |
| 读回校验（CRC） | `uuu -t 30 -b <数据目录>/scripts/verify_sd.lst <wic>` | 见第 5 节；跳过前 8MB 启动区 |
| 重启设备 | `uuu -t 30 FB: reboot` | fastboot 协议 reboot，板子回 OKAY 后重启 |
| 取消 | 给 uuu 发 Ctrl+Break（Windows） | 源码 ctrl_c_handle |

### 6.1 为什么读回校验跳过前 8MB（实测依据）

- 烧录脚本 `sd_all` 把 wic 整卡写进去后，又单独用 `flash -scanlimited 0x800000 bootloader` 把 Bootloader 写到前 8MB 里。
- 实测（对比官方包里的 wic 和 Bootloader 文件）：wic 里自带的 Bootloader 和单独烧的 Bootloader 在 0x8000 之后有约 2MB 不一致。
- 所以校验从前 8MB 之后开始（`-seek 0x800000 -skip 0x800000`），这一段是 wic 原样写入的，能确定一致；前 8MB 是启动区，不参与比对。

---

## 7. uuu 有但我们不用的功能（原因）

| 功能 | 为什么不用的 |
| --- | --- |
| 量产/多设备（-d、-m、-ms、多板并行） | 第一阶段只做单板 |
| 无 | NAND/QSPI/SPI NAND/NVMe 目标现在都做 |
| FBK 协议（社区内核） | NXP 官方 BSP 用 FB |
| SDP rdmem/wrmem（读/写内存） | 与烧卡无关 |
| `.bmap` 稀疏映射 | 整卡 raw2sparse 全映射，不需要 |
| shell 模式 `-s`、守护模式 `-d` | 图形界面点击即用 |
| 签名/加密相关（SecureBootTool 等，属 NXP 其他工具） | 不在本工具范围 |
