# uuu 脚本真机验证记录

> 板卡：FRDM-IMX95-PRO（MX95 SDPS 0x1FC9:015D，序列号 09A2B8C344224298）
> uuu 版本：libuuu_1.5.243-0f230f1b1（build/uuu.exe，锁定版本）
> 验证日期：2026-11-16
> 用途：ScriptBuilder / UUUAdapter 的设计依据。以下结论**全部来自真机实测**，非文档推测。

---

## 结论速查

| # | 结论 | 影响 |
|---|---|---|
| 1 | **`-b <脚本文件> <arg0> <arg1>` 可跑自定义脚本** ⭐ | 推荐方式；arg0→`_flash.bin`，arg1→`_image` 自动替换 |
| 2 | **`-c` 参数不存在** | 别用 `-c` |
| 3 | **脚本首行必须是 `uuu_version <ver>`** | 否则 uuu 不认脚本，把文件当 bootloader 下载 → 板子崩 |
| 4 | **路径含空格：参数传 OK，写死在脚本里不行** ⭐ | 见下 |
| 5 | **`>` 前缀 + 正斜杠绝对路径也可用** | 若脚本内写死路径，用 `>C:/path` 形式 |
| 6 | **USB 链路慢** | 2.9MB bootloader 传 25s+；13GB wic 约 1093s（18min） |
| 7 | **`-t/-T` 不控制传输超时** | 它只管"等设备出现"；SDPS 的 HID 传输有独立的 ~20s 内部超时 |

## ⭐ 4. 空格路径：区分"参数"与"脚本内"

**决定性证据（`-dry`）**：

```
# 路径作为 -b 的参数（arg1 含空格）→ uuu 自动加引号，OK
$ uuu -dry -b s.auto boot.bin "C:/.../my images/img.wic"
FB: flash -raw2sparse all "C:/.../my images/img.wic"     ← 自动加引号，正常

# 路径写死在脚本里（含空格）→ 失败
FB: flash -raw2sparse all C:/.../my images/img.wic
Error: FB: image file not found
```

**并且 11/11 的实际成功烧录证明**：GUI 用 `-b` 传参、wic 路径含空格（`Downloads/LF_v6.18.20-2.0.0_images_IMX95EVK (1)/`），**完整成功**（`Okay (1093s)` + `FB: done`）。

**结论**：
- 路径作为**命令行参数** → 含空格 **OK**（uuu 自动加引号）
- 路径**写死在脚本文件内** → 含空格 **失败**

**因此 ScriptBuilder 的正确设计是：脚本保留占位符（`_flash.bin`/`_image`），路径由 `-b` 参数传入。** 这与现有 TaskManager 代码一致，也天然规避空格问题。


## ⭐ 0. 首选方式：`-b <脚本文件> <arg0> <arg1>`（uuu 自己做占位符替换）

真机验证（`-dry`）：

```
$ uuu -dry -b btest2/t.auto "C:/BOOTLOADER_ARG.bin" "C:/IMAGE_ARG.wic"
SDPS: boot -scanterm -f C:/BOOTLOADER_ARG.bin -scanlimited 0x800000   ← _flash.bin 被 arg0 替换
FB: flash -raw2sparse all C:/IMAGE_ARG.wic                             ← _image 被 arg1 替换
FB: flash bootloader C:/BOOTLOADER_ARG.bin                             ← 同一 arg0
FB: done
```

**含义（重要）**：
- 脚本可以**静态存放**（占位符不替换），路径运行时由 `-b` 参数传入 → ScriptBuilder 不必把路径写死进脚本
- **完全兼容现有代码**：`TaskManager` 已在用 `-b <scriptPath> <image>`，方向正确
- 占位符约定：`_flash.bin` = arg0（bootloader），`_image` = arg1（镜像）


---

## 1. `-c` 参数不存在

```
$ uuu -c test_boot.auto
Unknown option: -c
```

`uuu` 的 help（`uuu` 无参运行）显示的正确用法：

```
uuu [-d -m -v -V -bmap -no-bmap] <bootloader|cmdlists|cmd>
    bootloader      download bootloader to board by usb
    cmdlist         run all commands in cmdlist file
                    If it is path, search uuu.auto in dir
                    If it is zip, search uuu.auto in zip
    cmd             Run one command, use -H see detail
```

**即：位置参数传"目录"，uuu 在目录里找固定名 `uuu.auto`。**

## 2. 脚本必须命名 `uuu.auto` 并传目录

传 `.auto` 文件（非 `uuu.auto` 名）时，uuu **把它当 bootloader 下载**：

```
$ uuu test_boot.auto        # 危险！把脚本文件当 bootloader 灌进板子
2:3-...>Start Cmd:SDPS: boot -f "test_boot.auto"   ← 下载的是脚本文件本身
```

正确：`uuu <目录>`，目录内 `uuu.auto`。

## 3. 首行必须是 `uuu_version`（关键！）

首行是 `#` 注释时，uuu **不认这是脚本**，同样走"当 bootloader 下载"的路径，**会把板子搞崩**（实测崩了两次，需断电重启恢复）。

必须：
```
uuu_version 1.4.149
# 注释/可追溯信息放在其后
SDPS: boot ...
```

**因此 ScriptBuilder::buildAndSave 的可追溯头（generated_by/at）必须放在 `uuu_version` 之后，不能放文件最前。** 已修复。

## 4. `>` 绝对路径前缀可用

```
SDPS: boot -scanterm -f >C:/dev/.../boot.bin -scanlimited 0x800000
→ 3%...88%（正常传输，路径解析成功）
```

uuu 在 PC 侧正确打开并读取了文件。`>` = 脚本内绝对路径标记（相对脚本目录的默认行为需覆盖时使用），路径用**正斜杠**。

## 5. 路径不能含空格（重要约束）

`-dry` 干跑模式可复现（不用真烧）：

| 写法 | 结果 |
|---|---|
| A `>C:/no-space/real.wic` | ✅ 正常解析 |
| B `>C:/my dir/real.wic` | ❌ `FB: image file not found` |
| C `>"C:/my dir/real.wic"` | ❌ 同样失败 |
| D `"C:/my dir/real.wic"`（无 >） | ❌ 同样失败 |

**结论：uuu 脚本解析器不支持含空格的路径，`>` 和引号都无效。**

⚠️ 实际影响：NXP 官方镜像默认解压路径常是 `OneDrive - NXP/...` 或 `Downloads/... (1)/`，**都含空格**。
- ScriptBuilder 已在 `build()` 阶段拦截并报错，提示用户移到无空格目录
- 使用手册需写明"镜像路径不要含空格"

## 6. USB 链路速度

| 传输 | 大小 | 耗时 |
|---|---|---|
| SDPS bootloader | 2.9 MB | 25s+（88% 时 20s 超时中断） |
| FB wic（11/11 日志） | 13 GB | 1093s ≈ 18 分钟 |

**超时值需放大**：UUUAdapter 默认 30s 对 SDPS 阶段就偏紧，FB 阶段要 1200s+。

---

## 待办（真机结论驱动）

1. ~~`UUUAdapter::start()` 改用目录方式~~ → **不需要**：现有 `-b <脚本文件> <args>` 已验证可用且更优
2. ~~超时默认值调整~~ → **修正**：`-t/-T` 只控制"等设备出现"，不控制传输超时。UUUAdapter 的 `-t/-T` 用法没错，但**别指望它解决传输慢**。SDPS HID 传输有独立 ~20s 内部超时，链路慢时可能不够（实测 2.9MB 传到 88% 用了 25s）。
3. 使用手册增加"**镜像路径不含空格**"说明（NXP 默认下载路径常含空格，必踩）
4. ScriptBuilder 设计调整：既然 `-b` 会做占位符替换，**脚本可静态化**，不必把路径写死进脚本
   - 当前 `buildAndSave` 把绝对路径写进了脚本（`>` 形式）——真机上"无空格路径"可用，但与 `-b` 占位符机制重复
   - 两种方案二选一：① 脚本留占位符 + `-b` 传参（推荐，路径不进脚本）② 脚本写死 `>` 路径（要求无空格）
   - **倾向 ①**：与现有 TaskManager 代码一致，且脚本可复用/可 diff

## 对 ScriptBuilder 当前实现的修正意见

- `buildAndSave` 目前把路径替换进脚本文本 → 建议改为**保留占位符**，由 `-b` 参数传路径
- 文件名 `sd_all.auto` 无所谓（`-b` 接任意文件名都行，只有"目录方式"才要求 `uuu.auto`）
- 空格校验保留（`-b` 的 arg 是否也受空格影响未验证，保守起见仍拦截）

---

## 测试环境备注

- `-dry` 干跑模式：校验脚本语法 + 路径解析，**不碰板子**，用于快速验证（本次发现 5 就是靠它）
- 本测试 exe 是 GUI 子系统程序，stdout 重定向无效，QtTest 结果要用 `-o <file>` 落盘
