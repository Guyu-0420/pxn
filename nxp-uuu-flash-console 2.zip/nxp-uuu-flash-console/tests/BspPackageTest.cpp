#include "task/BspPackage.h"

#include <QBuffer>
#include <QDataStream>
#include <QDir>
#include <QFile>
#include <QTemporaryDir>
#include <QtTest>

namespace {

void putU16(QByteArray* out, quint16 value)
{
    out->append(static_cast<char>(value & 0xff));
    out->append(static_cast<char>((value >> 8) & 0xff));
}

void putU32(QByteArray* out, quint32 value)
{
    putU16(out, static_cast<quint16>(value & 0xffff));
    putU16(out, static_cast<quint16>((value >> 16) & 0xffff));
}

// 造一个最小的 zip（全部 stored），用来验证目录区解析。
QByteArray makeZip(const QStringList& names, const QList<QByteArray>& contents)
{
    QByteArray out;
    QList<quint32> offsets;
    for (int i = 0; i < names.size(); ++i) {
        const QByteArray name = names.at(i).toUtf8();
        const QByteArray body = contents.at(i);
        offsets.append(static_cast<quint32>(out.size()));
        putU32(&out, 0x04034b50);
        putU16(&out, 20);
        putU16(&out, 0);
        putU16(&out, 0);
        putU16(&out, 0);
        putU16(&out, 0);
        putU32(&out, 0);
        putU32(&out, static_cast<quint32>(body.size()));
        putU32(&out, static_cast<quint32>(body.size()));
        putU16(&out, static_cast<quint16>(name.size()));
        putU16(&out, 0);
        out.append(name);
        out.append(body);
    }

    const quint32 directoryOffset = static_cast<quint32>(out.size());
    for (int i = 0; i < names.size(); ++i) {
        const QByteArray name = names.at(i).toUtf8();
        const QByteArray body = contents.at(i);
        putU32(&out, 0x02014b50);
        putU16(&out, 20);
        putU16(&out, 20);
        putU16(&out, 0);
        putU16(&out, 0);
        putU16(&out, 0);
        putU16(&out, 0);
        putU32(&out, 0);
        putU32(&out, static_cast<quint32>(body.size()));
        putU32(&out, static_cast<quint32>(body.size()));
        putU16(&out, static_cast<quint16>(name.size()));
        putU16(&out, 0);
        putU16(&out, 0);
        putU16(&out, 0);
        putU16(&out, 0);
        putU32(&out, 0);
        putU32(&out, offsets.at(i));
        out.append(name);
    }

    const quint32 directorySize = static_cast<quint32>(out.size()) - directoryOffset;
    putU32(&out, 0x06054b50);
    putU16(&out, 0);
    putU16(&out, 0);
    putU16(&out, static_cast<quint16>(names.size()));
    putU16(&out, static_cast<quint16>(names.size()));
    putU32(&out, directorySize);
    putU32(&out, directoryOffset);
    putU16(&out, 0);
    return out;
}

QVector<BspZipEntry> sampleEntries()
{
    QVector<BspZipEntry> entries;
    const QStringList names = {
        QStringLiteral("imx-image-full-imx95evk.wic"),
        QStringLiteral("imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55"),
        QStringLiteral("imx-boot-imx95-19x19-lpddr5-evk-sd.bin-flash_a55"),
        QStringLiteral("cve/imx/report.pdf")
    };
    for (const QString& name : names) {
        BspZipEntry entry;
        entry.name = name;
        entry.size = 4096;
        entries.push_back(entry);
    }
    return entries;
}

} // namespace

class BspPackageTest : public QObject {
    Q_OBJECT

private slots:
    void infersVersionFromZipName();
    void infersVersionFromFolder();
    void ignoresNameWithoutVersion();
    void readsZipEntries();
    void selectsImagesForBoard();
    void failsWhenBootloaderMissing();
    void failsWhenImageMissing();
    void listsBootloaderCandidates();
    void picksNamedImageVariant();
    void listsImageCandidates();
    void recognizesFlashBinBootloader();
};

void BspPackageTest::infersVersionFromZipName()
{
    QCOMPARE(BspPackage::inferVersion(
                 QStringLiteral("C:/Downloads/LF_v6.18.20-2.0.0_images_IMX95EVK.zip")),
             QStringLiteral("6.18.20-2.0.0"));
}

void BspPackageTest::infersVersionFromFolder()
{
    QCOMPARE(BspPackage::inferVersion(
                 QStringLiteral("C:\\img\\LF_v6.18.20-2.0.0_images_IMX95EVK\\"
                                 "imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55")),
             QStringLiteral("6.18.20-2.0.0"));
}

void BspPackageTest::ignoresNameWithoutVersion()
{
    QVERIFY(BspPackage::inferVersion(
                 QStringLiteral("imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55"))
                .isEmpty());
    QVERIFY(BspPackage::inferVersion(QString()).isEmpty());
}

void BspPackageTest::readsZipEntries()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const QString path = QDir(dir.path()).filePath(QStringLiteral("images.zip"));
    QFile file(path);
    QVERIFY(file.open(QIODevice::WriteOnly));
    const QList<QByteArray> bodies = { QByteArray(10, 'a'), QByteArray(20, 'b') };
    file.write(makeZip({ QStringLiteral("a.wic"), QStringLiteral("b.bin") }, bodies));
    file.close();

    QVector<BspZipEntry> entries;
    QString error;
    QVERIFY(BspPackage::readEntries(path, &entries, &error));
    QVERIFY(error.isEmpty());
    QCOMPARE(entries.size(), 2);
    QCOMPARE(entries.at(0).name, QStringLiteral("a.wic"));
    QCOMPARE(entries.at(0).size, quint64(10));
    QCOMPARE(entries.at(1).name, QStringLiteral("b.bin"));
    QCOMPARE(entries.at(1).size, quint64(20));
}

void BspPackageTest::selectsImagesForBoard()
{
    QString bootloader;
    QString linuxImage;
    QString error;
    QVERIFY(BspPackage::selectImages(
        sampleEntries(),
        QStringLiteral("imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55"),
        QString(),
        &bootloader, &linuxImage, &error));
    QCOMPARE(bootloader, QStringLiteral("imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55"));
    QCOMPARE(linuxImage, QStringLiteral("imx-image-full-imx95evk.wic"));
}

void BspPackageTest::failsWhenBootloaderMissing()
{
    QString bootloader;
    QString linuxImage;
    QString error;
    QVERIFY(!BspPackage::selectImages(sampleEntries(), QStringLiteral("not-there.bin"),
                                       QString(),
                                       &bootloader, &linuxImage, &error));
    QVERIFY(!error.isEmpty());
}

void BspPackageTest::failsWhenImageMissing()
{
    QVector<BspZipEntry> entries;
    BspZipEntry entry;
    entry.name = QStringLiteral("imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55");
    entry.size = 1024;
    entries.push_back(entry);

    QString bootloader;
    QString linuxImage;
    QString error;
    QVERIFY(!BspPackage::selectImages(entries,
        QStringLiteral("imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55"),
        QString(),
        &bootloader, &linuxImage, &error));
    QVERIFY(!error.isEmpty());
}

void BspPackageTest::listsBootloaderCandidates()
{
    const QStringList candidates = BspPackage::bootloaderCandidates(sampleEntries());
    QCOMPARE(candidates.size(), 2);
    QVERIFY(candidates.contains(
        QStringLiteral("imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55")));
    QVERIFY(candidates.contains(
        QStringLiteral("imx-boot-imx95-19x19-lpddr5-evk-sd.bin-flash_a55")));
    QVERIFY(!candidates.contains(QStringLiteral("cve/imx/report.pdf")));
}

void BspPackageTest::picksNamedImageVariant()
{
    QVector<BspZipEntry> entries;
    const QStringList names = {
        QStringLiteral("imx-boot-frdm.bin-flash_a55"),
        QStringLiteral("imx-image-full-imx95evk.wic"),
        QStringLiteral("imx-image-multimedia-imx95evk.wic")
    };
    for (const QString& name : names) {
        BspZipEntry entry;
        entry.name = name;
        entry.size = 4096;
        entries.push_back(entry);
    }

    QString bootloader;
    QString linuxImage;
    QString error;
    QVERIFY(BspPackage::selectImages(entries, QStringLiteral("imx-boot-frdm.bin-flash_a55"),
        QStringLiteral("imx-image-multimedia-imx95evk.wic"),
        &bootloader, &linuxImage, &error));
    QCOMPARE(linuxImage, QStringLiteral("imx-image-multimedia-imx95evk.wic"));
}

void BspPackageTest::listsImageCandidates()
{
    QVector<BspZipEntry> entries;
    const QStringList names = {
        QStringLiteral("imx-image-full-imx95evk.wic"),
        QStringLiteral("imx-image-full-imx95evk.wic.zst"),
        QStringLiteral("readme.txt"),
        QStringLiteral("imx-boot-frdm.bin-flash_a55")
    };
    for (const QString& name : names) {
        BspZipEntry entry;
        entry.name = name;
        entry.size = 4096;
        entries.push_back(entry);
    }

    const QStringList images = BspPackage::imageCandidates(entries);
    QCOMPARE(images.size(), 2);
    QVERIFY(images.contains(QStringLiteral("imx-image-full-imx95evk.wic")));
    QVERIFY(images.contains(QStringLiteral("imx-image-full-imx95evk.wic.zst")));
    QVERIFY(!images.contains(QStringLiteral("imx-boot-frdm.bin-flash_a55")));
}

void BspPackageTest::recognizesFlashBinBootloader()
{
    QVector<BspZipEntry> entries;
    const QStringList names = {
        QStringLiteral("flash.bin"),
        QStringLiteral("myboard-flash.bin"),
        QStringLiteral("imx-image-full-imx95evk.wic")
    };
    for (const QString& name : names) {
        BspZipEntry entry;
        entry.name = name;
        entry.size = 4096;
        entries.push_back(entry);
    }

    const QStringList boots = BspPackage::bootloaderCandidates(entries);
    QCOMPARE(boots.size(), 2);
    QVERIFY(boots.contains(QStringLiteral("flash.bin")));
    QVERIFY(boots.contains(QStringLiteral("myboard-flash.bin")));
}

QTEST_MAIN(BspPackageTest)
#include "BspPackageTest.moc"
