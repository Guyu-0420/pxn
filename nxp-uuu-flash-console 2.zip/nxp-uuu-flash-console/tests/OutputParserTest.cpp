#include "uuu/OutputParser.h"

#include <QtTest>

class OutputParserTest : public QObject {
    Q_OBJECT

private slots:
    void emptyLsusbOutputHasNoDevices();
    void parsesLsusbDevice();
    void zeroSummaryFrameHasNoEvidence();
    void parsesSuccessfulSummary();
    void parsesFailureSummary();
    void onlyParsesProgressBarPercentages();
    void parsesRealEmptyLsusbOutput();
    void parsesRealDeviceRow();
    void permissionLineHasPermissionEvidence();
    void verifyLineHasVerifyEvidence();
    void flashErrorTextMatchesDoc();
    void stripsProtocolColon();
    void parsesFastbootRowWithEmptyChip();
    void parsesMmcPartsDosTable();
    void parsesMmcPartsGptHasNoFatType();
    void emptyMmcPartsHasNoPartitions();
};

void OutputParserTest::emptyLsusbOutputHasNoDevices()
{
    QCOMPARE(OutputParser::parseLsusb(QString()).size(), 0);
    QCOMPARE(OutputParser::parseLsusb(QStringLiteral("\r\n")).size(), 0);
}

void OutputParserTest::parsesLsusbDevice()
{
    const auto devices = OutputParser::parseLsusb(QStringLiteral(
        "Path     Chip    Pro     Vid      Pid\n"
        "1:2      MX95    SDPS    0x1fc9  0x0146\n"));

    QCOMPARE(devices.size(), 1);
    QCOMPARE(devices.first().usbPath, QStringLiteral("1:2"));
    QCOMPARE(devices.first().chip, QStringLiteral("MX95"));
    QCOMPARE(devices.first().protocol, QStringLiteral("SDPS"));
    QCOMPARE(devices.first().vid, QStringLiteral("0x1fc9"));
    QCOMPARE(devices.first().pid, QStringLiteral("0x0146"));
}

void OutputParserTest::zeroSummaryFrameHasNoEvidence()
{
    const LineEffect effect = OutputParser::parseLine(QStringLiteral("Success 0  Failure 0"));

    QVERIFY(!effect.matched);
    QVERIFY(!effect.successEvidence);
    QVERIFY(!effect.failureEvidence);
}

void OutputParserTest::parsesSuccessfulSummary()
{
    const LineEffect effect = OutputParser::parseLine(QStringLiteral("Success 1    Failure 0"));

    QVERIFY(effect.matched);
    QVERIFY(effect.successEvidence);
    QVERIFY(!effect.failureEvidence);
    QCOMPARE(effect.stage, TaskStage::Finish);
    QCOMPARE(effect.percent, 100);
}

void OutputParserTest::parsesFailureSummary()
{
    const LineEffect effect = OutputParser::parseLine(QStringLiteral("Success 0    Failure 1"));

    QVERIFY(!effect.matched);
    QVERIFY(!effect.successEvidence);
    QVERIFY(effect.failureEvidence);
}

void OutputParserTest::onlyParsesProgressBarPercentages()
{
    const LineEffect progress = OutputParser::parseLine(QStringLiteral("FB: flash image.bin 58%=>"));
    const LineEffect filename = OutputParser::parseLine(QStringLiteral("FB: flash image-58%.bin"));

    QVERIFY(progress.hasPercent);
    QCOMPARE(progress.percent, 58);
    QVERIFY(!filename.hasPercent);
}

// Captured verbatim from `uuu.exe -lsusb` on Windows: tab separators, CRLF
// endings, an ANSI cursor-restore sequence, and no device row (board not in
// serial-download mode). This is the state the parser sees most often.
void OutputParserTest::parsesRealEmptyLsusbOutput()
{
    const QString real = QStringLiteral(
        "uuu (Universal Update Utility) for nxp imx chips -- libuuu_1.5.243-0-g230f1b1\r\n"
        "\r\n"
        "Your console don't support VT mode, fail back to verbose mode\r\n"
        "Connected Known USB Devices\r\n"
        "\tPath\t Chip\t Pro\t Vid\t Pid\t BcdVersion\t Serial_no\r\n"
        "\t====================================================================\r\n"
        "\x1b[?25h\r\n"
        "\r\n");

    QCOMPARE(OutputParser::parseLsusb(real).size(), 0);
}

// Same real framing, with one MX95 board in serial-download mode.
void OutputParserTest::parsesRealDeviceRow()
{
    const QString real = QStringLiteral(
        "uuu (Universal Update Utility) for nxp imx chips -- libuuu_1.5.243-0-g230f1b1\r\n"
        "Connected Known USB Devices\r\n"
        "\tPath\t Chip\t Pro\t Vid\t Pid\t BcdVersion\t Serial_no\r\n"
        "\t====================================================================\r\n"
        "\t1:2\t MX95\t SDPS\t 0x1fc9\t 0x0146\t 0x0002\t 12345678\r\n"
        "\x1b[?25h\r\n");

    const auto devices = OutputParser::parseLsusb(real);
    QCOMPARE(devices.size(), 1);
    QCOMPARE(devices.first().usbPath, QStringLiteral("1:2"));
    QCOMPARE(devices.first().chip, QStringLiteral("MX95"));
    QCOMPARE(devices.first().protocol, QStringLiteral("SDPS"));
    QCOMPARE(devices.first().vid, QStringLiteral("0x1fc9"));
    QCOMPARE(devices.first().pid, QStringLiteral("0x0146"));
    QVERIFY(isFlashableDevice(devices.first()));
}

void OutputParserTest::permissionLineHasPermissionEvidence()
{
    const LineEffect effect =
        OutputParser::parseLine(QStringLiteral("libusb_open() failed: Access denied"));

    QVERIFY(effect.permissionEvidence);
    QVERIFY(!effect.matched);
}

void OutputParserTest::verifyLineHasVerifyEvidence()
{
    const LineEffect effect =
        OutputParser::parseLine(QStringLiteral("verify failed: hash mismatch"));

    QVERIFY(effect.verifyEvidence);
}

void OutputParserTest::flashErrorTextMatchesDoc()
{
    QCOMPARE(flashErrorText(FlashError::ToolMissing), QStringLiteral("未找到 uuu.exe"));
    QCOMPARE(flashErrorText(FlashError::WrongDevice), QStringLiteral("当前不是串行下载模式（SDPS/SDP）"));
    QCOMPARE(flashErrorText(FlashError::Cancelled), QStringLiteral("已取消"));
    QCOMPARE(flashErrorName(FlashError::WaitFastbootTimeout),
             QStringLiteral("WaitFastbootTimeout"));
    QCOMPARE(flashErrorFromName(QStringLiteral("FlashImageFailed")),
             FlashError::FlashImageFailed);
}

// Captured from `uuu.exe -lsusb` with the FRDM-IMX95-PRO in serial download:
// the Pro column is "SDPS:" with a trailing colon.
void OutputParserTest::stripsProtocolColon()
{
    const QString real = QStringLiteral(
        "uuu (Universal Update Utility) for nxp imx chips -- libuuu_1.5.243-0-g230f1b1\r\n"
        "Connected Known USB Devices\r\n"
        "\tPath\t Chip\t Pro\t Vid\t Pid\t BcdVersion\t Serial_no\r\n"
        "\t====================================================================\r\n"
        "\t2:3\t MX95\t SDPS:\t 0x1FC9\t 0x015D\t 0x0002\t 09A2B8C344224298\r\n");

    const auto devices = OutputParser::parseLsusb(real);
    QCOMPARE(devices.size(), 1);
    QCOMPARE(devices.first().protocol, QStringLiteral("SDPS"));
    QVERIFY(isFlashableDevice(devices.first()));
}

// Captured from `uuu.exe -lsusb` with the board sitting in Fastboot mode:
// the Chip column is empty, so the Pro column shifts left.
void OutputParserTest::parsesFastbootRowWithEmptyChip()
{
    const QString real = QStringLiteral(
        "uuu (Universal Update Utility) for nxp imx chips -- libuuu_1.5.243-0-g230f1b1\r\n"
        "Connected Known USB Devices\r\n"
        "\tPath\t Chip\t Pro\t Vid\t Pid\t BcdVersion\t Serial_no\r\n"
        "\t====================================================================\r\n"
        "\t2:3\t \t FB:\t 0x1FC9\t 0x0152\t 0x7EA4\t 09A2B8C344224298\r\n");

    const auto devices = OutputParser::parseLsusb(real);
    QCOMPARE(devices.size(), 1);
    QCOMPARE(devices.first().usbPath, QStringLiteral("2:3"));
    QVERIFY(devices.first().chip.isEmpty());
    QCOMPARE(devices.first().protocol, QStringLiteral("FB"));
    QCOMPARE(devices.first().vid, QStringLiteral("0x1FC9"));
    QCOMPARE(devices.first().pid, QStringLiteral("0x0152"));
    QVERIFY(!isFlashableDevice(devices.first()));
}

// u-boot `mmc part` on a DOS-partitioned SD card: the boot partition is FAT
// (type 0c), the rootfs is Linux (type 83).
void OutputParserTest::parsesMmcPartsDosTable()
{
    const QString real = QStringLiteral(
        "Partition Map for MMC device 1  --   Partition Type: DOS\r\n"
        "\r\n"
        "Part\tStart Sector\tNum Sectors\tUUID\t\tType\r\n"
        "  1\t16384\t\t262144\t\t12345678-01\t0c Boot\r\n"
        "  2\t278528\t\t1048576\t\t12345678-02\t83\r\n");

    const auto parts = OutputParser::parseMmcParts(real);
    QCOMPARE(parts.size(), 2);
    QCOMPARE(parts.at(0).device, 1);
    QCOMPARE(parts.at(0).number, 1);
    QCOMPARE(parts.at(0).type, QStringLiteral("0c"));
    QVERIFY(parts.at(0).fat);
    QCOMPARE(parts.at(0).id(), QStringLiteral("1:1"));
    QCOMPARE(parts.at(1).type, QStringLiteral("83"));
    QVERIFY(!parts.at(1).fat);

    const auto fat = OutputParser::fatPartitions(parts);
    QCOMPARE(fat.size(), 1);
    QCOMPARE(fat.first().id(), QStringLiteral("1:1"));
}

// GPT tables have no DOS type code, so FAT cannot be detected: fatPartitions
// is empty and the UI falls back to listing every partition.
void OutputParserTest::parsesMmcPartsGptHasNoFatType()
{
    const QString real = QStringLiteral(
        "Partition Map for MMC device 0  --   Partition Type: EFI\r\n"
        "\r\n"
        "Part\tStart LBA\tEnd LBA\t\tName\r\n"
        "  1\t0x00000022\t0x00000c21\t%1boot%1\r\n"
        "  2\t0x00000c22\t0x0001c220\t%1rootfs%1\r\n").arg(QLatin1Char(34));

    const auto parts = OutputParser::parseMmcParts(real);
    QCOMPARE(parts.size(), 2);
    QCOMPARE(parts.at(0).device, 0);
    QCOMPARE(parts.at(0).name, QStringLiteral("boot"));
    QVERIFY(!parts.at(0).fat);
    QCOMPARE(OutputParser::fatPartitions(parts).size(), 0);
}

void OutputParserTest::emptyMmcPartsHasNoPartitions()
{
    QCOMPARE(OutputParser::parseMmcParts(QString()).size(), 0);
    QCOMPARE(OutputParser::fatPartitions({}).size(), 0);
}

QTEST_MAIN(OutputParserTest)
#include "OutputParserTest.moc"
