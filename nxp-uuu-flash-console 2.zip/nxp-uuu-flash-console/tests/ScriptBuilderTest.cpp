#include <QtTest>

#include "uuu/ScriptBuilder.h"

#include <QDir>
#include <QFile>
#include <QStringList>
#include <QTemporaryDir>

namespace {

// 在 dir 下造一个真实存在的文件，返回其路径。build() 会校验文件存在。
QString makeFile(const QString& dir, const QString& name)
{
    const QString p = dir + "/" + name;
    QFile f(p);
    f.open(QIODevice::WriteOnly);
    f.write("x");
    return p;
}

} // namespace

class ScriptBuilderTest : public QObject {
    Q_OBJECT

private slots:
    void sdAll_keepsPlaceholders_andBuildsArgs();
    void sdAll_missingBootloader_fails();
    void disabledMedia_rejects();
    void unknownMedia_fails();
    void spacePathInArgument_ok();
    void buildAndSave_versionFirstLine();
    void featureList_onlySdAllEnabled();
};

// sd_all：脚本保留占位符（路径走 -b 参数），参数顺序 = [bootloader, image]。
void ScriptBuilderTest::sdAll_keepsPlaceholders_andBuildsArgs()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const QString boot = makeFile(dir.path(), "imx-boot.bin");
    const QString image = makeFile(dir.path(), "imx-image.wic");

    ScriptBuilder::BuildOptions opt;
    opt.bootloaderPath = boot;
    opt.linuxImagePath = image;
    opt.media = QStringLiteral("sd_all");

    ScriptBuilder::BuildResult r;
    QString error;
    QVERIFY2(opt.build(&r, &error), qPrintable(error));

    // 脚本必须保留占位符（真机验证：路径由 uuu 的 -b 参数替换）
    QVERIFY(r.scriptText.contains("_flash.bin"));
    QVERIFY(r.scriptText.contains("_image"));
    // 路径不能出现在脚本里
    QVERIFY(!r.scriptText.contains(boot));
    QVERIFY(!r.scriptText.contains(image));
    // 首行 uuu_version
    QVERIFY(r.scriptText.startsWith("uuu_version"));

    // 参数：arg0=bootloader, arg1=image（顺序即 uuu 的占位符替换顺序）
    QCOMPARE(r.arguments.size(), 2);
    QCOMPARE(r.arguments.at(0), QFileInfo(boot).absoluteFilePath());
    QCOMPARE(r.arguments.at(1), QFileInfo(image).absoluteFilePath());

    // 阶段骨架与 uuu 内置 sd_all 一致
    QVERIFY(r.scriptText.contains("SDPS: boot"));
    QVERIFY(r.scriptText.contains("FB: flash -raw2sparse all"));
}

// 缺 Bootloader → 构建失败并给出原因。
void ScriptBuilderTest::sdAll_missingBootloader_fails()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const QString image = makeFile(dir.path(), "imx-image.wic");

    ScriptBuilder::BuildOptions opt;
    opt.bootloaderPath = dir.filePath("not-exist.bin"); // 故意不存在
    opt.linuxImagePath = image;
    opt.media = QStringLiteral("sd_all");

    ScriptBuilder::BuildResult r;
    QString error;
    QVERIFY(!opt.build(&r, &error));
    QVERIFY(!error.isEmpty());
}

// 一期只启用 sd_all：其余功能项即使参数齐全也应被拦截。
void ScriptBuilderTest::disabledMedia_rejects()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const QString boot = makeFile(dir.path(), "boot.bin");
    const QString image = makeFile(dir.path(), "image.wic");
    const QString file = makeFile(dir.path(), "kernel");

    const QStringList disabled = {QString("emmc_all"), QString("sd"),
                                  QString("fat_write"), QString("spl")};
    for (const QString& m : disabled) {
        ScriptBuilder::BuildOptions opt;
        opt.bootloaderPath = boot;
        opt.linuxImagePath = image;
        opt.extraFilePath = file;
        opt.targetDir = QStringLiteral("1");
        opt.media = m;
        ScriptBuilder::BuildResult r;
        QString error;
        QVERIFY2(!opt.build(&r, &error), qPrintable(m + " should be disabled"));
        QVERIFY(error.contains(QString("尚未启用")));
    }
    QVERIFY(ScriptBuilder::isMediaEnabled(QStringLiteral("sd_all")));
}

// 未知功能项（不在清单里）→ 被启用检查拦截。
void ScriptBuilderTest::unknownMedia_fails()
{
    ScriptBuilder::BuildOptions opt;
    opt.media = QStringLiteral("nand_all");
    ScriptBuilder::BuildResult r;
    QString error;
    QVERIFY(!opt.build(&r, &error));
    QVERIFY(error.contains(QString("尚未启用")));
}

// 关键：路径含空格作为参数是允许的（真机验证：uuu 自动加引号；
// 11/11 GUI 烧录成功用的就是含空格的 Downloads 路径）。
void ScriptBuilderTest::spacePathInArgument_ok()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const QString spaceDir = dir.path() + "/my images";
    QVERIFY(QDir().mkpath(spaceDir));
    const QString boot = makeFile(spaceDir, "boot.bin");
    const QString image = makeFile(spaceDir, "image.wic");
    QVERIFY(boot.contains(' '));

    ScriptBuilder::BuildOptions opt;
    opt.bootloaderPath = boot;
    opt.linuxImagePath = image;
    opt.media = QStringLiteral("sd_all");

    ScriptBuilder::BuildResult r;
    QString error;
    QVERIFY2(opt.build(&r, &error), qPrintable(error)); // 不因空格失败
    QVERIFY(r.arguments.at(0).contains(' '));
    // 脚本内仍不含路径（所以脚本本身无空格问题）
    QVERIFY(!r.scriptText.contains(' ' + image) && !r.scriptText.contains(boot));
}

// 落盘：首行必须是 uuu_version（真机验证），可追溯头在其后。
void ScriptBuilderTest::buildAndSave_versionFirstLine()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const QString boot = makeFile(dir.path(), "boot.bin");
    const QString image = makeFile(dir.path(), "image.wic");

    ScriptBuilder::BuildOptions opt;
    opt.bootloaderPath = boot;
    opt.linuxImagePath = image;
    opt.media = QStringLiteral("sd_all");

    ScriptBuilder::BuildResult r;
    QString error;
    const QString path = opt.buildAndSave(dir.path(), &r, &error);
    QVERIFY2(!path.isEmpty(), qPrintable(error));
    QVERIFY(path.endsWith("sd_all.auto"));
    QCOMPARE(r.arguments.size(), 2);

    QFile f(path);
    QVERIFY(f.open(QIODevice::ReadOnly));
    const QString text = QString::fromUtf8(f.readAll());
    const int firstEol = text.indexOf(QChar('\n'));
    QVERIFY(firstEol > 0);
    QVERIFY(text.left(firstEol).startsWith("uuu_version"));
    const int genBy = text.indexOf("# generated_by = nxp-uuu-flash-console");
    QVERIFY(genBy > firstEol);
    QVERIFY(text.contains("# generated_at = "));
}

// 功能项清单：5 项；一期只有 sd_all 启用。
void ScriptBuilderTest::featureList_onlySdAllEnabled()
{
    int count = 0;
    const ScriptBuilder::FeatureItem* items = ScriptBuilder::features(&count);
    QCOMPARE(count, 5);

    int enabledCount = 0;
    for (int i = 0; i < count; ++i) {
        QVERIFY(!items[i].media.isEmpty());
        QVERIFY(!items[i].name.isEmpty());
        QVERIFY(!items[i].name.contains("SDPS") && !items[i].name.contains("FB:"));
        if (items[i].enabled) {
            ++enabledCount;
            QCOMPARE(items[i].media, QString("sd_all"));
        }
    }
    QCOMPARE(enabledCount, 1);
}

QTEST_GUILESS_MAIN(ScriptBuilderTest)
#include "ScriptBuilderTest.moc"