#include "task/PartitionTable.h"

#include <QDir>
#include <QFile>
#include <QTemporaryDir>
#include <QtTest>

namespace {

// 造一个只有 MBR 分区表的最小镜像文件（512 字节）。
QString writeMbrImage(const QString& dir)
{
    QByteArray data(512, '\0');
    data[446 + 4] = char(0x0c);          // 分区 1：FAT32 LBA
    data[446 + 16 + 4] = char(0x83);     // 分区 2：Linux
    data[510] = char(0x55);
    data[511] = char(0xAA);
    const QString path = QDir(dir).filePath(QStringLiteral("mbr.wic"));
    QFile file(path);
    file.open(QIODevice::WriteOnly);
    file.write(data);
    return path;
}

// 造一个 GPT 镜像：分区 1 是 EFI System Partition（FAT），分区 2 是 Linux。
QString writeGptImage(const QString& dir)
{
    QByteArray data(1024 + 256, '\0');
    data[446 + 4] = char(0xEE);          // 保护性 MBR
    data[510] = char(0x55);
    data[511] = char(0xAA);
    const QByteArray sig = QByteArrayLiteral("EFI PART");
    for (int i = 0; i < sig.size(); ++i)
        data[512 + i] = sig.at(i);
    data[512 + 72] = char(2);             // 分区项表 LBA = 2
    data[512 + 80] = char(2);             // 分区项个数 = 2
    data[512 + 84] = char(128);           // 每个分区项 128 字节
    const uchar esp[16] = {0x28, 0x73, 0x2a, 0xc1, 0x1f, 0xf8, 0xd2, 0x11,
                          0xba, 0x4b, 0x00, 0xa0, 0xc9, 0x3e, 0xc9, 0x3b};
    for (int i = 0; i < 16; ++i)
        data[1024 + i] = char(esp[i]);
    const QString name = QStringLiteral("boot");
    for (int i = 0; i < name.size(); ++i) {
        const ushort ch = name.at(i).unicode();
        data[1024 + 56 + i * 2] = char(ch & 0xff);
        data[1024 + 56 + i * 2 + 1] = char((ch >> 8) & 0xff);
    }
    data[1024 + 128] = char(0xaf);       // 分区 2：Linux GUID 首字节
    const QString path = QDir(dir).filePath(QStringLiteral("gpt.wic"));
    QFile file(path);
    file.open(QIODevice::WriteOnly);
    file.write(data);
    return path;
}

} // namespace

class PartitionTableTest : public QObject {
    Q_OBJECT

private slots:
    void parsesMbrFatPartition();
    void parsesGptEspAsFat();
    void missingFileHasNoPartitions();
};

void PartitionTableTest::parsesMbrFatPartition()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const auto parts = PartitionTable::parseImage(writeMbrImage(dir.path()));

    QCOMPARE(parts.size(), 2);
    QCOMPARE(parts.at(0).number, 1);
    QCOMPARE(parts.at(0).type, QStringLiteral("0c"));
    QVERIFY(parts.at(0).fat);
    QCOMPARE(parts.at(0).writeArg(QStringLiteral("sd_dev")), QStringLiteral("${sd_dev}:1"));
    QCOMPARE(parts.at(1).number, 2);
    QCOMPARE(parts.at(1).type, QStringLiteral("83"));
    QVERIFY(!parts.at(1).fat);
}

void PartitionTableTest::parsesGptEspAsFat()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const auto parts = PartitionTable::parseImage(writeGptImage(dir.path()));

    QCOMPARE(parts.size(), 2);
    QCOMPARE(parts.at(0).number, 1);
    QVERIFY(parts.at(0).fat);
    QCOMPARE(parts.at(0).name, QStringLiteral("boot"));
    QCOMPARE(parts.at(1).number, 2);
    QVERIFY(!parts.at(1).fat);
}

void PartitionTableTest::missingFileHasNoPartitions()
{
    QCOMPARE(PartitionTable::parseImage(QStringLiteral("/no/such/file.wic")).size(), 0);
}

QTEST_MAIN(PartitionTableTest)
#include "PartitionTableTest.moc"