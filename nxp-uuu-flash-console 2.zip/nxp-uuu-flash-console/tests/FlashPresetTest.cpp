#include "config/FlashPreset.h"

#include <QtTest>

class FlashPresetTest : public QObject {
    Q_OBJECT

private slots:
    void roundTripKeepsValues();
    void rejectsBrokenJson();
    void rejectsForeignFile();
    void rejectsEmptyContent();
    void acceptsFileWithOnlyBoard();
    void acceptsFileWithOnlyFiles();
};

void FlashPresetTest::roundTripKeepsValues()
{
    FlashPreset::Data data;
    data.boardId = QStringLiteral("frdm-imx95-pro");
    data.bootloaderPath = QStringLiteral("C:/images/imx-boot-frdm-imx95-pro-sd.bin-flash_a55");
    data.linuxImagePath = QStringLiteral("C:/images/imx-image-full-imx95evk.wic");

    FlashPreset::Data parsed;
    QString error;
    QVERIFY(FlashPreset::decode(FlashPreset::encode(data), &parsed, &error));
    QVERIFY(error.isEmpty());
    QCOMPARE(parsed.boardId, data.boardId);
    QCOMPARE(parsed.bootloaderPath, data.bootloaderPath);
    QCOMPARE(parsed.linuxImagePath, data.linuxImagePath);
}

void FlashPresetTest::rejectsBrokenJson()
{
    FlashPreset::Data parsed;
    QString error;
    QVERIFY(!FlashPreset::decode(QStringLiteral("not json at all"), &parsed, &error));
    QVERIFY(!error.isEmpty());
}

void FlashPresetTest::rejectsForeignFile()
{
    FlashPreset::Data parsed;
    QString error;
    QVERIFY(!FlashPreset::decode(
        QStringLiteral("{\"board\": \"evk-imx95-19x19\"}"), &parsed, &error));
    QVERIFY(!error.isEmpty());
}

void FlashPresetTest::rejectsEmptyContent()
{
    FlashPreset::Data parsed;
    QString error;
    QVERIFY(!FlashPreset::decode(QStringLiteral(
                "{\"app\": \"nxp-uuu-flash-console\", \"type\": \"flash-config\"}"),
                &parsed, &error));
    QVERIFY(!error.isEmpty());
}

void FlashPresetTest::acceptsFileWithOnlyBoard()
{
    FlashPreset::Data parsed;
    QString error;
    QVERIFY(FlashPreset::decode(QStringLiteral(
                "{\"app\": \"nxp-uuu-flash-console\", \"type\": \"flash-config\", "
                "\"board\": \"frdm-imx95-pro\"}"), &parsed, &error));
    QCOMPARE(parsed.boardId, QStringLiteral("frdm-imx95-pro"));
    QVERIFY(parsed.bootloaderPath.isEmpty());
    QVERIFY(parsed.linuxImagePath.isEmpty());
}

void FlashPresetTest::acceptsFileWithOnlyFiles()
{
    FlashPreset::Data parsed;
    QString error;
    QVERIFY(FlashPreset::decode(QStringLiteral(
                "{\"app\": \"nxp-uuu-flash-console\", \"type\": \"flash-config\", "
                "\"bootloader\": \"C:/a/imx-boot.bin\", \"linuxImage\": \"C:/a/img.wic\"}"),
                &parsed, &error));
    QVERIFY(parsed.boardId.isEmpty());
    QCOMPARE(parsed.bootloaderPath, QStringLiteral("C:/a/imx-boot.bin"));
    QCOMPARE(parsed.linuxImagePath, QStringLiteral("C:/a/img.wic"));
}

QTEST_MAIN(FlashPresetTest)
#include "FlashPresetTest.moc"