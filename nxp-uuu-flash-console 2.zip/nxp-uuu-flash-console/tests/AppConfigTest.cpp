#include <QtTest>
#include <QCoreApplication>

#include "config/AppConfig.h"
#include "task/TaskRecord.h"

// 验证 exe 同目录的 <chip>-config.cfg 能被正确解析：
// 1) 四款芯片各有一份配置；
// 2) uuu 识别名（MX91/MX93/MX865/MX95）都能匹配到；
// 3) b*.bootloader 允许留空（名字对不上时由「从官方 zip 提取」列候选）。
class AppConfigTest : public QObject {
    Q_OBJECT
private slots:
    void loadsAllChips();
    void matchesUuuChipNames();
    void allowsEmptyBootloader();
    void mediaScripts();
    void scriptNamesDeduped();
    void advancedTabDefault();
};

void AppConfigTest::loadsAllChips()
{
    AppConfig config;
    config.load();
    QVERIFY(config.chipConfigValid());

    for (const QString& chip : {QStringLiteral("MX95"), QStringLiteral("MX91"),
                               QStringLiteral("MX93"), QStringLiteral("MX865")}) {
        const ChipConfig cfg = config.chipConfig(chip);
        QVERIFY2(cfg.valid, qPrintable(chip));
        QVERIFY2(cfg.name.compare(chip, Qt::CaseInsensitive) == 0, qPrintable(cfg.name));
        QVERIFY2(cfg.script == QLatin1String("sd_all"), qPrintable(cfg.script));
        QVERIFY2(!cfg.boards.isEmpty(), qPrintable(chip));
    }
}

void AppConfigTest::matchesUuuChipNames()
{
    AppConfig config;
    config.load();

    // i.MX 8M Plus 在 uuu -lsusb 里显示为 MX865（不是 MX8MP）。
    const ChipConfig plus = config.chipConfig(QStringLiteral("MX865"));
    QCOMPARE(plus.name, QStringLiteral("MX865"));

    // i.MX 91 有三块板：FRDM-IMX91 / FRDM-IMX91S / i.MX 91 EVK。
    const ChipConfig imx91 = config.chipConfig(QStringLiteral("MX91"));
    QCOMPARE(imx91.boards.size(), 3);

    // i.MX 95 有四块板。
    const ChipConfig imx95 = config.chipConfig(QStringLiteral("MX95"));
    QCOMPARE(imx95.boards.size(), 4);
}

void AppConfigTest::allowsEmptyBootloader()
{
    AppConfig config;
    config.load();

    const ChipConfig imx91 = config.chipConfig(QStringLiteral("MX91"));
    bool foundEmpty = false;
    for (const BoardProfile& board : imx91.boards) {
        if (board.id == QLatin1String("frdm-imx91s"))
            foundEmpty = board.bootloader.isEmpty();
    }
    QVERIFY2(foundEmpty, "frdm-imx91s 应能留空 bootloader 仍被加载");
}

void AppConfigTest::mediaScripts()
{
    AppConfig config;
    config.load();

    const ChipConfig chip = config.chipConfig(QStringLiteral("MX95"));
    // 六种介质都在，脚本名按介质区分。
    QVERIFY(chip.media.contains(QStringLiteral("sd")));
    QVERIFY(chip.media.contains(QStringLiteral("emmc")));
    QVERIFY(chip.media.contains(QStringLiteral("nand")));
    QVERIFY(chip.media.contains(QStringLiteral("qspi")));
    QVERIFY(chip.media.contains(QStringLiteral("spi_nand")));
    QVERIFY(chip.media.contains(QStringLiteral("nvme")));
    QCOMPARE(chip.scripts.value(QStringLiteral("sd")), QStringLiteral("sd_all"));
    QCOMPARE(chip.scripts.value(QStringLiteral("emmc")), QStringLiteral("emmc_all"));
    QCOMPARE(chip.scripts.value(QStringLiteral("nand")), QStringLiteral("nand"));
    QCOMPARE(chip.scripts.value(QStringLiteral("qspi")), QStringLiteral("qspi"));
    QCOMPARE(chip.scripts.value(QStringLiteral("spi_nand")), QStringLiteral("spi_nand"));
    QCOMPARE(chip.scripts.value(QStringLiteral("nvme")), QStringLiteral("nvme_all"));
    // 兼容字段 script = 默认介质的脚本。
    QCOMPARE(chip.script, QStringLiteral("sd_all"));
    QCOMPARE(chip.mediaDefault, QStringLiteral("sd"));

    // 整卡 wic 只适用于块设备；NAND/QSPI/SPI NAND 只烧 Bootloader。
    QVERIFY(mediaNeedsImage(QStringLiteral("sd")));
    QVERIFY(mediaNeedsImage(QStringLiteral("emmc")));
    QVERIFY(mediaNeedsImage(QStringLiteral("nvme")));
    QVERIFY(!mediaNeedsImage(QStringLiteral("nand")));
    QVERIFY(!mediaNeedsImage(QStringLiteral("qspi")));
    QVERIFY(!mediaNeedsImage(QStringLiteral("spi_nand")));
    QCOMPARE(mediaDisplayName(QStringLiteral("nand")), QStringLiteral("NAND"));
    QCOMPARE(mediaDisplayName(QStringLiteral("qspi")), QStringLiteral("QSPI NOR"));

    // 读回校验（FB: crc 读存储）只支持 mmc 块设备（SD / eMMC）。
    QVERIFY(mediaSupportsCrcVerify(QStringLiteral("sd")));
    QVERIFY(mediaSupportsCrcVerify(QStringLiteral("emmc")));
    QVERIFY(!mediaSupportsCrcVerify(QStringLiteral("nvme")));
    QVERIFY(!mediaSupportsCrcVerify(QStringLiteral("nand")));
    QVERIFY(!mediaSupportsCrcVerify(QStringLiteral("qspi")));
    QVERIFY(!mediaSupportsCrcVerify(QStringLiteral("spi_nand")));
}

void AppConfigTest::scriptNamesDeduped()
{
    AppConfig config;
    config.load();
    const ChipConfig chip = config.chipConfig(QStringLiteral("MX95"));
    // 六种介质六个脚本，去重后数量一致（没有重名脚本）。
    const QStringList names = chip.scriptNames();
    QCOMPARE(names.size(), chip.scripts.size());
    QVERIFY(names.contains(QStringLiteral("sd_all")));
    QVERIFY(names.contains(QStringLiteral("nand")));
    QVERIFY(names.contains(QStringLiteral("nvme_all")));
}

void AppConfigTest::advancedTabDefault()
{
    AppConfig config;
    config.load();
    // 高级页默认隐藏；菜单「显示高级页」可打开，状态写进 config.ini 的 Ui/AdvancedTab。
    QVERIFY(!config.advancedTab());
}

QTEST_GUILESS_MAIN(AppConfigTest)
#include "AppConfigTest.moc"
