# RKDevTool 官方工具 vs 我们程序（逐项对比）

对比对象：
- 官方：`C:\Users\nxh03528\OneDrive - NXP\YJY\RKDevTool_v3.37_for_window`（预编译，无源码，含官方 PDF 手册）
- 我们：`C:\dev\nxp-uuu-flash-console` 本地源码

---

## 1. 文件夹结构对比

| 项 | 官方 RKDevTool | 我们 | 说明 |
| --- | --- | --- | --- |
| 主程序 | `RKDevTool.exe`（3MB，功能全内置） | `uuu-flash-console.exe` + `uuu.exe` | 他们单 exe 干所有事；我们 GUI 调官方 uuu |
| 烧录引擎 | 内置于 exe | 官方 `uuu.exe`（NXP 工具） | 他们自己写引擎；我们直接用 NXP 的 |
| 解包/打包 | `bin\AFPTool.exe`、`bin\RKImageMaker.exe` | 无（程序内自己解析 zip） | 我们不用外部工具 |
| 设备切换 | `bin\adb.exe` + AdbWinApi/AdbWinUsbApi | 无（拨码物理切换） | NXP 板子不需要 adb 切模式 |
| 工具配置 | `config.ini` | `config.ini` | 都有，内容不同（见第 2 节） |
| 下载配置 | `config.cfg`（分区表） | `imx95-config.cfg`（芯片/板型/脚本） | 他们按分区；我们按芯片/板型（见第 3 节） |
| 配置导入导出 | 右键菜单「导入配置 / 导出配置」（ConfigFile） | 「导入配置…」「导出配置…」按钮（板型 + 两个文件路径，JSON） | 对应 |
| 语言 | `Language\Chinese.ini` + `English.ini` | 无（中文硬编码） | 他们支持中英切换 + 字体设置 |
| 日志 | `Log\Log2026-11-11.txt`（按天） | `logs\<任务id>.log`（按任务）+ `tasks.json` | 他们一天一个文件；我们一任务一个文件 |
| 版本记录 | `revision.txt`（v3.22–v3.37 逐版） | `开发文档.md` §12 变更记录 | 对应 |
| 手册 | `开发工具使用文档_v1.0.pdf`（12 页） | `开发文档.md` + `使用手册.md` + `uuu功能说明.md` | 我们的手册更细 |

## 2. config.ini 逐项对比

官方 `config.ini`（原文注释）：

| 官方配置项 | 含义 | 我们 | 状态 |
| --- | --- | --- | --- |
| `[Language] Kinds/Selected/LangPath/Lang1File/Lang1FontName/Lang1FontSize` | 语言文件 + 字体 + 大小 | `[General] Language=zh_CN` | 对应（简化） |
| `MSC_VIDPID/ADB_VIDPID/MTP_VIDPID/UVC_VIDPID` | 自定义四类 USB 设备的 VID/PID | 无 | NXP 固定 MX95（SDPS/FB），不需要 |
| `SUPPORTLOWUSB=true` | 支持全速 USB 设备（默认只支持高速） | 无 | 不需要 |
| `FORCE_DATA_BAND`（0–6，6=1M/5=512K/0=16K） | 烧写时单次传输带宽 | 无 | 不需要 |
| `MSC_TIMEOUT=30`、`ROCKUSB_TIMEOUT=5` | 设备超时（秒） | `[Device] TimeoutSeconds=30` | 对应 ✓ |
| `DEFAULT_IMAGE_CONFIG=config.cfg` | 启动时自动加载的配置文件 | 启动自动载入 `imx95-config.cfg` | 对应 ✓ |
| `RESET_AFTER_DOWNLOAD=TRUE` | 下载镜像后自动重启设备 | `[Flash] ResetAfterFlash=true` + 手动「重启设备」按钮 | 对应 ✓ |
| `FW_NOT_CHECK=TRUE` | 固件加载不做完整性校验 | `[Flash] VerifyAfterFlash=true`（反向） | 对应 ✓ |
| `RB_CHECK_OFF`（FALSE 时做回读校验） | 固件升级回读校验 | 「读回校验（CRC）」按钮 | 对应 ✓ |
| `LBA_PARITY=TRUE` | 设备端写后校验 | 无 | 不做 |
| `NOR_SINGLE_IDB` | NorFlash 单个 IDBlock | 无 | 不做 |
| `USB3_TRANSFER=TRUE` | 设备支持 USB3 时用 USB3 下载 | 无 | 不做 |
| `CLOSE_CHECK_IDB=TRUE` | 不检查 IDBLOCK 是否被覆盖 | 无 | 不做 |
| `AUTO=true` | 自动保存配置 | 自动保存 `tasks.json` | 对应 ✓ |

## 3. 下载配置对比（config.cfg vs imx95-config.cfg）

官方 `config.cfg`：`parameter`（分区表）+ 每个分区一项（Loader/Uboot/trust/Misc/Resource/Kernel/Boot/Recovery/System/Backup），每项带地址、路径、存储。
→ 这是 RK 固件的「分区级」配置：Android 系统多分区，需要逐分区指定文件与地址。

我们 `imx95-config.cfg`：
- `[chip]` name=MX95 / protocol=SDPS
- `[script]` sd=sd_all
- `[image]` bootloader=`*.bin imx-boot*` / linux=`*.wic *.wic.zst`
- `[board]` 4 个板型（FRDM/EVK × 19x19/15x15）+ 各自 bootloader 文件名
- `[download]` 官网下载页 + 快速上手页链接

→ 我们是「芯片级 + 板型级」配置：Linux BSP 是整卡镜像（wic），烧录只需两个文件，配置简单得多。

## 4. 错误分类对比

官方 `Language\Chinese.ini` 里约 50 条错误/提示（原文分类）：

| 官方分类 | 官方原文（举例） | 我们对应 |
| --- | --- | --- |
| 初始化 | 程序初始化失败! | — |
| 设备 | 没有发现设备,停止执行! / 发现多台设备,停止执行! / 获取设备失败 / 设备类型不匹配 | `NoDevice` / `MultiDevice` ✓ |
| 下载项 | %s下载项不存在 / 没有勾选下载项 / %s下载项没有分区大小 / Parameter文件被更新,请先确认更新后的下载地址再运行! | — （我们没有分区级配置） |
| 对象创建 | 创建IMAGE/COMM/DEVICE/SCAN/STEP/UPGRADE对象失败 | — （内部实现细节） |
| Boot | 写LBA前必须完成下载Boot! | 内部自动处理 ✓ |
| 下载 | 下载失败 / 读取设备参数失败 / 解析parameter失败 / 解析GPT失败 / 读取GPT标志失败 / 读取Flash信息失败 / 没有找到%s分区偏移 / %s分区大小未知 | `FlashImageFailed` ✓ |
| 存储 | 不支持存储读取和切换操作 / 读取当前存储失败 / 当前存储为%s,不支持! / 请选中要切换的存储 / 选中的存储未连接 / 切换存储失败 | — （单存储 SD） |
| 固件 | 重新加载固件失败 / 加载固件失败 / 固件未加载 / 固件被删除 / 解包工具不存在 / %s分区不够存放镜像 / 解析脚本出错 / 固件被修改是否重新加载继续升级? | `VersionMismatch` / `ConfigMissing` ✓ 部分 |
| 解包 | 开始解包统一固件... / 解包统一固件成功 / 解包统一固件失败 / 解包Android固件 / 解包多存储固件 | 从官方 zip 提取 ✓ |

我们 `FlashError`（13 类）：`ToolMissing / NoDevice / WrongDevice / MultiDevice / ConfigMissing / LoadBootloaderFailed / WaitFastbootTimeout / FlashImageFailed / VerifyFailed / PermissionDenied / VersionMismatch / Cancelled`。

差异：
- 他们约 50 条，是「哪一步失败」的流水账（每步都有 START/FAIL/PASS 三态）；我们 13 类，是「什么类型的问题」+ 每类配修复意见。
- 他们只有原文，没有修复意见；我们有修复意见（他们需要用户自己去 PDF 里查）。
- 他们有「Parameter 被更新」提醒（文件变了要重确认）→ 我们可以参考（wic/bootloader 变了提醒重新烧录）。

## 5. 日志对比

| 项 | 官方 | 我们 |
| --- | --- | --- |
| 文件 | `Log\Log2026-11-11.txt`（按天一个） | `logs\<任务id>.log`（按任务）+ `tasks.json` 记录表 |
| 格式 | `16:09:50 605 瑞芯微开发工具 v3.3.7.0 start run` / `16:12:04 218 Layer<>: RunProc is ending, ret=0` | `HH:mm:ss` + uuu 原始输出逐行 |
| 内容 | 工具自己的事件 + 结果码 | uuu 原始输出（用户要求：不猜测） |
| 导出 | 「导出串口日志」按钮 | 「导出」按钮（.txt） | 对应 ✓ |

实测：官方 Log 里有一条你今天的运行记录（16:09:50 启动，16:12:04 结束，ret=0）。

## 6. 版本记录对比

官方 `revision.txt`（v3.22–v3.37，2023–2025）最近几条：
- v3.37：修切换存储 bug；切换存储前检查是否下载 Boot
- v3.36：vdk 改名 rvd；支持切换 ufs/vdk 存储
- v3.35：换 VS2008 编译 AFPTool/RKImageMaker（避免被识别为病毒）
- v3.34：同步 upgradelib v2.68，支持 ufs 擦除 idb
- v3.30：支持读写 env 分区；Loader 模式下切换存储
- v3.26：4K UFS 的 GPT 支持；Nor 擦除单位 128K；471/472 可关 CRC

→ 他们每个版本都在修「存储/GPT/分区」类问题；我们的版本记录在 `开发文档.md` §12（当前 15 条）。

## 7. 结论：值得借鉴的

1. **语言文件**：他们中英文两套 `Language/*.ini` + 字体设置；我们目前只有中文硬编码 → 若以后要多语言，照这个结构做。
2. **Parameter 变更提醒**：`ERROR_PARAMETER_CHANGED`（配置被更新，请先确认再运行）→ 我们可以对「wic/bootloader 文件被替换后」提醒重新烧录（和我们的版本一致性检查合并）。
3. **固件被修改提醒**：`WARN_FIRMWARE_MODIFIED`（固件被修改是否重新加载继续升级?）→ 可在 wic 校验失败时给「是否重新烧录」提示。
4. **按天日志**：他们 `Log/LogYYYY-MM-DD.txt`；我们是按任务。可以并存：任务日志 + 汇总日志（可选）。
5. **导出串口日志按钮**：他们有（BUTTON_1055）；我们有「导出」✓ 已对齐。
6. **RESET_AFTER_DOWNLOAD**：他们有（下载后自动重启）；我们有 ResetAfterFlash 设置 + 手动按钮 ✓ 已对齐。
7. **导入/导出配置**：他们右键菜单导入 ParameterFile / 导出 ConfigFile；我们有「导入配置…」「导出配置…」按钮（`.json`，含板型 + 两个文件路径）✓ 已对齐。

## 8. 我们做得更好的

1. **修复意见**：他们只报错（如「没有发现设备,停止执行!」），我们每条错误给「修复意见」+ 基于实测状态（界面已实测显示）。
2. **板型/官网链接内置**：他们配置里只有分区文件路径；我们把 4 个板型的 bootloader 文件名 + 官网下载页/快速上手页内置在 `imx95-config.cfg`。
3. **官方 zip 自动提取**：他们没有（要自己准备 parameter + 分区文件）；我们「从官方 zip 提取」按板型自动挑出两个文件。
4. **数据保存位置可选**：他们日志固定 `Log/`；我们「数据保存位置…」可换目录 + 迁移旧记录。
5. **手册**：他们一份 12 页 PDF；我们开发文档 + 使用手册 + uuu 功能说明三份，GUI 与手册对齐。