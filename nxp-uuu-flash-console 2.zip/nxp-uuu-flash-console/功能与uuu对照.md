# 功能与 uuu 对照

维护烧录行为时以本文为准。界面不直接拼命令。命令在 `src/uuu/UUUAdapter.cpp` 发出，参数在 `src/task/TaskManager.cpp` 决定。

`src/uuu/ScriptBuilder.cpp` 未接入界面，也未接入 `TaskManager`。改烧录命令不要改这个文件。

内置脚本（`sd_all`、`emmc_all`、`nvme_all`、`nand`、`qspi`、`spi_nand`、`fat_write`）在 uuu 程序内部。本仓库只传脚本名。脚本正文见 `uuu功能说明.md`。

## 1. 命令怎么拼

可执行文件 `UUUAdapter::resolveExecutable`，顺序：

1. 界面「UUU 路径」写入的 `config.ini`
2. 程序目录下的 `uuu` / `uuu.exe`
3. 环境变量 `UUU_PATH`
4. `/usr/bin/uuu`（非 Windows）
5. `PATH`

超时秒数来自 `config.ini` 的 timeout，默认 30。烧录同时传 `-t` 和 `-T`。检测、读回、重启、FAT 写入只在注明的命令里带 `-t`。

并行烧录：每台设备一个 `UUUAdapter`。只有烧录命令带 `-m <usbPath>`。`usbPath` 是 `uuu -lsusb` 的 Path 列，例如 `1:2`。

工作目录：有系统镜像时用镜像所在目录，否则用启动文件所在目录。

## 2. 脚本名从哪来

`TaskManager::startJob`。后者覆盖前者：

1. 芯片配置 `<chip>-config.cfg` 的 `[script]`，键是介质
2. 高级页下拉选中的内置脚本名
3. 高级页「自定义脚本文件…」的 `.lst` 路径

`[script]` 缺省由 `defaultScriptForMedia`（`src/config/AppConfig.cpp`）填：

| 介质 | 脚本 | 传给 `-b` 的文件 |
| --- | --- | --- |
| sd | sd_all | 启动文件、系统镜像 |
| emmc | emmc_all | 启动文件、系统镜像 |
| nvme | nvme_all | 启动文件、系统镜像 |
| nand | nand | 只有启动文件 |
| qspi | qspi | 只有启动文件 |
| spi_nand | spi_nand | 只有启动文件 |

介质是否要系统镜像：`mediaNeedsImage`（`src/task/TaskRecord.h`）。不要镜像时 `linuxImagePath` 清空，命令行不追加该参数。

## 3. 功能对照

### 3.1 检测设备

界面：「再查一次」，以及每 3 秒自动检测（烧录和高级操作进行时不检测）。

```text
uuu -lsusb
```

代码：`TaskManager::detect` → `UUUAdapter::listDevices`。输出列 `Path Chip Pro Vid Pid`，解析在 `src/uuu/OutputParser.cpp`。可烧录条件：协议为 `SDPS` 或 `SDP`，且芯片能匹配某个 `*-config.cfg`。`FB` 表示停在 Fastboot，不能开始烧录。

### 3.2 整卡烧录 / 只烧启动文件

界面：「开始整卡烧录」或「开始烧启动文件」。一次提交烧所有可烧设备。已有任务时拒绝下一批。

```text
uuu -m <usbPath> -t <秒> -T <秒> -b <脚本> <启动文件> [系统镜像]
```

代码：`MainWindow::startFlash` → `TaskManager::submit` → `startJob` → `UUUAdapter::start`。

阶段由 uuu 输出行决定，`OutputParser`：`SDP:` / `SDPS:` / `SDPV:` 为加载启动文件，进入 `FB:` 之前为等待 Fastboot，`FB:` 且含 `flash` 为写镜像，`FB: done` 或 `Success 1 Failure 0` 为完成。

### 3.3 取消

只作用于烧录进程，不作用于检测、读回、重启、FAT。

- Windows：`CTRL_BREAK_EVENT`，发不出则 `terminate`
- 其他系统：`SIGINT`
- 2 秒后进程仍在：`kill`

代码：`TaskManager::cancel` / `cancelAll` → `UUUAdapter::cancel`。

### 3.4 启动镜像

不调用 uuu。`BspExtractor` 用系统 `unzip` 从官方 zip 抽出启动文件和系统镜像。版本不一致时界面禁止烧录。

### 3.5 读回校验

仅 SD、eMMC。设备须在 Fastboot。程序每次写脚本到数据目录 `scripts/verify_<介质>.lst`。

```text
uuu -t <秒> -b <数据目录>/scripts/verify_sd.lst <系统镜像>
uuu -t <秒> -b <数据目录>/scripts/verify_emmc.lst <系统镜像>
```

`verify_sd.lst` 使用 `${sd_dev}`，`verify_emmc.lst` 使用 `${emmc_dev}`。正文：

```text
uuu_version 1.5.243
# @_image                | wic image to verify (read back and compare CRC32)
FB: ucmd setenv fastboot_dev mmc
FB: ucmd setenv mmcdev ${sd_dev}
FB: ucmd mmc dev ${sd_dev}
FB: crc -f _image -seek 0x800000 -skip 0x800000
FB: done
```

`-seek` / `-skip` 的 `0x800000` 是跳过前 8MB。原因：`sd_all` 写完整卡后又把启动文件写进前 8MB，这一段与 wic 原文件不一致。

代码：`TaskManager::verifyCrc` → `UUUAdapter::runUtility`。

### 3.6 重启设备

设备须在 Fastboot。这是 uuu 单条命令，不是 `-b` 脚本。

```text
uuu -t <秒> FB: reboot
```

代码：`TaskManager::resetDevice` → `UUUAdapter::runUtility`。参数是两个独立参数：`FB:` 和 `reboot`。

### 3.7 FAT 写入

仅 SD、eMMC，仅分区根目录。设备须在 Fastboot。

读分区表有两步。先由 `PartitionTable::parseImage` 解析所选 wic，不调用 uuu。设备在 Fastboot 时再执行：

```text
uuu -t <秒> -b <数据目录>/scripts/list_parts.lst
```

`list_parts.lst`：

```text
uuu_version 1.5.243
FB: ucmd mmc dev ${sd_dev}
FB: ucmd mmc part
FB: done
```

eMMC 把 `${sd_dev}` 换成 `${emmc_dev}`。代码：`TaskManager::listFatPartitions` → `UUUAdapter::listPartitions`。

写入：

```text
uuu -t <秒> -b fat_write <本地文件> mmc <设备:分区> <目标文件名>
```

`<设备:分区>` 来自 `FatPartition::writeArg`。从 wic 解析、设备号未知时，拼出来的字符串是 `${` + `fatDeviceVar()` + `}:分区号`。`fatDeviceVar()` 本身已是 `${sd_dev}` 或 `${emmc_dev}`，因此实际参数形如 `${${sd_dev}}:1`。板子 `mmc part` 回填了设备号时，参数改为 `<设备号>:<分区号>`。代码：`TaskManager::writeFatFile`。

### 3.8 启动介质与芯片

不单独调用 uuu。介质决定第 2 节的脚本名，以及是否追加系统镜像。芯片决定读哪个 `*-config.cfg`（`AppConfig::chipConfig`）。匹配规则：全名相等，或去掉数字边界后的后缀相等。`MX95` 可以匹配 `IMX95`，不能匹配 `MX952`。

### 3.9 并行烧录

同 3.2。`TaskManager::submit` 对每台可烧设备调用一次 `startJob`。每条命令的 `-m` 不同，脚本和文件相同。

### 3.10 本机 API

`src/api/FlashApiServer.cpp`，默认 `127.0.0.1:8765`（`config.ini` 的 `Api/Enabled`、`Api/Port`）。API 不另写 uuu 命令，转调上面的函数。

| 方法 | 路径 | 转到 |
| --- | --- | --- |
| GET | /v1/health | 存活与端口 |
| GET | /v1/devices | 最近一次检测结果 |
| GET | /v1/tasks | 任务记录 |
| GET | /v1/tasks/\<id\> | 单条任务 |
| POST | /v1/detect | `TaskManager::detect` |
| POST | /v1/flash | `TaskManager::submit` |
| POST | /v1/cancel | `cancelAll`，或按 `taskId` 取消一条 |

`POST /v1/flash` 正文：`bootloader`、`image`、`media`、`board`、`script`、`scriptPath`、`usbPath`。`usbPath` 为空时烧所有可烧设备。`script` 是内置脚本名，`scriptPath` 是 `.lst` 路径。
