cmake_minimum_required(VERSION 3.21)
project(uuu-flash-console LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_AUTOMOC ON)

find_package(Qt6 6.5 REQUIRED COMPONENTS Network Widgets)

file(GLOB UVS_CHIP_CFGS CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/*-config.cfg")

function(uvs_copy_configs target)
    add_custom_command(TARGET ${target} POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            "${CMAKE_CURRENT_SOURCE_DIR}/config.ini"
            ${UVS_CHIP_CFGS}
            "$<TARGET_FILE_DIR:${target}>"
        COMMAND_EXPAND_LISTS
    )
endfunction()

add_executable(uuu-flash-console
    src/main.cpp
    src/config/AppConfig.h
    src/config/AppConfig.cpp
    src/config/FlashPreset.h
    src/config/FlashPreset.cpp
    src/task/TaskRecord.h
    src/task/BspPackage.h
    src/task/BspPackage.cpp
    src/task/PartitionTable.h
    src/task/PartitionTable.cpp
    src/task/BspExtractor.h
    src/task/BspExtractor.cpp
    src/task/TaskManager.h
    src/task/TaskManager.cpp
    src/uuu/OutputParser.h
    src/uuu/OutputParser.cpp
    src/uuu/UUUAdapter.h
    src/uuu/UUUAdapter.cpp
    src/uuu/ScriptBuilder.h
    src/uuu/ScriptBuilder.cpp
    src/api/FlashApiServer.h
    src/api/FlashApiServer.cpp
    src/gui/AppIcon.h
    src/gui/AppIcon.cpp
    src/gui/DropZone.h
    src/gui/DropZone.cpp
    src/gui/MainWindow.h
    src/gui/MainWindow.cpp
    src/gui/TaskHistoryDialog.h
    src/gui/TaskHistoryDialog.cpp
)

target_include_directories(uuu-flash-console PRIVATE src)
target_link_libraries(uuu-flash-console PRIVATE Qt6::Network Qt6::Widgets)

uvs_copy_configs(uuu-flash-console)

if(MSVC)
    target_compile_options(uuu-flash-console PRIVATE /utf-8)
endif()

if(WIN32)
    set_target_properties(uuu-flash-console PROPERTIES WIN32_EXECUTABLE TRUE)
    target_sources(uuu-flash-console PRIVATE assets/app.rc)

    # Windows 运行时依赖：清理 build 目录后重新构建也能直接运行，避免「找不到 DLL」弹窗。
    get_filename_component(UVS_MINGW_BIN_DIR "${CMAKE_CXX_COMPILER}" DIRECTORY)
    set(UVS_MINGW_RUNTIME_DLLS
        "${UVS_MINGW_BIN_DIR}/libgcc_s_seh-1.dll"
        "${UVS_MINGW_BIN_DIR}/libstdc++-6.dll"
        "${UVS_MINGW_BIN_DIR}/libwinpthread-1.dll"
    )

    function(uvs_copy_runtime_dlls target)
        add_custom_command(TARGET ${target} POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                $<TARGET_RUNTIME_DLLS:${target}>
                ${UVS_MINGW_RUNTIME_DLLS}
                "$<TARGET_FILE_DIR:${target}>"
            COMMAND_EXPAND_LISTS
        )
    endfunction()

    uvs_copy_runtime_dlls(uuu-flash-console)

    # Qt 的 DLL 与插件（platforms/qwindows.dll 等）用官方 windeployqt 部署。
    find_program(WINDEPLOYQT_EXECUTABLE windeployqt
        HINTS "${Qt6_DIR}/../../../bin")
    if(WINDEPLOYQT_EXECUTABLE)
        add_custom_command(TARGET uuu-flash-console POST_BUILD
            COMMAND "${WINDEPLOYQT_EXECUTABLE}"
                --no-translations --no-system-d3d-compiler --no-opengl-sw
                "$<TARGET_FILE:uuu-flash-console>"
        )
    endif()
endif()

include(CTest)
if(BUILD_TESTING)
    find_package(Qt6 6.5 REQUIRED COMPONENTS Test)

    add_executable(output-parser-tests
        tests/OutputParserTest.cpp
        src/task/TaskRecord.h
        src/uuu/OutputParser.h
        src/uuu/OutputParser.cpp
    )
    target_include_directories(output-parser-tests PRIVATE src)
    target_link_libraries(output-parser-tests PRIVATE Qt6::Test)
    add_test(NAME output-parser-tests COMMAND output-parser-tests)
    if(WIN32)
        uvs_copy_runtime_dlls(output-parser-tests)
    endif()

    add_executable(bsp-package-tests
        tests/BspPackageTest.cpp
        src/task/BspPackage.h
        src/task/BspPackage.cpp
    )
    target_include_directories(bsp-package-tests PRIVATE src)
    target_link_libraries(bsp-package-tests PRIVATE Qt6::Test)
    add_test(NAME bsp-package-tests COMMAND bsp-package-tests)
    if(WIN32)
        uvs_copy_runtime_dlls(bsp-package-tests)
    endif()
    add_executable(flash-preset-tests
        tests/FlashPresetTest.cpp
        src/config/FlashPreset.h
        src/config/FlashPreset.cpp
    )
    target_include_directories(flash-preset-tests PRIVATE src)
    target_link_libraries(flash-preset-tests PRIVATE Qt6::Test)
    add_test(NAME flash-preset-tests COMMAND flash-preset-tests)
    if(WIN32)
        uvs_copy_runtime_dlls(flash-preset-tests)
    endif()

    add_executable(partition-table-tests
        tests/PartitionTableTest.cpp
        src/task/PartitionTable.h
        src/task/PartitionTable.cpp
    )
    target_include_directories(partition-table-tests PRIVATE src)
    target_link_libraries(partition-table-tests PRIVATE Qt6::Test)
    add_test(NAME partition-table-tests COMMAND partition-table-tests)
    if(WIN32)
        uvs_copy_runtime_dlls(partition-table-tests)
    endif()

    add_executable(script-builder-tests
        tests/ScriptBuilderTest.cpp
        src/uuu/ScriptBuilder.h
        src/uuu/ScriptBuilder.cpp
    )
    target_include_directories(script-builder-tests PRIVATE src)
    target_link_libraries(script-builder-tests PRIVATE Qt6::Test)
    add_test(NAME script-builder-tests COMMAND script-builder-tests)
    if(WIN32)
        uvs_copy_runtime_dlls(script-builder-tests)
    endif()

    add_executable(app-config-tests
        tests/AppConfigTest.cpp
        src/config/AppConfig.h
        src/config/AppConfig.cpp
    )
    target_include_directories(app-config-tests PRIVATE src)
    target_link_libraries(app-config-tests PRIVATE Qt6::Test)
    add_test(NAME app-config-tests COMMAND app-config-tests)
    uvs_copy_configs(app-config-tests)
    if(WIN32)
        uvs_copy_runtime_dlls(app-config-tests)
    endif()
endif()
