#include "task/BspPackage.h"

#include <QByteArray>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QRegularExpression>
#include <QStandardPaths>

namespace {

const quint32 kEndSignature = 0x06054b50;
const quint32 kZip64EndSignature = 0x06064b50;
const quint32 kZip64LocatorSignature = 0x07064b50;
const quint32 kCentralSignature = 0x02014b50;
const quint32 kZip64Marker32 = 0xffffffff;
const quint16 kZip64Marker16 = 0xffff;
const quint64 kMaxEntries = 200000;
const quint64 kMaxDirectorySize = 64ull * 1024 * 1024;

quint16 readU16(const QByteArray& data, int offset)
{
    return static_cast<quint16>(static_cast<quint8>(data.at(offset)))
        | static_cast<quint16>(static_cast<quint8>(data.at(offset + 1))) << 8;
}

quint32 readU32(const QByteArray& data, int offset)
{
    return static_cast<quint32>(static_cast<quint8>(data.at(offset)))
        | static_cast<quint32>(static_cast<quint8>(data.at(offset + 1))) << 8
        | static_cast<quint32>(static_cast<quint8>(data.at(offset + 2))) << 16
        | static_cast<quint32>(static_cast<quint8>(data.at(offset + 3))) << 24;
}

quint64 readU64(const QByteArray& data, int offset)
{
    return static_cast<quint64>(readU32(data, offset))
        | static_cast<quint64>(readU32(data, offset + 4)) << 32;
}

// 顶层条目里，能当 Bootloader 的：imx-boot* / *flash*.bin（如 flash.bin）。
bool isBootloaderName(const QString& name)
{
    const QString lower = name.toLower();
    if (lower.startsWith(QLatin1String("imx-boot")))
        return true;
    if (!lower.endsWith(QLatin1String(".bin")))
        return false;
    return lower.contains(QLatin1String("flash"));
}

// 顶层条目里，能当整盘镜像的：*.wic / *.wic.zst / *.img / *.img.zst。
bool isImageName(const QString& name)
{
    const QString lower = name.toLower();
    return lower.endsWith(QLatin1String(".wic"))
        || lower.endsWith(QLatin1String(".wic.zst"))
        || lower.endsWith(QLatin1String(".img"))
        || lower.endsWith(QLatin1String(".img.zst"));
}

int findEndSignature(const QByteArray& tail)
{
    for (int i = tail.size() - 22; i >= 0; --i) {
        if (readU32(tail, i) == kEndSignature)
            return i;
    }
    return -1;
}

} // namespace

QString BspPackage::inferVersion(const QString& pathOrName)
{
    static const QRegularExpression pattern(
        QStringLiteral("(\\d+\\.\\d+\\.\\d+)[-_](\\d+\\.\\d+\\.\\d+)"));

    QString text = pathOrName;
    text.replace(QLatin1Char('\\'), QLatin1Char('/'));
    const QStringList parts = text.split(QLatin1Char('/'), Qt::SkipEmptyParts);
    for (int i = parts.size() - 1; i >= 0 && i >= parts.size() - 4; --i) {
        const QRegularExpressionMatch match = pattern.match(parts.at(i));
        if (match.hasMatch())
            return match.captured(1) + QLatin1Char('-') + match.captured(2);
    }
    return QString();
}

bool BspPackage::readEntries(const QString& zipPath, QVector<BspZipEntry>* entries, QString* error)
{
    entries->clear();
    QFile file(zipPath);
    if (!file.open(QIODevice::ReadOnly)) {
        *error = QStringLiteral("无法打开镜像包：%1").arg(QFileInfo(zipPath).fileName());
        return false;
    }

    const qint64 size = file.size();
    const qint64 tailSize = qMin<qint64>(size, 66000);
    if (tailSize < 22 || !file.seek(size - tailSize)) {
        *error = QStringLiteral("不是有效的 zip 文件：%1").arg(QFileInfo(zipPath).fileName());
        return false;
    }

    const QByteArray tail = file.read(tailSize);
    const int end = findEndSignature(tail);
    if (end < 0) {
        *error = QStringLiteral("不是有效的 zip 文件：%1").arg(QFileInfo(zipPath).fileName());
        return false;
    }

    quint64 count = readU16(tail, end + 10);
    quint64 offset = readU32(tail, end + 16);
    quint64 directorySize = readU32(tail, end + 12);

    if (offset == kZip64Marker32 || count == kZip64Marker16) {
        const qint64 locator = size - tailSize + end - 20;
        if (locator < 0 || !file.seek(locator)) {
            *error = QStringLiteral("镜像包目录区损坏：%1").arg(QFileInfo(zipPath).fileName());
            return false;
        }
        const QByteArray record = file.read(20);
        if (record.size() != 20 || readU32(record, 0) != kZip64LocatorSignature) {
            *error = QStringLiteral("镜像包目录区损坏：%1").arg(QFileInfo(zipPath).fileName());
            return false;
        }
        if (!file.seek(static_cast<qint64>(readU64(record, 8)))) {
            *error = QStringLiteral("镜像包目录区损坏：%1").arg(QFileInfo(zipPath).fileName());
            return false;
        }
        const QByteArray header = file.read(56);
        if (header.size() != 56 || readU32(header, 0) != kZip64EndSignature) {
            *error = QStringLiteral("镜像包目录区损坏：%1").arg(QFileInfo(zipPath).fileName());
            return false;
        }
        count = readU64(header, 32);
        directorySize = readU64(header, 40);
        offset = readU64(header, 48);
    }

    if (count > kMaxEntries || directorySize > kMaxDirectorySize || directorySize == 0
        || !file.seek(static_cast<qint64>(offset))) {
        *error = QStringLiteral("镜像包目录区损坏：%1").arg(QFileInfo(zipPath).fileName());
        return false;
    }

    const QByteArray directory = file.read(static_cast<qint64>(directorySize));
    if (static_cast<quint64>(directory.size()) != directorySize) {
        *error = QStringLiteral("镜像包目录区损坏：%1").arg(QFileInfo(zipPath).fileName());
        return false;
    }

    int cursor = 0;
    for (quint64 i = 0; i < count; ++i) {
        if (cursor + 46 > directory.size()
            || readU32(directory, cursor) != kCentralSignature) {
            *error = QStringLiteral("镜像包目录区损坏：%1").arg(QFileInfo(zipPath).fileName());
            return false;
        }
        quint64 compressed = readU32(directory, cursor + 20);
        quint64 uncompressed = readU32(directory, cursor + 24);
        const int nameLength = readU16(directory, cursor + 28);
        const int extraLength = readU16(directory, cursor + 30);
        const int commentLength = readU16(directory, cursor + 32);
        const int nameAt = cursor + 46;
        if (nameAt + nameLength > directory.size()) {
            *error = QStringLiteral("镜像包目录区损坏：%1").arg(QFileInfo(zipPath).fileName());
            return false;
        }

        if (uncompressed == kZip64Marker32 || compressed == kZip64Marker32) {
            const int extraEnd = qMin(nameAt + nameLength + extraLength, directory.size());
            int extra = nameAt + nameLength;
            while (extra + 4 <= extraEnd) {
                const quint16 id = readU16(directory, extra);
                const int fieldSize = readU16(directory, extra + 2);
                extra += 4;
                if (extra + fieldSize > extraEnd)
                    break;
                if (id == 1) {
                    int at = extra;
                    if (uncompressed == kZip64Marker32 && at + 8 <= extra + fieldSize) {
                        uncompressed = readU64(directory, at);
                        at += 8;
                    }
                    if (compressed == kZip64Marker32 && at + 8 <= extra + fieldSize)
                        compressed = readU64(directory, at);
                }
                extra += fieldSize;
            }
        }

        BspZipEntry entry;
        entry.name = QString::fromUtf8(directory.mid(nameAt, nameLength));
        entry.size = uncompressed;
        entries->push_back(entry);
        cursor = nameAt + nameLength + extraLength + commentLength;
    }
    return true;
}

bool BspPackage::selectImages(const QVector<BspZipEntry>& entries, const QString& bootloaderName,
                              const QString& linuxImageName, QString* bootloader,
                              QString* linuxImage, QString* error)
{
    bootloader->clear();
    linuxImage->clear();
    QString compressed;
    for (const BspZipEntry& entry : entries) {
        if (entry.name.contains(QLatin1Char('/')))
            continue;
        if (bootloader->isEmpty()
            && entry.name.compare(bootloaderName, Qt::CaseInsensitive) == 0) {
            *bootloader = entry.name;
        }
        if (!linuxImageName.isEmpty()) {
            // 指定了镜像名：精确匹配。
            if (entry.name.compare(linuxImageName, Qt::CaseInsensitive) == 0)
                *linuxImage = entry.name;
            continue;
        }
        // 没指定：退回第一个 imx-image-*.wic（.wic 优先，其次 .wic.zst）。
        if (linuxImage->isEmpty() && entry.name.startsWith(QLatin1String("imx-image-"))
            && entry.name.endsWith(QLatin1String(".wic"))) {
            *linuxImage = entry.name;
        } else if (compressed.isEmpty() && entry.name.startsWith(QLatin1String("imx-image-"))
                   && entry.name.endsWith(QLatin1String(".wic.zst"))) {
            compressed = entry.name;
        }
    }
    if (linuxImage->isEmpty())
        *linuxImage = compressed;
    if (bootloader->isEmpty()) {
        *error = QStringLiteral("镜像包里没有该板型的 Bootloader：%1").arg(bootloaderName);
        return false;
    }
    if (linuxImage->isEmpty()) {
        *error = QStringLiteral("镜像包里没有找到指定的镜像：%1")
                     .arg(linuxImageName.isEmpty()
                              ? QStringLiteral("imx-image-*.wic") : linuxImageName);
        return false;
    }
    return true;
}

QStringList BspPackage::bootloaderCandidates(const QVector<BspZipEntry>& entries)
{
    QStringList result;
    for (const BspZipEntry& entry : entries) {
        if (entry.name.contains(QLatin1Char('/')))
            continue;
        if (isBootloaderName(entry.name))
            result << entry.name;
    }
    result.sort(Qt::CaseInsensitive);
    return result;
}

QStringList BspPackage::imageCandidates(const QVector<BspZipEntry>& entries)
{
    QStringList result;
    for (const BspZipEntry& entry : entries) {
        if (entry.name.contains(QLatin1Char('/')))
            continue;
        if (isImageName(entry.name))
            result << entry.name;
    }
    result.sort(Qt::CaseInsensitive);
    return result;
}

QString BspPackage::extractToolPath()
{
#if defined(Q_OS_WIN)
    const QString root = qEnvironmentVariable("SystemRoot", QStringLiteral("C:\\Windows"));
    const QString tar = QDir(root).filePath(QStringLiteral("System32/tar.exe"));
    if (QFileInfo::exists(tar))
        return tar;
#endif
    return QStandardPaths::findExecutable(QStringLiteral("tar"));
}
