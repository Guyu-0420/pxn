#pragma once

#include "config/AppConfig.h"
#include "task/TaskRecord.h"
#include "uuu/UUUAdapter.h"

#include <QFile>
#include <QHash>
#include <QObject>

class TaskManager : public QObject {
    Q_OBJECT
public:
    explicit TaskManager(QObject* parent = nullptr);
    ~TaskManager() override;

    void detect(bool silent = false);
    QStringList submit(const FlashRequest& request);
    QString submitError() const;
    void verifyCrc(const FlashRequest& request);
    void resetDevice();
    void listFatPartitions(const QString& media);
    void writeFatFile(const QString& filePath, const QString& media,
                      const QString& devicePartition, const QString& targetName);
    void cancel(const QString& taskId);
    void cancelAll();
    bool isFlashTarget(const DeviceInfo& device) const;
    void setBootChecked(const QString& taskId, bool checked);
    void setExecutable(const QString& path);
    void beginQuit();

    AppConfig& config();

    QVector<TaskRecord> history() const;
    QVector<TaskRecord> running() const;
    QVector<TaskRecord> lastBatch() const;
    void reloadHistory();
    QString storageDir() const;
    QString logDirectory() const;
    QVector<DeviceInfo> devices() const;
    QString detectError() const;
    FlashError detectErrorCode() const;
    bool isDetecting() const;
    bool isFlashing() const;
    bool isUtilityRunning() const;
    QString utilityTitle() const;
    QVector<FatPartition> partitions() const;
    QVector<FatPartition> fatPartitions() const;
    QString partitionsError() const;
    bool isListingPartitions() const;
    bool isQuitting() const;

signals:
    void devicesChanged(QVector<DeviceInfo> devices);
    void taskChanged(TaskRecord task);
    void logLine(QString taskId, QString text);
    void activityChanged();
    void utilityFinished(QString title, bool ok, QString message);
    void partitionsChanged(QVector<FatPartition> partitions);

private:
    void applyConfig();
    void load();
    void persist();
    void replaceHistory(const TaskRecord& task);
    void onDevices(QVector<DeviceInfo> devices, QString error);
    void onPartitions(QVector<FatPartition> partitions, QString error);
    void onUtilityFinished(int exitCode, bool success, QString message);
    QString startJob(const DeviceInfo& device, const FlashRequest& request);
    void onJobOutput(const QString& id, const QString& line);
    void onJobStage(const QString& id, TaskStage stage, int percent);
    void onJobFinished(const QString& id, int exitCode, bool success, FlashError error);
    FlashError classifyDetect(const QVector<DeviceInfo>& devices, const QString& error) const;

    struct Job {
        TaskRecord task;
        UUUAdapter* uuu = nullptr;
        QFile* log = nullptr;
        QString lastOutput;
        bool cancelRequested = false;
    };

    AppConfig m_config;
    UUUAdapter m_uuu;
    QHash<QString, Job*> m_jobs;
    QVector<TaskRecord> m_lastBatch;
    QVector<TaskRecord> m_history;
    QVector<DeviceInfo> m_devices;
    QVector<FatPartition> m_partitions;
    QString m_submitError;
    QString m_detectError;
    FlashError m_detectErrorCode = FlashError::None;
    QString m_partitionsError;
    bool m_utility = false;
    bool m_listingParts = false;
    QString m_utilityTitle;
    bool m_detecting = false;
    bool m_quitting = false;
};
