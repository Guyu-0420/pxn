#pragma once

#include <QString>
#include <QStringList>
#include <QVector>

// 官方镜像包（LF_v<版本>_images_*.zip）里的一个条目。
struct BspZipEntry {
    QString name;
    quint64 size = 0;
};

// 官方镜像包的识别与解包。只读 zip 目录区，不依赖 uuu。
namespace BspPackage {

// 从 zip 文件名或所在目录名解析 BSP 版本，如 6.18.20-2.0.0；解析不到返回空。
QString inferVersion(const QString& pathOrName);

// 读取 zip 条目清单（只读目录区，不解压）。
bool readEntries(const QString& zipPath, QVector<BspZipEntry>* entries, QString* error);

// 按板型 Bootloader 文件名与指定镜像名挑出要烧录的两个文件。
// linuxImageName 为空时退回第一个 imx-image-*.wic（兼容旧行为）。
bool selectImages(const QVector<BspZipEntry>& entries, const QString& bootloaderName,
                  const QString& linuxImageName, QString* bootloader, QString* linuxImage,
                  QString* error);

// 列出 zip 里所有可作 Bootloader 的顶层条目（imx-boot*），按名字排序。
// 供界面在 cfg 名字对不上、或有多个候选时让工人自己选/搜索。
QStringList bootloaderCandidates(const QVector<BspZipEntry>& entries);

// 列出 zip 里所有可作整盘镜像的顶层条目（*.wic / *.wic.zst / *.img / *.img.zst），按名字排序。
// 供界面在包里有多份镜像变体时让工人自己选/搜索。
QStringList imageCandidates(const QVector<BspZipEntry>& entries);

// 解包工具路径：Windows 用系统自带 tar.exe，其他平台从 PATH 找 tar。
QString extractToolPath();

} // namespace BspPackage
