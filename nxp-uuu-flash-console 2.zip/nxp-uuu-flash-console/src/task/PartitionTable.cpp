#include "task/PartitionTable.h"

#include <QFile>

namespace {

quint32 le32(const QByteArray& data, int offset)
{
    if (offset < 0 || offset + 4 > data.size())
        return 0;
    const uchar* p = reinterpret_cast<const uchar*>(data.constData()) + offset;
    return quint32(p[0]) | (quint32(p[1]) << 8) | (quint32(p[2]) << 16) | (quint32(p[3]) << 24);
}

quint64 le64(const QByteArray& data, int offset)
{
    quint64 value = 0;
    for (int i = 0; i < 8; ++i)
        value |= quint64(uchar(data.at(offset + i))) << (8 * i);
    return value;
}

// DOS 分区类型码 → 是否 FAT（01/04/06/0b/0c/0e 及隐藏变体）。
bool isFatTypeCode(int code)
{
    switch (code) {
    case 0x01: case 0x04: case 0x06: case 0x0b: case 0x0c: case 0x0e:
    case 0x11: case 0x14: case 0x16: case 0x1b: case 0x1c: case 0x1e:
        return true;
    default:
        return false;
    }
}

// GPT 分区类型 GUID == EFI System Partition（ESP，FAT）。镜像里按小端字节序存。
bool isEspGuid(const QByteArray& guid)
{
    static const uchar kEsp[16] = {0x28, 0x73, 0x2a, 0xc1, 0x1f, 0xf8, 0xd2, 0x11,
                                  0xba, 0x4b, 0x00, 0xa0, 0xc9, 0x3e, 0xc9, 0x3b};
    if (guid.size() < 16)
        return false;
    for (int i = 0; i < 16; ++i) {
        if (uchar(guid.at(i)) != kEsp[i])
            return false;
    }
    return true;
}

// GPT 分区名是 UTF-16LE 定长字段，取到第一个 0 为止。
QString utf16Name(const QByteArray& bytes)
{
    QString name;
    for (int i = 0; i + 1 < bytes.size(); i += 2) {
        const ushort ch = ushort(uchar(bytes.at(i))) | (ushort(uchar(bytes.at(i + 1))) << 8);
        if (ch == 0)
            break;
        name.append(QChar(ch));
    }
    return name.trimmed();
}

QVector<FatPartition> parseGpt(QFile& file, const QByteArray& header)
{
    QVector<FatPartition> parts;
    if (header.size() < 92 || header.left(8) != QByteArrayLiteral("EFI PART"))
        return parts;
    const quint64 entriesLba = le64(header, 72);
    const quint32 count = le32(header, 80);
    const quint32 entrySize = le32(header, 84);
    if (entriesLba == 0 || count == 0 || entrySize < 128 || count > 1024)
        return parts;
    if (!file.seek(qint64(entriesLba) * 512))
        return parts;
    const QByteArray table = file.read(qint64(count) * qint64(entrySize));
    for (quint32 i = 0; i < count; ++i) {
        const QByteArray entry = table.mid(int(i) * int(entrySize), int(entrySize));
        if (entry.size() < 128)
            break;
        const QByteArray type = entry.left(16);
        bool zero = true;
        for (int k = 0; k < 16; ++k) {
            if (type.at(k) != 0) {
                zero = false;
                break;
            }
        }
        if (zero)
            continue;
        FatPartition part;
        part.device = -1;
        part.number = int(i) + 1;
        part.fat = isEspGuid(type);
        part.type = part.fat ? QStringLiteral("efi") : QStringLiteral("gpt");
        part.name = utf16Name(entry.mid(56, 72));
        parts.push_back(part);
    }
    return parts;
}

QVector<FatPartition> parseMbr(const uchar* mbr)
{
    QVector<FatPartition> parts;
    for (int i = 0; i < 4; ++i) {
        const int off = 446 + i * 16;
        const int type = mbr[off + 4];
        if (type == 0)
            continue;
        FatPartition part;
        part.device = -1;
        part.number = i + 1;
        part.type = QStringLiteral("%1").arg(type, 2, 16, QLatin1Char('0'));
        part.fat = isFatTypeCode(type);
        parts.push_back(part);
    }
    return parts;
}

} // namespace

QVector<FatPartition> PartitionTable::parseImage(const QString& imagePath)
{
    QVector<FatPartition> parts;
    QFile file(imagePath);
    if (!file.open(QIODevice::ReadOnly))
        return parts;

    const QByteArray mbr = file.read(512);
    if (mbr.size() < 512)
        return parts;
    const uchar* m = reinterpret_cast<const uchar*>(mbr.constData());
    if (m[510] != 0x55 || m[511] != 0xAA)
        return parts;

    // 第一个分区类型 0xEE = 保护性 MBR，说明是 GPT。
    if (m[446 + 4] == 0xEE) {
        if (!file.seek(512))
            return parts;
        return parseGpt(file, file.read(92));
    }
    return parseMbr(m);
}