#include "task/BspExtractor.h"

#include "task/BspPackage.h"

#include <QDir>
#include <QFileInfo>
#include <QProcess>

BspExtractor::BspExtractor(QObject* parent)
    : QObject(parent)
{
}

BspExtractor::~BspExtractor()
{
    if (m_process) {
        m_process->kill();
        m_process->waitForFinished(3000);
    }
}

bool BspExtractor::isRunning() const
{
    return m_process != nullptr;
}

bool BspExtractor::start(const QString& zipPath, const QStringList& members, const QString& destDir,
                         QString* error)
{
    if (m_process) {
        *error = QStringLiteral("正在解包，请稍候");
        return false;
    }
    if (members.isEmpty()) {
        *error = QStringLiteral("没有要解包的文件");
        return false;
    }

    const QString tool = BspPackage::extractToolPath();
    if (tool.isEmpty()) {
        *error = QStringLiteral("找不到解包工具 tar，无法解压镜像包");
        return false;
    }
    if (!QDir().mkpath(destDir)) {
        *error = QStringLiteral("无法创建目录：%1").arg(destDir);
        return false;
    }

    QStringList args;
    args << QStringLiteral("-xf") << QFileInfo(zipPath).absoluteFilePath()
         << QStringLiteral("-C") << QDir(destDir).absolutePath();
    args << members;

    m_cancelled = false;
    m_process = new QProcess(this);
    m_process->setProcessChannelMode(QProcess::MergedChannels);
    connect(m_process, &QProcess::readyReadStandardOutput, this, [this] {
        if (!m_process)
            return;
        const QString text = QString::fromLocal8Bit(m_process->readAllStandardOutput()).trimmed();
        if (!text.isEmpty())
            emit output(text);
    });
    connect(m_process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
            [this](int exitCode, QProcess::ExitStatus status) {
        QProcess* process = m_process;
        m_process = nullptr;
        process->deleteLater();
        if (m_cancelled) {
            emit finished(false, QStringLiteral("已取消解包"));
            return;
        }
        if (status != QProcess::NormalExit || exitCode != 0)
            emit finished(false, QStringLiteral("解包失败，退出码 %1").arg(exitCode));
        else
            emit finished(true, QString());
    });
    m_process->start(tool, args);
    if (!m_process->waitForStarted(5000)) {
        QProcess* process = m_process;
        m_process = nullptr;
        process->deleteLater();
        *error = QStringLiteral("无法启动解包工具：%1").arg(tool);
        return false;
    }
    return true;
}

void BspExtractor::cancel()
{
    if (!m_process)
        return;
    m_cancelled = true;
    m_process->kill();
}