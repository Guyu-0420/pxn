#pragma once

#include <QObject>
#include <QString>
#include <QStringList>

class QProcess;

// 异步解包官方镜像包里的指定条目，界面不卡住。
class BspExtractor : public QObject {
    Q_OBJECT
public:
    explicit BspExtractor(QObject* parent = nullptr);
    ~BspExtractor() override;

    bool start(const QString& zipPath, const QStringList& members, const QString& destDir,
                QString* error);
    void cancel();
    bool isRunning() const;

signals:
    void output(const QString& text);
    void finished(bool ok, const QString& message);

private:
    QProcess* m_process = nullptr;
    bool m_cancelled = false;
};