#include "task/TaskManager.h"

#include "uuu/OutputParser.h"

#include "task/PartitionTable.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>

namespace {

QJsonObject toJson(const TaskRecord& task)
{
    QJsonObject obj;
    obj.insert(QStringLiteral("id"), task.id);
    obj.insert(QStringLiteral("startedAt"), task.startedAt.toString(Qt::ISODate));
    obj.insert(QStringLiteral("endedAt"), task.endedAt.toString(Qt::ISODate));
    obj.insert(QStringLiteral("usbPath"), task.device.usbPath);
    obj.insert(QStringLiteral("chip"), task.device.chip);
    obj.insert(QStringLiteral("protocol"), task.device.protocol);
    obj.insert(QStringLiteral("vid"), task.device.vid);
    obj.insert(QStringLiteral("pid"), task.device.pid);
    obj.insert(QStringLiteral("bootloaderPath"), task.bootloaderPath);
    obj.insert(QStringLiteral("linuxImagePath"), task.linuxImagePath);
    obj.insert(QStringLiteral("boardName"), task.boardName);
    obj.insert(QStringLiteral("target"), task.target);
    obj.insert(QStringLiteral("state"), taskStateName(task.state));
    obj.insert(QStringLiteral("stage"), static_cast<int>(task.stage));
    obj.insert(QStringLiteral("percent"), task.percent);
    obj.insert(QStringLiteral("exitCode"), task.exitCode);
    obj.insert(QStringLiteral("errorCode"), flashErrorName(task.errorCode));
    obj.insert(QStringLiteral("message"), task.message);
    obj.insert(QStringLiteral("bootChecked"), task.bootChecked);
    obj.insert(QStringLiteral("logPath"), task.logPath);
    return obj;
}

TaskRecord fromJson(const QJsonObject& obj)
{
    TaskRecord task;
    task.id = obj.value(QStringLiteral("id")).toString();
    task.startedAt = QDateTime::fromString(obj.value(QStringLiteral("startedAt")).toString(), Qt::ISODate);
    task.endedAt = QDateTime::fromString(obj.value(QStringLiteral("endedAt")).toString(), Qt::ISODate);
    task.device.usbPath = obj.value(QStringLiteral("usbPath")).toString();
    task.device.chip = obj.value(QStringLiteral("chip")).toString();
    task.device.protocol = obj.value(QStringLiteral("protocol")).toString();
    task.device.vid = obj.value(QStringLiteral("vid")).toString();
    task.device.pid = obj.value(QStringLiteral("pid")).toString();
    task.bootloaderPath = obj.value(QStringLiteral("bootloaderPath")).toString();
    task.linuxImagePath = obj.value(QStringLiteral("linuxImagePath")).toString();
    task.boardName = obj.value(QStringLiteral("boardName")).toString();
    task.target = obj.value(QStringLiteral("target")).toString(QStringLiteral("SD"));
    task.state = taskStateFromName(obj.value(QStringLiteral("state")).toString());
    task.stage = static_cast<TaskStage>(obj.value(QStringLiteral("stage")).toInt());
    task.percent = obj.value(QStringLiteral("percent")).toInt();
    task.exitCode = obj.value(QStringLiteral("exitCode")).toInt(-1);
    task.errorCode = flashErrorFromName(obj.value(QStringLiteral("errorCode")).toString());
    task.message = obj.value(QStringLiteral("message")).toString();
    task.bootChecked = obj.value(QStringLiteral("bootChecked")).toBool();
    task.logPath = obj.value(QStringLiteral("logPath")).toString();
    return task;
}

QString formatStamp()
{
    return QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss "));
}

} // namespace

TaskManager::TaskManager(QObject* parent)
    : QObject(parent)
{
    connect(&m_uuu, &UUUAdapter::devicesReady, this, &TaskManager::onDevices);
    connect(&m_uuu, &UUUAdapter::output, this, [this](const QString& line) {
        emit logLine(QString(), formatStamp() + line);
    });
    connect(&m_uuu, &UUUAdapter::utilityFinished, this, &TaskManager::onUtilityFinished);
    connect(&m_uuu, &UUUAdapter::partitionsReady, this, &TaskManager::onPartitions);
    m_config.load();
    applyConfig();
    load();
}

TaskManager::~TaskManager()
{
    const auto jobs = m_jobs.values();
    m_jobs.clear();
    for (Job* job : jobs) {
        delete job->log;
        delete job;
    }
}

AppConfig& TaskManager::config()
{
    return m_config;
}

void TaskManager::applyConfig()
{
    m_uuu.setTimeoutSeconds(m_config.timeoutSeconds());
    if (!m_config.uuuPath().isEmpty())
        m_uuu.setExecutable(m_config.uuuPath());
}

// silent=true 用于自动轮询：不置“检测中”、不刷按钮，只在结果变化时更新界面。
void TaskManager::detect(bool silent)
{
    if (isFlashing() || m_uuu.isRunning())
        return;
    m_detecting = !silent;
    if (!silent)
        emit activityChanged();
    m_uuu.listDevices();
}

QString TaskManager::submitError() const
{
    return m_submitError;
}

bool TaskManager::isFlashTarget(const DeviceInfo& device) const
{
    return isSerialDownload(device.protocol) && m_config.hasChip(device.chip);
}

QStringList TaskManager::submit(const FlashRequest& request)
{
    m_submitError.clear();
    if (isFlashing() || m_uuu.isRunning()) {
        m_submitError = QStringLiteral("已有烧录或检测在进行");
        return {};
    }
    if (!m_uuu.executableFound()) {
        m_submitError = QStringLiteral("未找到 uuu");
        return {};
    }

    const QString bootloader = QFileInfo(request.bootloaderPath).absoluteFilePath();
    const QString image = QFileInfo(request.linuxImagePath).absoluteFilePath();
    if (!QFileInfo::exists(bootloader)) {
        m_submitError = QStringLiteral("Bootloader 不存在");
        return {};
    }
    const QString media = request.media.isEmpty() ? QStringLiteral("sd") : request.media.toLower();
    if (mediaNeedsImage(media) && !QFileInfo::exists(image)) {
        m_submitError = QStringLiteral("镜像不存在");
        return {};
    }

    QVector<DeviceInfo> targets;
    for (const DeviceInfo& device : m_devices) {
        if (!request.usbPath.isEmpty() && device.usbPath != request.usbPath)
            continue;
        if (isFlashTarget(device))
            targets.push_back(device);
    }
    if (targets.isEmpty()) {
        m_submitError = QStringLiteral("没有处于串行下载的已配置芯片");
        return {};
    }

    m_lastBatch.clear();
    QStringList ids;
    for (const DeviceInfo& device : targets) {
        const QString id = startJob(device, request);
        if (!id.isEmpty())
            ids << id;
    }
    if (ids.isEmpty())
        m_submitError = QStringLiteral("没有启动任何烧录");
    return ids;
}

QString TaskManager::startJob(const DeviceInfo& device, const FlashRequest& request)
{
    const ChipConfig chip = m_config.chipConfig(device.chip);
    const QString media = request.media.isEmpty() ? chip.mediaDefault : request.media.toLower();
    QString script = chip.scripts.value(media, chip.script);
    if (!request.scriptName.isEmpty())
        script = request.scriptName;
    if (!request.scriptPath.isEmpty())
        script = request.scriptPath;
    if (!chip.valid || script.isEmpty())
        return {};

    auto* job = new Job;
    QString usbTag = device.usbPath;
    usbTag.replace(QLatin1Char(':'), QLatin1Char('_'));
    job->task.id = QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd_HHmmss_zzz"))
        + QLatin1Char('_') + usbTag;
    job->task.startedAt = QDateTime::currentDateTime();
    job->task.device = device;
    job->task.bootloaderPath = QFileInfo(request.bootloaderPath).absoluteFilePath();
    job->task.linuxImagePath = QFileInfo(request.linuxImagePath).absoluteFilePath();
    job->task.boardName = request.boardName;
    job->task.target = mediaDisplayName(media);
    job->task.state = TaskState::Running;
    job->task.stage = TaskStage::WaitDevice;
    job->task.percent = 0;
    job->task.logPath = QDir(logDirectory()).filePath(job->task.id + QStringLiteral(".log"));
    QDir().mkpath(QFileInfo(job->task.logPath).absolutePath());
    job->log = new QFile(job->task.logPath);
    if (!job->log->open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text))
        job->lastOutput = QStringLiteral("无法写入日志");

    job->uuu = new UUUAdapter(this);
    job->uuu->setTimeoutSeconds(m_config.timeoutSeconds());
    if (!m_config.uuuPath().isEmpty())
        job->uuu->setExecutable(m_config.uuuPath());

    const QString id = job->task.id;
    m_jobs.insert(id, job);
    connect(job->uuu, &UUUAdapter::output, this, [this, id](const QString& line) {
        onJobOutput(id, line);
    });
    connect(job->uuu, &UUUAdapter::stageChanged, this, [this, id](TaskStage stage, int percent) {
        onJobStage(id, stage, percent);
    });
    connect(job->uuu, &UUUAdapter::finished, this, [this, id](int exitCode, bool success, FlashError error) {
        onJobFinished(id, exitCode, success, error);
    });

    m_history.prepend(job->task);
    m_lastBatch.push_back(job->task);
    persist();
    emit taskChanged(job->task);

    FlashRequest command = request;
    command.bootloaderPath = job->task.bootloaderPath;
    command.linuxImagePath = job->task.linuxImagePath;
    command.media = media;
    command.scriptName = script;
    command.usbPath = device.usbPath;
    command.target = mediaDisplayName(media);
    if (!mediaNeedsImage(media))
        command.linuxImagePath.clear();
    onJobOutput(id, QStringLiteral("开始烧录：脚本 %1，USB %2").arg(script, device.usbPath));
    job->uuu->start(device, command);
    return id;
}

void TaskManager::verifyCrc(const FlashRequest& request)
{
    if (isFlashing() || m_uuu.isRunning() || !m_uuu.executableFound())
        return;
    const QString image = QFileInfo(request.linuxImagePath).absoluteFilePath();
    if (request.linuxImagePath.isEmpty() || !QFileInfo::exists(image))
        return;

    // 读回校验只支持 mmc 块设备（SD / eMMC）；NAND/QSPI/SPI NAND/NVMe 没有对应流程。
    const QString media = request.media.isEmpty() ? QStringLiteral("sd") : request.media.toLower();
    if (!mediaSupportsCrcVerify(media))
        return;
    const QString deviceVar = media == QLatin1String("emmc")
        ? QStringLiteral("${emmc_dev}") : QStringLiteral("${sd_dev}");

    const QString scriptDir = QDir(storageDir()).filePath(QStringLiteral("scripts"));
    QDir().mkpath(scriptDir);
    const QString scriptPath = QDir(scriptDir).filePath(QStringLiteral("verify_%1.lst").arg(media));
    {
        QFile file(scriptPath);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
            return;
        file.write(QStringLiteral(
            "uuu_version 1.5.243\n"
            "\n"
            "# @_image                | wic image to verify (read back and compare CRC32)\n"
            "\n"
            "FB: ucmd setenv fastboot_dev mmc\n"
            "FB: ucmd setenv mmcdev %1\n"
            "FB: ucmd mmc dev %1\n"
            "FB: crc -f _image -seek 0x800000 -skip 0x800000\n"
            "FB: done\n").arg(deviceVar).toUtf8());
    }

    m_utility = true;
    m_utilityTitle = QStringLiteral("读回校验");
    emit activityChanged();
    emit logLine(QString(),
                  QStringLiteral("开始读回校验：uuu -b %1 %2（跳过前 8MB 启动区）").arg(scriptPath, image));
    m_uuu.runUtility({QStringLiteral("-t"), QString::number(m_config.timeoutSeconds()),
                       QStringLiteral("-b"), scriptPath, image},
                      QFileInfo(image).absolutePath());
}

void TaskManager::resetDevice()
{
    if (isFlashing() || m_uuu.isRunning() || !m_uuu.executableFound())
        return;
    m_utility = true;
    m_utilityTitle = QStringLiteral("重启设备");
    emit activityChanged();
    emit logLine(QString(),
                  QStringLiteral("重启设备：uuu FB: reboot"));
    m_uuu.runUtility({QStringLiteral("-t"), QString::number(m_config.timeoutSeconds()),
                       QStringLiteral("FB:"), QStringLiteral("reboot")},
                      QDir::tempPath());
}

// 刷新 FAT 分区列表：主机侧解析所选 wic 镜像的分区表（板子刷的就是它，布局一致）。
// 板子停在 Fastboot 时再跑一次 mmc part：uuu 若能取到板子的真实输出，就用板子的覆盖。
void TaskManager::listFatPartitions(const QString& media)
{
    if (isFlashing() || m_uuu.isRunning() || !m_uuu.executableFound())
        return;
    const QString key = media.isEmpty() ? QStringLiteral("sd") : media.toLower();
    if (!mediaSupportsFat(key))
        return;

    m_partitions.clear();
    m_partitionsError.clear();
    const QString image = m_config.linuxImagePath();
    if (!image.isEmpty() && QFileInfo::exists(image))
        m_partitions = PartitionTable::parseImage(image);
    if (m_partitions.isEmpty())
        m_partitionsError = QStringLiteral("请先选好 Linux 镜像（.wic），分区表从镜像读取");

    const QVector<DeviceInfo> devices = m_devices;
    const bool fastboot = devices.size() == 1
        && devices.first().protocol.compare(QStringLiteral("FB"), Qt::CaseInsensitive) == 0;
    if (!fastboot) {
        // 板子不在 Fastboot：直接用镜像解析结果。
        emit partitionsChanged(m_partitions);
        emit activityChanged();
        return;
    }

    const QString deviceVar = key == QLatin1String("emmc")
        ? QStringLiteral("${emmc_dev}") : QStringLiteral("${sd_dev}");
    const QString scriptDir = QDir(storageDir()).filePath(QStringLiteral("scripts"));
    QDir().mkpath(scriptDir);
    const QString scriptPath = QDir(scriptDir).filePath(QStringLiteral("list_parts.lst"));
    {
        QFile file(scriptPath);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            emit partitionsChanged(m_partitions);
            emit activityChanged();
            return;
        }
        file.write(QStringLiteral(
            "uuu_version 1.5.243\n"
            "\n"
            "# 列出当前启动介质（mmc）的分区表，用于确定 FAT 分区号。\n"
            "FB: ucmd mmc dev %1\n"
            "FB: ucmd mmc part\n"
            "FB: done\n").arg(deviceVar).toUtf8());
    }

    m_utility = true;
    m_listingParts = true;
    m_utilityTitle = QStringLiteral("读取分区");
    emit activityChanged();
    emit logLine(QString(),
                  QStringLiteral("读取 %1 分区表：uuu -b list_parts.lst")
                      .arg(mediaDisplayName(key)));
    m_uuu.listPartitions(scriptPath);
}

// 写入 FAT 分区文件：uuu -b fat_write <文件> mmc <设备号:分区号> <目标文件名>（要求板子在 Fastboot）。
void TaskManager::writeFatFile(const QString& filePath, const QString& media,
                              const QString& devicePartition, const QString& targetName)
{
    if (isFlashing() || m_uuu.isRunning() || !m_uuu.executableFound())
        return;
    if (filePath.isEmpty() || !QFileInfo::exists(filePath))
        return;
    const QString key = media.isEmpty() ? QStringLiteral("sd") : media.toLower();
    if (!mediaSupportsFat(key) || devicePartition.isEmpty())
        return;
    const QString name = targetName.isEmpty() ? QFileInfo(filePath).fileName() : targetName;

    m_utility = true;
    m_utilityTitle = QStringLiteral("写入 FAT 分区文件");
    emit activityChanged();
    emit logLine(QString(),
                  QStringLiteral("写入 FAT 分区：uuu -b fat_write %1 mmc %2 %3")
                      .arg(QFileInfo(filePath).fileName(), devicePartition, name));
    m_uuu.runUtility({QStringLiteral("-t"), QString::number(m_config.timeoutSeconds()),
                       QStringLiteral("-b"), QStringLiteral("fat_write"),
                       QFileInfo(filePath).absoluteFilePath(),
                       QStringLiteral("mmc"), devicePartition, name},
                      QFileInfo(filePath).absolutePath());
}

void TaskManager::cancel(const QString& taskId)
{
    Job* job = m_jobs.value(taskId, nullptr);
    if (!job || job->task.state != TaskState::Running)
        return;
    job->cancelRequested = true;
    job->uuu->cancel();
}

void TaskManager::cancelAll()
{
    const QStringList ids = m_jobs.keys();
    for (const QString& id : ids)
        cancel(id);
}

void TaskManager::setBootChecked(const QString& taskId, bool checked)
{
    for (TaskRecord& task : m_history) {
        if (task.id != taskId || task.state != TaskState::Succeeded)
            continue;
        task.bootChecked = checked;
        if (Job* job = m_jobs.value(taskId, nullptr))
            job->task.bootChecked = checked;
        persist();
        emit taskChanged(task);
        return;
    }
}

void TaskManager::setExecutable(const QString& path)
{
    m_config.setUuuPath(path);
    m_uuu.setExecutable(path);
}

void TaskManager::beginQuit()
{
    m_quitting = true;
    cancelAll();
}

QVector<TaskRecord> TaskManager::history() const
{
    return m_history;
}

QVector<TaskRecord> TaskManager::running() const
{
    QVector<TaskRecord> tasks;
    for (Job* job : m_jobs)
        tasks.push_back(job->task);
    return tasks;
}

QVector<TaskRecord> TaskManager::lastBatch() const
{
    return m_lastBatch;
}

void TaskManager::reloadHistory()
{
    m_history.clear();
    load();
}

QVector<DeviceInfo> TaskManager::devices() const
{
    return m_devices;
}

QString TaskManager::detectError() const
{
    return m_detectError;
}

FlashError TaskManager::detectErrorCode() const
{
    return m_detectErrorCode;
}

bool TaskManager::isDetecting() const
{
    return m_detecting;
}

bool TaskManager::isFlashing() const
{
    return !m_jobs.isEmpty();
}

bool TaskManager::isUtilityRunning() const
{
    return m_utility;
}

QString TaskManager::utilityTitle() const
{
    return m_utilityTitle;
}

QVector<FatPartition> TaskManager::partitions() const
{
    return m_partitions;
}

// 只返回按类型码识别出的 FAT 分区；识别不出（如 GPT）时返回空，由界面回退列出全部。
QVector<FatPartition> TaskManager::fatPartitions() const
{
    return OutputParser::fatPartitions(m_partitions);
}

QString TaskManager::partitionsError() const
{
    return m_partitionsError;
}

bool TaskManager::isListingPartitions() const
{
    return m_listingParts;
}

bool TaskManager::isQuitting() const
{
    return m_quitting;
}

QString TaskManager::storageDir() const
{
    const QString dir = m_config.dataDir();
    if (!dir.isEmpty()) {
        QDir().mkpath(dir);
        return dir;
    }
    return appStorageDir();
}

QString TaskManager::logDirectory() const
{
    const QString dir = m_config.logDir();
    return QDir::isAbsolutePath(dir) ? dir : QDir(storageDir()).filePath(dir);
}

void TaskManager::load()
{
    QByteArray data;
    {
        QFile file(QDir(storageDir()).filePath(QStringLiteral("tasks.json")));
        if (!file.open(QIODevice::ReadOnly))
            return;
        data = file.readAll();
    }
    const QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isArray())
        return;
    bool dirty = false;
    for (const QJsonValue& value : doc.array()) {
        if (!value.isObject())
            continue;
        TaskRecord task = fromJson(value.toObject());
        if (task.id.isEmpty())
            continue;
        if (task.state == TaskState::Running) {
            task.state = TaskState::Failed;
            task.message = QStringLiteral("未完成");
            if (!task.endedAt.isValid())
                task.endedAt = QDateTime::currentDateTime();
            dirty = true;
        }
        m_history.push_back(task);
    }
    if (dirty)
        persist();
}

void TaskManager::persist()
{
    QJsonArray array;
    for (const TaskRecord& task : m_history)
        array.append(toJson(task));
    QSaveFile file(QDir(storageDir()).filePath(QStringLiteral("tasks.json")));
    if (!file.open(QIODevice::WriteOnly))
        return;
    file.write(QJsonDocument(array).toJson(QJsonDocument::Indented));
    file.commit();
}

void TaskManager::replaceHistory(const TaskRecord& task)
{
    for (TaskRecord& item : m_history) {
        if (item.id == task.id) {
            item = task;
            return;
        }
    }
    m_history.prepend(task);
}

void TaskManager::onDevices(QVector<DeviceInfo> devices, QString error)
{
    m_detecting = false;
    m_devices = devices;
    m_detectError = error;
    m_detectErrorCode = classifyDetect(devices, error);
    emit devicesChanged(devices);
    emit activityChanged();
}

void TaskManager::onPartitions(QVector<FatPartition> partitions, QString error)
{
    m_utility = false;
    m_listingParts = false;
    if (!partitions.isEmpty()) {
        // uuu 取到了板子的真实分区，用它覆盖镜像解析结果。
        m_partitions = partitions;
        m_partitionsError.clear();
    } else if (!error.isEmpty()) {
        m_partitionsError = error;
    }
    emit partitionsChanged(m_partitions);
    emit activityChanged();
}

void TaskManager::onJobOutput(const QString& id, const QString& line)
{
    Job* job = m_jobs.value(id, nullptr);
    if (!job || job->task.state != TaskState::Running)
        return;
    job->lastOutput = line;
    const QString stamped = formatStamp() + QStringLiteral("[%1] %2").arg(job->task.device.usbPath, line);
    if (job->log && job->log->isOpen()) {
        job->log->write(stamped.toUtf8());
        job->log->write("\n", 1);
        job->log->flush();
    }
    emit logLine(id, stamped);
}

void TaskManager::onJobStage(const QString& id, TaskStage stage, int percent)
{
    Job* job = m_jobs.value(id, nullptr);
    if (!job || job->task.state != TaskState::Running)
        return;
    job->task.stage = stage;
    job->task.percent = percent;
    replaceHistory(job->task);
    for (TaskRecord& item : m_lastBatch) {
        if (item.id == id)
            item = job->task;
    }
    emit taskChanged(job->task);
}

void TaskManager::onUtilityFinished(int exitCode, bool success, QString message)
{
    Q_UNUSED(exitCode);
    m_utility = false;
    emit activityChanged();
    emit utilityFinished(m_utilityTitle, success, message);
}

void TaskManager::onJobFinished(const QString& id, int exitCode, bool success, FlashError error)
{
    Job* job = m_jobs.value(id, nullptr);
    if (!job || job->task.state != TaskState::Running)
        return;
    job->task.endedAt = QDateTime::currentDateTime();
    job->task.exitCode = exitCode;
    if (job->cancelRequested || error == FlashError::Cancelled) {
        job->task.state = TaskState::Cancelled;
        job->task.errorCode = FlashError::Cancelled;
        job->task.message = QStringLiteral("已取消");
    } else if (success) {
        job->task.state = TaskState::Succeeded;
        job->task.errorCode = FlashError::None;
        job->task.stage = TaskStage::Finish;
        job->task.percent = 100;
        job->task.message.clear();
    } else {
        job->task.state = TaskState::Failed;
        job->task.errorCode = error == FlashError::None ? FlashError::FlashImageFailed : error;
        job->task.message = job->lastOutput.isEmpty() ? QStringLiteral("烧录失败") : job->lastOutput;
    }
    if (job->log)
        job->log->close();
    replaceHistory(job->task);
    for (TaskRecord& item : m_lastBatch) {
        if (item.id == id)
            item = job->task;
    }
    persist();
    const TaskRecord done = job->task;
    job->uuu->deleteLater();
    delete job->log;
    m_jobs.remove(id);
    delete job;
    emit taskChanged(done);
    if (m_jobs.isEmpty() && !m_quitting)
        detect();
}

FlashError TaskManager::classifyDetect(const QVector<DeviceInfo>& devices, const QString& error) const
{
    if (error.contains(QStringLiteral("未找到")))
        return FlashError::ToolMissing;
    if (devices.isEmpty())
        return FlashError::NoDevice;
    for (const DeviceInfo& device : devices) {
        if (isFlashTarget(device))
            return FlashError::None;
    }
    return FlashError::WrongDevice;
}
