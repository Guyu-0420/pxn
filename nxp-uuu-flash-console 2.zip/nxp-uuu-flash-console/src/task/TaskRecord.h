#pragma once

#include <QDateTime>
#include <QMetaType>
#include <QString>
#include <QStringList>
#include <QVector>

enum class TaskState {
    Idle,
    Detecting,
    Ready,
    Running,
    Succeeded,
    Failed,
    Cancelled
};

enum class TaskStage {
    WaitDevice,
    LoadBootloader,
    WaitFastboot,
    FlashImage,
    Finish
};

// 错误分类，对齐开发文档第 9 章。
enum class FlashError {
    None,
    ToolMissing,
    NoDevice,
    WrongDevice,
    MultiDevice,
    ConfigMissing,
    LoadBootloaderFailed,
    WaitFastbootTimeout,
    FlashImageFailed,
    VerifyFailed,
    PermissionDenied,
    VersionMismatch,
    Cancelled
};

struct DeviceInfo {
    QString usbPath;
    QString chip;
    QString protocol;
    QString vid;
    QString pid;
    QString raw;
};

struct FlashRequest {
    QString bootloaderPath;
    QString linuxImagePath;
    QString boardName;
    QString media = QStringLiteral("sd");
    QString scriptName;  // 内置脚本名；空时按介质取 cfg [script]
    QString scriptPath;   // 自定义 .lst 脚本路径；非空时优先于 scriptName
    QString usbPath;      // 空 = 所有处于串行下载的已配置芯片
    QString target = QStringLiteral("SD");
};

// FAT 分区（板子 mmc part 输出里的一个分区）。
// device = "Partition Map for MMC device N" 里的 N；number = 分区号。
struct FatPartition {
    int device = -1;
    int number = 0;
    QString type;     // DOS 分区类型码（如 "0c"）；GPT 或未知时为空
    QString name;     // 分区名 / 标签（有则填）
    bool fat = false; // 按类型码判定为 FAT

    QString id() const { return QStringLiteral("%1:%2").arg(device).arg(number); }

    // 传给 fatwrite 的分区参数 <设备号>:<分区号>；设备号未知（主机侧解析镜像）时用 u-boot 变量。
    QString writeArg(const QString& deviceVar) const
    {
        if (device < 0)
            return QStringLiteral("${%1}:%2").arg(deviceVar).arg(number);
        return QStringLiteral("%1:%2").arg(device).arg(number);
    }

    QString display() const
    {
        QString text = id();
        QStringList tags;
        if (!type.isEmpty())
            tags << type;
        if (!name.isEmpty())
            tags << name;
        if (!tags.isEmpty())
            text += QStringLiteral("（%1）").arg(tags.join(QLatin1Char(' ')));
        return text;
    }
};

struct TaskRecord {
    QString id;
    QDateTime startedAt;
    QDateTime endedAt;
    DeviceInfo device;
    QString bootloaderPath;
    QString linuxImagePath;
    QString boardName;
    QString target = QStringLiteral("SD");
    TaskState state = TaskState::Idle;
    TaskStage stage = TaskStage::WaitDevice;
    int percent = 0;
    int exitCode = -1;
    FlashError errorCode = FlashError::None;
    QString message;
    bool bootChecked = false;
    QString logPath;
};

// 目标介质：uuu 内置脚本名 → 显示名；整卡 wic 只适用于块设备。
inline QString mediaDisplayName(const QString& media)
{
    const QString key = media.toLower();
    if (key == QLatin1String("sd")) return QStringLiteral("SD 卡");
    if (key == QLatin1String("emmc")) return QStringLiteral("eMMC");
    if (key == QLatin1String("nand")) return QStringLiteral("NAND");
    if (key == QLatin1String("qspi")) return QStringLiteral("QSPI NOR");
    if (key == QLatin1String("spi_nand")) return QStringLiteral("SPI NAND");
    if (key == QLatin1String("nvme")) return QStringLiteral("NVMe");
    return media;
}

inline bool mediaNeedsImage(const QString& media)
{
    const QString key = media.toLower();
    return key == QLatin1String("sd") || key == QLatin1String("emmc")
        || key == QLatin1String("nvme");
}

// 读回校验（FB: crc 从存储读回比对）只适用于 mmc 块设备（SD / eMMC）。
inline bool mediaSupportsCrcVerify(const QString& media)
{
    const QString key = media.toLower();
    return key == QLatin1String("sd") || key == QLatin1String("emmc");
}

// FAT 分区文件写入（uuu 内置脚本 fat_write）只适用于带 FAT 的块设备（SD / eMMC）。
inline bool mediaSupportsFat(const QString& media)
{
    const QString key = media.toLower();
    return key == QLatin1String("sd") || key == QLatin1String("emmc");
}

// 串行下载：i.MX 8/9 的 SDPS，以及 i.MX 8M Mini / Quad 的 SDP。FB 是烧录中转，不能当开始状态。
inline bool isSerialDownload(const QString& protocol)
{
    const QString key = protocol.toUpper();
    return key == QLatin1String("SDPS") || key == QLatin1String("SDP");
}

inline bool isFlashableDevice(const DeviceInfo& device)
{
    return isSerialDownload(device.protocol);
}

inline QString taskStateName(TaskState state)
{
    switch (state) {
    case TaskState::Idle: return QStringLiteral("Idle");
    case TaskState::Detecting: return QStringLiteral("Detecting");
    case TaskState::Ready: return QStringLiteral("Ready");
    case TaskState::Running: return QStringLiteral("Running");
    case TaskState::Succeeded: return QStringLiteral("Succeeded");
    case TaskState::Failed: return QStringLiteral("Failed");
    case TaskState::Cancelled: return QStringLiteral("Cancelled");
    }
    return QStringLiteral("Idle");
}

inline TaskState taskStateFromName(const QString& name)
{
    if (name == QLatin1String("Detecting")) return TaskState::Detecting;
    if (name == QLatin1String("Ready")) return TaskState::Ready;
    if (name == QLatin1String("Running")) return TaskState::Running;
    if (name == QLatin1String("Succeeded")) return TaskState::Succeeded;
    if (name == QLatin1String("Failed")) return TaskState::Failed;
    if (name == QLatin1String("Cancelled")) return TaskState::Cancelled;
    return TaskState::Idle;
}

inline QString flashErrorName(FlashError error)
{
    switch (error) {
    case FlashError::None: return QStringLiteral("None");
    case FlashError::ToolMissing: return QStringLiteral("ToolMissing");
    case FlashError::NoDevice: return QStringLiteral("NoDevice");
    case FlashError::WrongDevice: return QStringLiteral("WrongDevice");
    case FlashError::MultiDevice: return QStringLiteral("MultiDevice");
    case FlashError::ConfigMissing: return QStringLiteral("ConfigMissing");
    case FlashError::LoadBootloaderFailed: return QStringLiteral("LoadBootloaderFailed");
    case FlashError::WaitFastbootTimeout: return QStringLiteral("WaitFastbootTimeout");
    case FlashError::FlashImageFailed: return QStringLiteral("FlashImageFailed");
    case FlashError::VerifyFailed: return QStringLiteral("VerifyFailed");
    case FlashError::PermissionDenied: return QStringLiteral("PermissionDenied");
    case FlashError::VersionMismatch: return QStringLiteral("VersionMismatch");
    case FlashError::Cancelled: return QStringLiteral("Cancelled");
    }
    return QStringLiteral("None");
}

inline FlashError flashErrorFromName(const QString& name)
{
    if (name == QLatin1String("ToolMissing")) return FlashError::ToolMissing;
    if (name == QLatin1String("NoDevice")) return FlashError::NoDevice;
    if (name == QLatin1String("WrongDevice")) return FlashError::WrongDevice;
    if (name == QLatin1String("MultiDevice")) return FlashError::MultiDevice;
    if (name == QLatin1String("ConfigMissing")) return FlashError::ConfigMissing;
    if (name == QLatin1String("LoadBootloaderFailed")) return FlashError::LoadBootloaderFailed;
    if (name == QLatin1String("WaitFastbootTimeout")) return FlashError::WaitFastbootTimeout;
    if (name == QLatin1String("FlashImageFailed")) return FlashError::FlashImageFailed;
    if (name == QLatin1String("VerifyFailed")) return FlashError::VerifyFailed;
    if (name == QLatin1String("PermissionDenied")) return FlashError::PermissionDenied;
    if (name == QLatin1String("VersionMismatch")) return FlashError::VersionMismatch;
    if (name == QLatin1String("Cancelled")) return FlashError::Cancelled;
    return FlashError::None;
}

inline QString flashErrorText(FlashError error)
{
    switch (error) {
    case FlashError::None: return QString();
    case FlashError::ToolMissing: return QStringLiteral("未找到 uuu.exe");
    case FlashError::NoDevice: return QStringLiteral("未连接");
    case FlashError::WrongDevice: return QStringLiteral("当前不是串行下载模式（SDPS/SDP）");
    case FlashError::MultiDevice: return QStringLiteral("检测到多台设备");
    case FlashError::ConfigMissing: return QStringLiteral("配置不完整");
    case FlashError::LoadBootloaderFailed: return QStringLiteral("载入 Bootloader 失败");
    case FlashError::WaitFastbootTimeout: return QStringLiteral("等待 Fastboot 超时");
    case FlashError::FlashImageFailed: return QStringLiteral("写入镜像失败");
    case FlashError::VerifyFailed: return QStringLiteral("镜像校验失败");
    case FlashError::PermissionDenied: return QStringLiteral("驱动或权限问题");
    case FlashError::VersionMismatch: return QStringLiteral("Bootloader 与镜像版本不一致");
    case FlashError::Cancelled: return QStringLiteral("已取消");
    }
    return QString();
}

Q_DECLARE_METATYPE(DeviceInfo)
Q_DECLARE_METATYPE(TaskRecord)
Q_DECLARE_METATYPE(FlashError)
Q_DECLARE_METATYPE(QVector<DeviceInfo>)
Q_DECLARE_METATYPE(QVector<FatPartition>)
