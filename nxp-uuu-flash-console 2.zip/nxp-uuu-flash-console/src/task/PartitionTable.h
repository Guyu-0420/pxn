#pragma once

#include "task/TaskRecord.h"

#include <QString>

// 从磁盘镜像（.wic）读 MBR / GPT 分区表，返回分区列表（含 FAT 判定）。
//
// 为什么用镜像而不是板子：uuu 取不到 u-boot 控制台输出（`FB: ucmd mmc part`
// 只回 Okay，不回分区表），所以改在主机侧解析镜像。板子刷的就是这个镜像，
// 分区号与板子实际一致。device 留 -1，写 fatwrite 时用 u-boot 变量 ${sd_dev}。
namespace PartitionTable {

QVector<FatPartition> parseImage(const QString& imagePath);

} // namespace PartitionTable