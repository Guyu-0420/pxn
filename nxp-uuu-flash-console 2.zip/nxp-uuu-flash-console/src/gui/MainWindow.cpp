#include "gui/MainWindow.h"

#include "gui/AppIcon.h"
#include "gui/TaskHistoryDialog.h"
#include "task/BspPackage.h"

#include <QCheckBox>
#include <QComboBox>
#include <QCryptographicHash>
#include <QDateTime>
#include <QDesktopServices>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFont>
#include <QFormLayout>
#include <QFrame>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QIcon>
#include <QInputDialog>
#include <QMenuBar>
#include <QMessageBox>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QSaveFile>
#include <QSignalBlocker>
#include <QSizePolicy>
#include <QStandardPaths>
#include <QStorageInfo>
#include <QTabWidget>
#include <QTimer>
#include <QUrl>
#include <QVBoxLayout>

namespace {

QString durationText(const QDateTime& start, const QDateTime& end)
{
    qint64 seconds = start.secsTo(end);
    if (seconds < 0)
        seconds = 0;
    return QStringLiteral("%1分%2秒").arg(seconds / 60).arg(seconds % 60);
}

QWidget* fieldPair(const QString& name, QLabel** value)
{
    auto box = new QWidget;
    auto layout = new QHBoxLayout(box);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(6);
    auto title = new QLabel(name);
    title->setStyleSheet(QStringLiteral("color:#667085;"));
    *value = new QLabel(QStringLiteral("—"));
    (*value)->setStyleSheet(QStringLiteral("font-weight:600;"));
    layout->addWidget(title);
    layout->addWidget(*value);
    return box;
}

void paintStep(QLabel* label, const QString& title, const QString& mode)
{
    QString text = title;
    QString style = QStringLiteral("color:#98a2b3;background:#f2f4f7;border-radius:4px;padding:6px 8px;");
    if (mode == QLatin1String("done")) {
        text = QStringLiteral("✓ ") + title;
        style = QStringLiteral("color:#067647;background:#ecfdf3;border-radius:4px;padding:6px 8px;");
    } else if (mode == QLatin1String("current")) {
        style = QStringLiteral("color:#0f6b4c;background:#e8f6f0;border-radius:4px;padding:6px 8px;font-weight:600;");
    } else if (mode == QLatin1String("failed")) {
        text = QStringLiteral("× ") + title;
        style = QStringLiteral("color:#b42318;background:#fef3f2;border-radius:4px;padding:6px 8px;font-weight:600;");
    }
    label->setText(text);
    label->setStyleSheet(style);
}

// 读分区表 / 写 FAT 都要求板子停在 Fastboot（刚烧录完就是）。
bool isFastbootDevice(const DeviceInfo& device)
{
    return device.protocol.compare(QStringLiteral("FB"), Qt::CaseInsensitive) == 0;
}

} // namespace

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
{
    setWindowTitle(QStringLiteral("NXP UUU Flash Console"));
    setWindowIcon(QIcon(appIconPixmap(64)));
    resize(1160, 780);
    setMinimumSize(1000, 640);
    buildUi();
    loadSettings();

    connect(&m_tasks, &TaskManager::taskChanged, this, &MainWindow::onTask);
    connect(&m_tasks, &TaskManager::logLine, this, &MainWindow::onLog);
    connect(&m_tasks, &TaskManager::devicesChanged, this, [this] { updateUi(); });
    connect(&m_tasks, &TaskManager::activityChanged, this, [this] { updateUi(); });
    connect(&m_tasks, &TaskManager::utilityFinished, this, &MainWindow::onUtility);
    connect(m_detectBtn, &QPushButton::clicked, this, &MainWindow::detect);
    connect(m_startBtn, &QPushButton::clicked, this, &MainWindow::startFlash);
    connect(m_cancelBtn, &QPushButton::clicked, this, [this] {
        if (m_extractor.isRunning())
            m_extractor.cancel();
        else
            m_tasks.cancelAll();
    });
    connect(m_boardBox, &QComboBox::currentIndexChanged, this, [this] {
        m_tasks.config().setBoardId(m_boardBox->currentData().toString());
        updateUi();
    });
    connect(&m_extractor, &BspExtractor::output, this,
            [this](const QString& text) { m_log->appendPlainText(text); });
    connect(&m_extractor, &BspExtractor::finished, this, &MainWindow::onExtractFinished);
    connect(m_bootBrowse, &QPushButton::clicked, this, &MainWindow::chooseBootloader);
    connect(m_linuxBrowse, &QPushButton::clicked, this, &MainWindow::chooseLinux);
    connect(m_bootEdit, &QLineEdit::textChanged, this, [this] { saveFiles(); updateUi(); });
    connect(m_linuxEdit, &QLineEdit::textChanged, this, [this] { saveFiles(); updateUi(); });
    connect(m_bootCheck, &QCheckBox::toggled, this, [this](bool checked) {
        if (!m_task.id.isEmpty())
            m_tasks.setBootChecked(m_task.id, checked);
    });
    connect(m_verifyBtn, &QPushButton::clicked, this, [this] {
        FlashRequest request;
        request.bootloaderPath = m_bootEdit->text();
        request.linuxImagePath = m_linuxEdit->text();
        request.media = m_mediaBox ? m_mediaBox->currentData().toString()
                                  : QStringLiteral("sd");
        m_utilityResult->clear();
        m_tasks.verifyCrc(request);
    });
    connect(m_resetBtn, &QPushButton::clicked, this, [this] {
        m_utilityResult->clear();
        m_tasks.resetDevice();
    });
    connect(&m_tasks, &TaskManager::partitionsChanged, this, [this] { onPartitionsChanged(); });


    updateStages(TaskStage::WaitDevice, TaskState::Idle);
    updateResult(m_task);
    updateUi();
    if (m_tasks.config().apiEnabled()) {
        m_api = new FlashApiServer(&m_tasks, this);
        const auto port = static_cast<quint16>(m_tasks.config().apiPort());
        if (!m_api->listen(port))
            m_log->appendPlainText(QStringLiteral("本机 API 未启动：%1").arg(m_api->errorString()));
    }
    m_tasks.detect();
}

void MainWindow::buildUi()
{
    auto menu = menuBar()->addMenu(QStringLiteral("菜单"));
    menu->addAction(QStringLiteral("导入配置…"), this, &MainWindow::importConfig);
    menu->addAction(QStringLiteral("导出配置…"), this, &MainWindow::exportConfig);
    menu->addAction(QStringLiteral("任务记录"), this, &MainWindow::openHistory);
    menu->addAction(QStringLiteral("数据保存位置…"), this, &MainWindow::chooseDataDir);
    menu->addAction(QStringLiteral("UUU 路径"), this, &MainWindow::chooseUuu);
    menu->addAction(QStringLiteral("下载 UUU"), this, &MainWindow::downloadUuu);
    menu->addAction(QStringLiteral("进入串行下载"), this, &MainWindow::goMaskrom);
    menu->addAction(QStringLiteral("打开镜像下载页"), this, &MainWindow::openDownloadPage);
    menu->addAction(QStringLiteral("打开入门指南"), this, &MainWindow::openGettingStarted);
    menu->addAction(QStringLiteral("功能说明"), this, [this] {
        if (m_tabs && m_guideTab)
            m_tabs->setCurrentWidget(m_guideTab);
    });
    m_advAction = menu->addAction(QStringLiteral("显示高级页"));
    m_advAction->setCheckable(true);
    m_advAction->setChecked(m_tasks.config().advancedTab());
    connect(m_advAction, &QAction::toggled, this, [this](bool on) {
        m_tasks.config().setAdvancedTab(on);
        updateAdvancedTab();
    });
    menu->addAction(QStringLiteral("关于"), this, &MainWindow::about);

    auto central = new QWidget(this);
    auto root = new QVBoxLayout(central);
    root->setContentsMargins(16, 10, 16, 12);
    root->setSpacing(8);
    setCentralWidget(central);
    setStyleSheet(QStringLiteral(
        "QMainWindow, QWidget, QMenuBar { background:#f3f4f6; color:#1f2933; font-size:13px; }"
        "QGroupBox { background:#ffffff; border:1px solid #e4e7ec; border-radius:10px; margin-top:10px; padding:8px 12px 10px 12px; font-weight:600; }"
        "QGroupBox::title { subcontrol-origin:margin; subcontrol-position:top left; left:12px; padding:0 6px; background:#f3f4f6; }"
        "QLineEdit { background:#ffffff; border:1px solid #cfd6e0; border-radius:6px; padding:5px 8px; font-weight:400; }"
        "QLineEdit:focus { border:1px solid #0f6b4c; }"
        "QPlainTextEdit { background:#ffffff; border:1px solid #e4e7ec; border-radius:8px; padding:8px; font-family:Consolas, monospace; font-weight:400; }"
        "QComboBox { background:#ffffff; border:1px solid #cfd6e0; border-radius:6px; padding:4px 8px; font-weight:400; }"
        "QComboBox::drop-down { border:none; width:24px; }"
        "QLabel { background:transparent; font-weight:400; }"
        "QPushButton { background:#ffffff; border:1px solid #c5ced9; border-radius:6px; padding:6px 14px; font-weight:400; }"
        "QPushButton:hover { background:#f9fafb; border:1px solid #98a2b3; }"
        "QPushButton:pressed { background:#eef2f6; }"
        "QPushButton:disabled { color:#98a2b3; background:#f2f4f7; border:1px solid #e4e7ec; }"
        "QPushButton#startButton { background:#0f6b4c; color:#ffffff; border:1px solid #0f6b4c; font-weight:600; padding:6px 18px; }"
        "QPushButton#startButton:hover { background:#0d5c41; }"
        "QPushButton#startButton:pressed { background:#0b4f38; }"
        "QPushButton#startButton:disabled { background:#d8e5df; color:#6b7c75; border:1px solid #d8e5df; }"
        "QProgressBar { border:1px solid #e4e7ec; border-radius:6px; background:#eef1f5; text-align:center; height:20px; font-weight:400; }"
        "QProgressBar::chunk { background:#0f6b4c; border-radius:5px; }"
        "QCheckBox { font-weight:400; }"
        "QTabWidget::pane { border:none; background:transparent; }"
        "QTabBar::tab { background:#e4e7ec; border:none; padding:6px 16px; margin-right:4px; border-top-left-radius:6px; border-top-right-radius:6px; }"
        "QTabBar::tab:selected { background:#ffffff; font-weight:600; }"
        "QListWidget { background:#ffffff; border:1px solid #e4e7ec; border-radius:10px; padding:6px; outline:none; }"
        "QListWidget::item { padding:10px 8px; border-radius:6px; }"
        "QListWidget::item:selected { background:#e8f6f0; color:#0f6b4c; }"
        "QTextEdit#guideHow { background:#ffffff; border:none; font-size:13px; }"
        "QMenu { background:#ffffff; border:1px solid #e4e7ec; }"));

    auto header = new QHBoxLayout;
    header->setSpacing(12);
    auto logo = new QLabel;
    QPixmap logoPixmap = appIconPixmap(80);
    logoPixmap.setDevicePixelRatio(2.0);
    logo->setPixmap(logoPixmap);
    logo->setFixedSize(40, 40);
    header->addWidget(logo, 0, Qt::AlignVCenter);
    auto titleCol = new QVBoxLayout;
    titleCol->setSpacing(1);
    auto appTitle = new QLabel(QStringLiteral("NXP UUU Flash Console"));
    appTitle->setStyleSheet(QStringLiteral("font-size:13px;font-weight:600;color:#101828;"));
    auto appSubtitle = new QLabel(QStringLiteral("状态栏显示当前步骤"));
    appSubtitle->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
    titleCol->addWidget(appTitle);
    titleCol->addWidget(appSubtitle);
    header->addLayout(titleCol);
    header->addStretch(1);
    root->addLayout(header);

    m_banner = new QLabel(QStringLiteral("步骤 1：拨码置于串行下载，USB 接下载口，上电。"));
    m_banner->setMinimumHeight(44);
    m_banner->setWordWrap(true);
    m_banner->setAlignment(Qt::AlignVCenter | Qt::AlignLeft);
    m_banner->setContentsMargins(12, 0, 12, 0);
    root->addWidget(m_banner);

    auto deviceBox = new QGroupBox(QStringLiteral("设备"));
    auto deviceLayout = new QVBoxLayout(deviceBox);
    auto deviceRow = new QHBoxLayout;
    m_dot = new QLabel;
    m_dot->setFixedSize(10, 10);
    deviceRow->addWidget(m_dot, 0, Qt::AlignVCenter);
    deviceRow->addWidget(fieldPair(QStringLiteral("状态"), &m_chip));
    m_protocol = new QLabel;
    m_usb = new QLabel;
    deviceRow->addStretch(1);
    m_detectBtn = new QPushButton(QStringLiteral("检测"));
    deviceRow->addWidget(m_detectBtn);
    deviceLayout->addLayout(deviceRow);
    m_hint = new QLabel;
    m_hint->setWordWrap(true);
    m_hint->setStyleSheet(QStringLiteral("color:#b42318;font-weight:400;"));
    deviceLayout->addWidget(m_hint);
    deviceBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Maximum);

    m_tabs = new QTabWidget;
    m_tabs->setDocumentMode(true);
    auto flashTab = new QWidget;
    auto flashLayout = new QVBoxLayout(flashTab);
    flashLayout->setContentsMargins(0, 8, 0, 0);
    flashLayout->setSpacing(0);

    auto configBox = new QGroupBox(QStringLiteral("烧录配置"));
    configBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    auto configForm = new QFormLayout(configBox);
    configForm->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    configForm->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
    configForm->setHorizontalSpacing(16);
    configForm->setVerticalSpacing(8);

    m_boardBox = new QComboBox;
    configForm->addRow(QStringLiteral("板型"), m_boardBox);
    m_importBtn = nullptr;
    m_exportBtn = nullptr;

    m_bootEdit = new QLineEdit(this);
    m_bootEdit->hide();
    m_linuxEdit = new QLineEdit(this);
    m_linuxEdit->hide();

    auto fileName = [](const QString& text) {
        auto label = new QLabel(text);
        label->setStyleSheet(QStringLiteral("font-weight:600;"));
        label->setTextInteractionFlags(Qt::TextSelectableByMouse);
        return label;
    };
    m_bootName = fileName(QStringLiteral("未选择"));
    m_linuxName = fileName(QStringLiteral("未选择"));
    m_bootBrowse = new QPushButton(QStringLiteral("更换…"));
    m_linuxBrowse = new QPushButton(QStringLiteral("更换…"));
    m_bootBrowse->setToolTip(QStringLiteral("替换单个文件。常规流程使用「选择镜像包…」。"));
    m_linuxBrowse->setToolTip(m_bootBrowse->toolTip());

    m_bootMissing = new QLabel;
    m_bootMissing->setStyleSheet(QStringLiteral("color:#b42318;font-weight:400;"));
    m_linuxMissing = new QLabel;
    m_linuxMissing->setStyleSheet(QStringLiteral("color:#b42318;font-weight:400;"));

    auto bootRow = new QHBoxLayout;
    bootRow->addWidget(m_bootName, 1);
    bootRow->addWidget(m_bootBrowse);
    auto bootWrap = new QVBoxLayout;
    bootWrap->setSpacing(2);
    bootWrap->addLayout(bootRow);
    bootWrap->addWidget(m_bootMissing);

    auto linuxRow = new QHBoxLayout;
    linuxRow->addWidget(m_linuxName, 1);
    linuxRow->addWidget(m_linuxBrowse);
    auto linuxWrap = new QVBoxLayout;
    linuxWrap->setSpacing(2);
    linuxWrap->addLayout(linuxRow);
    linuxWrap->addWidget(m_linuxMissing);

    m_mediaBox = new QComboBox;
    m_mediaBox->setToolTip(QStringLiteral(
        "目标介质须与启动拨码一致：SD 卡 / eMMC / NAND / QSPI NOR / SPI NAND / NVMe。\n"
        "SD、eMMC、NVMe 写入整卡镜像；NAND、QSPI、SPI NAND 仅写入启动文件。"));
    auto targetHint = new QLabel(QStringLiteral("须与拨码一致"));
    targetHint->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
    auto targetRow = new QHBoxLayout;
    targetRow->setSpacing(12);
    targetRow->addWidget(m_mediaBox);
    targetRow->addWidget(targetHint);
    targetRow->addStretch(1);
    configForm->addRow(QStringLiteral("目标介质"), targetRow);
    connect(m_mediaBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [this](int) {
        if (!m_mediaBox->currentData().isValid())
            return;
        m_tasks.config().setMediaId(m_mediaBox->currentData().toString());
        // 换介质时脚本回到该介质的默认脚本（自定义脚本不受影响）。
        if (m_customScriptPath.isEmpty())
            m_scriptChoice.clear();
        updateUi();
    });

    m_zipBtn = new QPushButton(QStringLiteral("选择镜像包…"));
    m_zipBtn->setObjectName(QStringLiteral("startButton"));
    m_zipBtn->setToolTip(QStringLiteral("选择 BSP 压缩包，填入启动文件与系统镜像"));
    connect(m_zipBtn, &QPushButton::clicked, this, &MainWindow::chooseZip);
    m_extractTimer = new QTimer(this);
    m_extractTimer->setInterval(1000);
    connect(m_extractTimer, &QTimer::timeout, this, [this] {
        if (m_extractor.isRunning())
            m_hint->setText(QStringLiteral("正在解包，已用 %1 秒…")
                                .arg(m_extractStart.secsTo(QDateTime::currentDateTime())));
    });
    m_extractTimer->start();
    // 自动轮询设备：板子上电 / 拨码变化后界面自动更新，不需要手动点『检测设备』。
    m_autoDetectTimer = new QTimer(this);
    m_autoDetectTimer->setInterval(3000);
    connect(m_autoDetectTimer, &QTimer::timeout, this, [this] {
        if (m_tasks.isFlashing() || m_tasks.isDetecting() || m_tasks.isUtilityRunning())
            return;
        m_tasks.detect(true);
    });
    m_autoDetectTimer->start();
    m_versionHint = new QLabel;
    m_versionHint->setWordWrap(true);
    m_versionHint->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
    auto zipRow = new QHBoxLayout;
    zipRow->addWidget(m_zipBtn);
    zipRow->addStretch(1);
    configForm->addRow(QStringLiteral("镜像包"), zipRow);
    configForm->addRow(QStringLiteral("启动文件"), bootWrap);
    configForm->addRow(QStringLiteral("系统镜像"), linuxWrap);
    configForm->addRow(QString(), m_versionHint);

    auto fatBox = new QGroupBox(QStringLiteral("FAT 写入"));
    fatBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    auto fatLayout = new QVBoxLayout(fatBox);
    fatLayout->setSpacing(8);

    m_fatStatus = new QLabel(QStringLiteral(
        "设备停在 Fastboot 时，向 FAT 分区根目录写入一个文件。"));
    m_fatStatus->setWordWrap(true);
    m_fatStatus->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
    fatLayout->addWidget(m_fatStatus);
    m_fatMedia = new QLabel;
    m_fatMedia->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
    fatLayout->addWidget(m_fatMedia);

    m_fatPartBox = new QComboBox;
    m_fatPartBox->setVisible(false);
    m_fatReadBtn = new QPushButton(QStringLiteral("读取分区"));
    m_fatReadBtn->setToolTip(QStringLiteral(
        "设备停在 Fastboot 时读取分区表（mmc part）。单个 FAT 分区可直接拖入；多个分区时先选择。"));
    m_fatWriteBtn = new QPushButton(QStringLiteral("选择文件写入…"));
    m_fatWriteBtn->setToolTip(QStringLiteral(
        "选择电脑上的文件，写入所选 FAT 分区的根目录（uuu -b fat_write）。\\n"
        "只支持根目录，不支持子目录。"));
    auto fatRow = new QHBoxLayout;
    fatRow->setSpacing(8);
    fatRow->addWidget(new QLabel(QStringLiteral("FAT 分区")));
    fatRow->addWidget(m_fatPartBox, 1);
    fatRow->addWidget(m_fatReadBtn);
    fatRow->addWidget(m_fatWriteBtn);
    fatLayout->addLayout(fatRow);

    m_fatDrop = new DropZone;
    m_fatDrop->setText(QStringLiteral("拖入文件，写入 FAT 分区根目录"));
    m_fatDrop->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    fatLayout->addWidget(m_fatDrop, 1);

    connect(m_fatDrop, &DropZone::fileDropped, this, &MainWindow::onFatFileChosen);
    connect(m_fatReadBtn, &QPushButton::clicked, this, &MainWindow::refreshFatPartitions);
    connect(m_fatWriteBtn, &QPushButton::clicked, this, &MainWindow::onFatWriteClicked);

    auto taskBox = new QGroupBox(QStringLiteral("烧录任务"));
    taskBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    auto taskLayout = new QVBoxLayout(taskBox);
    m_jobKind = new QLabel(QStringLiteral("整卡烧录"));
    m_jobKind->setStyleSheet(QStringLiteral("font-size:13px;font-weight:600;color:#101828;"));
    m_jobDetail = new QLabel;
    m_jobDetail->setWordWrap(true);
    m_jobDetail->setStyleSheet(QStringLiteral("color:#344054;"));
    m_jobScript = new QLabel;
    m_jobScript->setWordWrap(true);
    m_jobScript->setStyleSheet(QStringLiteral("color:#667085;"));
    taskLayout->addWidget(m_jobKind);
    taskLayout->addWidget(m_jobDetail);
    taskLayout->addWidget(m_jobScript);
    taskLayout->addSpacing(8);
    auto actions = new QHBoxLayout;
    m_startBtn = new QPushButton(QStringLiteral("开始整卡烧录"));
    m_startBtn->setObjectName(QStringLiteral("startButton"));
    m_startBtn->setMinimumHeight(48);
    m_startBtn->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    m_cancelBtn = new QPushButton(QStringLiteral("取消"));
    actions->addWidget(m_startBtn, 1);
    actions->addWidget(m_cancelBtn);
    taskLayout->addLayout(actions);

    auto steps = new QHBoxLayout;
    steps->setSpacing(6);
    m_stageTitles = {
        QStringLiteral("加载 Bootloader"),
        QStringLiteral("等待 Fastboot"),
        QStringLiteral("写入镜像"),
        QStringLiteral("完成")
    };
    for (const QString& title : m_stageTitles) {
        auto label = new QLabel(title);
        label->setAlignment(Qt::AlignCenter);
        m_steps.push_back(label);
        steps->addWidget(label, 1);
    }
    taskLayout->addLayout(steps);

    m_progress = new QProgressBar;
    m_progress->setRange(0, 100);
    m_progress->setValue(0);
    m_progress->setFormat(QStringLiteral("总进度 %p%"));
    taskLayout->addWidget(m_progress);

    m_result = new QLabel(QStringLiteral("—"));
    m_result->setWordWrap(true);
    m_result->setStyleSheet(QStringLiteral("font-weight:400;"));
    taskLayout->addWidget(m_result);

    m_bootCheck = new QCheckBox(QStringLiteral("已断电，从介质启动，串口能进入系统"));
    m_bootCheck->setVisible(false);
    taskLayout->addWidget(m_bootCheck);

    m_verifyBtn = new QPushButton(QStringLiteral("读回校验（CRC）"));
    m_resetBtn = new QPushButton(QStringLiteral("重启设备"));
    m_utilityResult = new QLabel;
    m_utilityResult->setWordWrap(true);
    m_utilityResult->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));

    m_sdInfo = new QLabel;
    m_sdInfo->setWordWrap(true);
    m_sdInfo->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
    m_sdInfo->setToolTip(QStringLiteral("来自本机的烧录记录（tasks.json），不是从 SD 卡读取。"));
    taskLayout->addWidget(m_sdInfo);
    taskLayout->addStretch(1);

    auto grid = new QGridLayout;
    grid->setHorizontalSpacing(10);
    grid->setVerticalSpacing(0);
    grid->addWidget(deviceBox, 0, 0);
    grid->addWidget(configBox, 1, 0);
    grid->addWidget(taskBox, 0, 1, 2, 1);
    grid->setRowStretch(0, 0);
    grid->setRowStretch(1, 1);
    grid->setColumnStretch(0, 3);
    grid->setColumnStretch(1, 2);
    flashLayout->addLayout(grid, 1);

    auto logBox = new QGroupBox(QStringLiteral("命令行输出"));
    logBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    auto logLayout = new QVBoxLayout(logBox);
    auto logActions = new QHBoxLayout;
    logActions->addStretch(1);
    auto clearBtn = new QPushButton(QStringLiteral("清空"));
    auto exportBtn = new QPushButton(QStringLiteral("导出"));
    logActions->addWidget(clearBtn);
    logActions->addWidget(exportBtn);
    logLayout->addLayout(logActions);
    m_log = new QPlainTextEdit;
    m_log->setReadOnly(true);
    m_log->setMinimumHeight(72);
    m_log->setMaximumBlockCount(5000);
    m_log->setStyleSheet(QStringLiteral("font-family:Menlo,Consolas,monospace;font-size:13px;"));
    logLayout->addWidget(m_log, 1);

    connect(clearBtn, &QPushButton::clicked, m_log, &QPlainTextEdit::clear);
    connect(exportBtn, &QPushButton::clicked, this, &MainWindow::exportLog);

    auto scriptTab = new QWidget;
    auto scriptLayout = new QHBoxLayout(scriptTab);
    scriptLayout->setContentsMargins(0, 8, 0, 0);
    scriptLayout->setSpacing(10);
    auto scriptBox = new QGroupBox(QStringLiteral("脚本"));
    scriptBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    auto scriptBoxLayout = new QVBoxLayout(scriptBox);
    auto advBanner = new QLabel(QStringLiteral(
        "脚本由芯片配置文件按目标介质确定：SD = sd_all，eMMC = emmc_all，NAND = nand。更改「目标介质」即切换脚本。"));
    advBanner->setWordWrap(true);
    advBanner->setStyleSheet(QStringLiteral(
        "background:#fffaeb;color:#b54708;border:1px solid #fedf89;border-radius:8px;padding:10px;font-weight:400;"));
    scriptBoxLayout->addWidget(advBanner);
    m_scriptBox = new QComboBox;
    m_scriptBox->setToolTip(QStringLiteral(
        "默认用配置文件里该介质的脚本。选「自定义脚本文件…」才会改用一个 .lst。"));
    m_scriptHint = new QLabel;
    m_scriptHint->setWordWrap(true);
    m_scriptHint->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
    scriptBoxLayout->addWidget(m_scriptBox);
    scriptBoxLayout->addWidget(m_scriptHint);
    connect(m_scriptBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onScriptChanged);
    auto scriptHelp = new QLabel(QStringLiteral(
        "优先级：自定义 .lst > 此处所选脚本 > 配置文件。\n"
        "烧录任务按该脚本执行。FAT 写入在右侧，不改变烧录脚本。"));
    scriptHelp->setWordWrap(true);
    scriptHelp->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
    scriptBoxLayout->addWidget(scriptHelp);
    auto utilityRow = new QHBoxLayout;
    utilityRow->addWidget(m_verifyBtn);
    utilityRow->addWidget(m_resetBtn);
    utilityRow->addStretch(1);
    scriptBoxLayout->addLayout(utilityRow);
    scriptBoxLayout->addWidget(m_utilityResult);
    scriptBoxLayout->addStretch(1);
    scriptLayout->addWidget(scriptBox, 1);
    scriptLayout->addWidget(fatBox, 1);

    m_flashTab = flashTab;
    m_tabs->addTab(flashTab, QStringLiteral("烧录"));

    m_guideTab = new QWidget;
    auto guideLayout = new QHBoxLayout(m_guideTab);
    guideLayout->setContentsMargins(0, 8, 0, 0);
    guideLayout->setSpacing(10);
    m_guideList = new QListWidget;
    m_guideList->setFixedWidth(220);
    m_guideList->addItems({
        QStringLiteral("整卡烧录"),
        QStringLiteral("启动镜像"),
        QStringLiteral("FAT 写入"),
        QStringLiteral("脚本"),
        QStringLiteral("启动介质"),
        QStringLiteral("并行烧录"),
        QStringLiteral("i.MX 8 / 9"),
        QStringLiteral("读回校验"),
        QStringLiteral("重启设备"),
        QStringLiteral("本机 API"),
    });
    m_guideCard = new QGroupBox;
    m_guideCard->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    auto guideCardLayout = new QVBoxLayout(m_guideCard);
    m_guideHow = new QTextEdit;
    m_guideHow->setObjectName(QStringLiteral("guideHow"));
    m_guideHow->setReadOnly(true);
    m_guideHow->setFrameShape(QFrame::NoFrame);
    QFont guideFont = font();
    guideFont.setPixelSize(13);
    guideFont.setWeight(QFont::Normal);
    m_guideHow->setFont(guideFont);
    m_guideHow->document()->setDefaultFont(guideFont);
    m_guideGo = new QPushButton;
    guideCardLayout->addWidget(m_guideHow, 1);
    guideCardLayout->addWidget(m_guideGo, 0, Qt::AlignLeft);
    guideLayout->addWidget(m_guideList);
    guideLayout->addWidget(m_guideCard, 1);
    connect(m_guideList, &QListWidget::currentRowChanged, this, &MainWindow::showGuide);
    connect(m_guideGo, &QPushButton::clicked, this, &MainWindow::openGuideTarget);
    m_guideList->setCurrentRow(0);
    m_tabs->addTab(m_guideTab, QStringLiteral("功能说明"));

    m_advTab = scriptTab;
    updateAdvancedTab();
    root->addWidget(m_tabs, 3);
    root->addWidget(logBox, 2);
}

void MainWindow::showGuide(int index)
{
    struct Item {
        const char* title;
        const char* how;
        int target;
        const char* go;
    };
    const Item items[] = {
        {"整卡烧录",
         "适用\n"
         "SD、eMMC、NVMe。写入启动文件与系统镜像，覆盖目标介质。\n\n"
         "前提\n"
         "设备处于串行下载（SDPS 或 SDP），且已选择镜像包。\n\n"
         "操作\n"
         "1. 拨码置于串行下载，USB 接下载口，上电。\n"
         "2. 在「烧录」选择板型与介质。介质与拨码一致。\n"
         "3. 「选择镜像包…」指定 BSP 压缩包。\n"
         "4. 执行「开始整卡烧录」。烧录中可「取消」。\n"
         "5. 设备每 3 秒自动检测，也可执行「检测」。\n"
         "6. 完成后断电，拨码切回目标介质并上电。串口进入系统后勾选确认。",
         0, "打开烧录"},
        {"启动镜像",
         "适用\n"
         "NXP Linux BSP 压缩包。按当前板型提取启动文件与系统镜像，并核对版本。\n\n"
         "操作\n"
         "1. 先选择板型。\n"
         "2. 「选择镜像包…」。\n"
         "3. 「启动文件」「系统镜像」显示文件名，下方显示版本。\n"
         "4. 版本不一致时禁止烧录，重新选择同一压缩包。\n\n"
         "替换单个文件使用对应行的「更换…」。",
         0, "打开烧录"},
        {"FAT 写入",
         "适用\n"
         "SD、eMMC 上已有的 FAT 分区，仅根目录。\n\n"
         "前提\n"
         "设备停在 Fastboot。整卡烧录结束且未断电时即处于该状态。\n\n"
         "操作\n"
         "1. 菜单勾选「显示高级页」。\n"
         "2. 在「FAT 写入」中，单分区直接拖入文件。\n"
         "3. 多分区时先选择分区，再拖入或「选择文件写入…」。",
         1, "打开高级"},
        {"脚本",
         "来源\n"
         "芯片配置文件 [script]。随「目标介质」切换。烧录任务显示本次脚本名。\n\n"
         "默认\n"
         "SD = sd_all，eMMC = emmc_all，NVMe = nvme_all\n"
         "NAND = nand，QSPI NOR = qspi，SPI NAND = spi_nand\n\n"
         "覆盖顺序\n"
         "自定义 .lst > 高级页所选脚本 > 配置文件。\n\n"
         "操作\n"
         "特殊流程在高级页修改下拉项，或选择「自定义脚本文件…」。",
         1, "打开高级"},
        {"启动介质",
         "可选\n"
         "SD 卡、eMMC、NAND、QSPI NOR、SPI NAND、NVMe。须与启动拨码一致。\n\n"
         "写入范围\n"
         "SD、eMMC、NVMe：整卡烧录，需要系统镜像。\n"
         "NAND、QSPI NOR、SPI NAND：仅写入启动文件。",
         0, "打开烧录"},
        {"并行烧录",
         "范围\n"
         "当前所有处于串行下载、且芯片已有配置的设备。\n\n"
         "行为\n"
         "一次提交，全部写入同一镜像。已有任务进行时拒绝新的一批。\n\n"
         "操作\n"
         "各板进入串行下载后，执行一次开始。烧录过程中保持 USB 连接与供电。",
         0, "打开烧录"},
        {"i.MX 8 / 9",
         "范围\n"
         "已提供配置文件的 i.MX 8 与 i.MX 9。\n\n"
         "行为\n"
         "按 uuu 识别的芯片加载配置，板型列表切换为该芯片。\n"
         "未匹配配置时，状态栏给出芯片名并禁止烧录。\n\n"
         "操作\n"
         "板型与封装、内存一致。",
         0, "打开烧录"},
        {"读回校验",
         "适用\n"
         "SD、eMMC。设备停在 Fastboot，且系统镜像为刚写入的 wic。\n\n"
         "行为\n"
         "从存储读回，与镜像逐段比对 CRC32。跳过前 8MB 启动区。\n"
         "NAND、QSPI NOR、SPI NAND、NVMe 无此操作。\n\n"
         "操作\n"
         "菜单勾选「显示高级页」，执行「读回校验（CRC）」。",
         1, "打开高级"},
        {"重启设备",
         "适用\n"
         "设备停在 Fastboot。整卡烧录结束且未断电时即处于该状态。\n\n"
         "行为\n"
         "向设备发送重启，由拨码决定下次启动介质。\n\n"
         "操作\n"
         "菜单勾选「显示高级页」，执行「重启设备」。",
         1, "打开高级"},
        {"本机 API",
         "监听\n"
         "127.0.0.1，仅本机。\n\n"
         "接口\n"
         "GET  /v1/health\n"
         "GET  /v1/devices\n"
         "GET  /v1/tasks\n"
         "GET  /v1/tasks/<id>\n"
         "POST /v1/detect\n"
         "POST /v1/flash     bootloader, image, media\n"
         "POST /v1/cancel",
         -1, ""},
    };
    const int count = int(sizeof(items) / sizeof(items[0]));
    if (index < 0 || index >= count || !m_guideCard)
        return;
    const Item& item = items[index];
    m_guideCard->setTitle(QString::fromUtf8(item.title));
    QString how = QString::fromUtf8(item.how);
    if (QString::fromUtf8(item.title) == QStringLiteral("本机 API")) {
        const bool on = m_api && m_api->port() != 0;
        how += on
            ? QStringLiteral("\n\n现在的地址：http://127.0.0.1:%1").arg(m_api->port())
            : QStringLiteral("\n\n这次启动没有打开接口。");
    }
    m_guideHow->setPlainText(how);
    m_guideTarget = item.target;
    m_guideGo->setVisible(item.target >= 0);
    if (item.target >= 0)
        m_guideGo->setText(QString::fromUtf8(item.go));
}

void MainWindow::openGuideTarget()
{
    if (m_guideTarget == 1) {
        if (m_advAction && !m_advAction->isChecked())
            m_advAction->setChecked(true);
        if (m_advTab)
            m_tabs->setCurrentWidget(m_advTab);
        return;
    }
    if (m_flashTab)
        m_tabs->setCurrentWidget(m_flashTab);
}

void MainWindow::loadSettings()
{
    AppConfig& config = m_tasks.config();
    m_bootEdit->setText(config.bootloaderPath());
    m_linuxEdit->setText(config.linuxImagePath());
}

void MainWindow::saveFiles()
{
    AppConfig& config = m_tasks.config();
    config.setBootloaderPath(m_bootEdit->text());
    config.setLinuxImagePath(m_linuxEdit->text());
    const QString bootDir = QFileInfo(m_bootEdit->text()).absolutePath();
    const QString linuxDir = QFileInfo(m_linuxEdit->text()).absolutePath();
    if (!m_bootEdit->text().isEmpty() && QFileInfo::exists(bootDir))
        config.setLastDir(bootDir);
    if (!m_linuxEdit->text().isEmpty() && QFileInfo::exists(linuxDir))
        config.setLastDir(linuxDir);
}

void MainWindow::detect()
{
    m_holdResult = false;
    m_tasks.detect();
}

void MainWindow::startFlash()
{
    FlashRequest request;
    request.bootloaderPath = m_bootEdit->text();
    request.linuxImagePath = m_linuxEdit->text();
    request.boardName = activeBoard().name;
    request.media = m_mediaBox ? m_mediaBox->currentData().toString()
                              : QStringLiteral("sd");
    request.scriptName = m_customScriptPath.isEmpty() ? m_scriptChoice : QString();
    request.scriptPath = m_customScriptPath;
    request.target = mediaDisplayName(request.media);
    m_log->clear();
    m_utilityResult->clear();
    m_holdResult = false;
    const QStringList ids = m_tasks.submit(request);
    if (ids.isEmpty())
        m_log->appendPlainText(m_tasks.submitError());
}

QString MainWindow::currentMedia() const
{
    return m_mediaBox ? m_mediaBox->currentData().toString() : QStringLiteral("sd");
}

// 「脚本」下拉：选中内置脚本名，或「自定义脚本文件…」选一个 .lst。
void MainWindow::onScriptChanged(int index)
{
    if (!m_scriptBox || index < 0)
        return;
    const QString data = m_scriptBox->currentData().toString();
    if (data != QLatin1String("__custom__")) {
        m_customScriptPath.clear();
        m_scriptChoice = data;
        m_scriptHint->clear();
        m_scriptHint->setToolTip(QString());
        updateUi();
        return;
    }
    const QString startDir = m_customScriptPath.isEmpty()
        ? m_tasks.config().lastDir()
        : QFileInfo(m_customScriptPath).absolutePath();
    const QString path = QFileDialog::getOpenFileName(
        this, QStringLiteral("选择自定义 uuu 脚本（.lst）"), startDir,
        QStringLiteral("uuu 脚本 (*.lst *.auto);;所有文件 (*)"));
    if (path.isEmpty()) {
        // 取消：回到介质默认脚本。
        m_customScriptPath.clear();
        m_scriptChoice.clear();
        updateBoards();
        return;
    }
    m_customScriptPath = path;
    m_scriptHint->setText(QStringLiteral("自定义：%1").arg(QFileInfo(path).fileName()));
    m_scriptHint->setToolTip(path);
    updateUi();
}

// fatwrite 的 u-boot 设备变量：SD → ${sd_dev}，eMMC → ${emmc_dev}（由 u-boot 展开）。
QString MainWindow::fatDeviceVar() const
{
    return currentMedia() == QLatin1String("emmc") ? QStringLiteral("${emmc_dev}")
                                                : QStringLiteral("${sd_dev}");
}

// 刷新 FAT 分区列表：主机侧解析所选 wic 镜像；板子在 Fastboot 时再用 mmc part 覆盖。
void MainWindow::refreshFatPartitions()
{
    const QString media = currentMedia();
    if (!mediaSupportsFat(media)) {
        m_fatStatus->setText(QStringLiteral(
            "当前介质不支持 FAT 分区文件写入（仅 SD / eMMC）。"));
        return;
    }
    m_partsKey = fatPartsKey();
    m_tasks.listFatPartitions(media);
}

// 分区列表的 key：设备 / 介质 / 镜像任一变化都重新读取。
QString MainWindow::fatPartsKey() const
{
    const QVector<DeviceInfo> devices = m_tasks.devices();
    const QString usb = devices.size() == 1 ? devices.first().usbPath : QString();
    return usb + QLatin1Char('|') + currentMedia() + QLatin1Char('|') + m_linuxEdit->text();
}

// 写 FAT 分区文件：走 uuu 内置脚本 fat_write，要求板子在 Fastboot。
void MainWindow::writeFat(const QString& path, const QString& partitionId)
{
    m_utilityResult->clear();
    m_tasks.writeFatFile(path, currentMedia(), partitionId, QFileInfo(path).fileName());
}

void MainWindow::onFatFileChosen(const QString& path)
{
    if (path.isEmpty() || m_tasks.isFlashing() || m_tasks.isUtilityRunning())
        return;
    const QString media = currentMedia();
    if (!mediaSupportsFat(media)) {
        m_fatStatus->setText(QStringLiteral(
            "当前介质不支持 FAT 分区文件写入（仅 SD / eMMC）。"));
        return;
    }
    const QVector<DeviceInfo> devices = m_tasks.devices();
    if (devices.size() != 1 || !isFastbootDevice(devices.first())) {
        m_fatStatus->setText(QStringLiteral(
            "写入 FAT 分区要求设备停在 Fastboot。整卡烧录结束且未断电时即处于该状态。"));
        return;
    }
    const QVector<FatPartition> fat = m_tasks.fatPartitions();
    if (fat.isEmpty()) {
        // 还没读到分区（或识别不出 FAT）：先读，读到后自动写入。
        m_pendingFatFile = path;
        m_fatStatus->setText(QStringLiteral("正在读取分区，读到后自动写入…"));
        refreshFatPartitions();
        return;
    }
    // 分区已读到：写入「FAT 分区」当前所选（默认第一个）。
    writeFat(path, m_fatPartBox->currentData().toString());
}

void MainWindow::onFatWriteClicked()
{
    const QString media = currentMedia();
    if (!mediaSupportsFat(media)) {
        m_fatStatus->setText(QStringLiteral(
            "当前介质不支持 FAT 分区文件写入（仅 SD / eMMC）。"));
        return;
    }
    QString startDir = m_tasks.config().lastDir();
    if (startDir.isEmpty())
        startDir = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);
    const QString path = QFileDialog::getOpenFileName(
        this, QStringLiteral("选择要写入 FAT 分区的文件"), startDir);
    if (path.isEmpty())
        return;
    onFatFileChosen(path);
}

void MainWindow::onPartitionsChanged()
{
    const QVector<FatPartition> all = m_tasks.partitions();
    const QVector<FatPartition> fat = m_tasks.fatPartitions();
    const QVector<FatPartition>& shown = fat.isEmpty() ? all : fat;

    {
        const QSignalBlocker blocker(m_fatPartBox);
        m_fatPartBox->clear();
        for (const FatPartition& part : shown)
            m_fatPartBox->addItem(part.display(), part.writeArg(fatDeviceVar()));
    }

    if (fat.size() == 1) {
        m_fatPartBox->setVisible(false);
        m_fatStatus->setText(QStringLiteral("检测到 1 个 FAT 分区：%1。拖入文件即写入。")
                                 .arg(fat.first().display()));
    } else if (fat.size() > 1) {
        m_fatPartBox->setVisible(true);
        m_fatStatus->setText(QStringLiteral(
            "检测到 %1 个 FAT 分区。先选择目标分区，再拖入或使用「选择文件写入…」。")
            .arg(fat.size()));
    } else if (!all.isEmpty()) {
        m_fatPartBox->setVisible(true);
        m_fatStatus->setText(QStringLiteral(
            "未能按类型识别 FAT 分区，已列出全部 %1 个分区，请选择目标。").arg(all.size()));
    } else {
        m_fatPartBox->setVisible(false);
        const QString error = m_tasks.partitionsError();
        m_fatStatus->setText(error.isEmpty()
            ? QStringLiteral("未读到分区。设备停在 Fastboot 时可执行「读取分区」。")
            : QStringLiteral("读取分区失败：%1").arg(error));
    }

    // 拖入的文件已就绪 → 写入当前所选分区。
    if (!m_pendingFatFile.isEmpty() && !shown.isEmpty()) {
        const QString path = m_pendingFatFile;
        m_pendingFatFile.clear();
        writeFat(path, m_fatPartBox->currentData().toString());
        return;
    }
    updateUi();
}

ChipConfig MainWindow::activeChipConfig()
{
    const QVector<DeviceInfo> devices = m_tasks.devices();
    for (const DeviceInfo& device : devices) {
        if (m_tasks.isFlashTarget(device))
            return m_tasks.config().chipConfig(device.chip);
    }
    if (devices.size() == 1)
        return m_tasks.config().chipConfig(devices.first().chip);
    return m_tasks.config().defaultChipConfig();
}

BoardProfile MainWindow::activeBoard()
{
    const ChipConfig chip = activeChipConfig();
    const QString id = m_boardBox->currentData().toString();
    for (const BoardProfile& board : chip.boards) {
        if (board.id == id)
            return board;
    }
    if (chip.boards.isEmpty())
        return BoardProfile();
    return chip.boards.first();
}

void MainWindow::chooseBootloader()
{
    pickLocalFile(true);
}

void MainWindow::chooseLinux()
{
    pickLocalFile(false);
}

void MainWindow::pickLocalFile(bool bootloader)
{
    const QString downloads = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);
    const QStringList zips = downloadedZips();
    if (!zips.isEmpty() && (m_bootEdit->text().isEmpty() || m_linuxEdit->text().isEmpty())) {
        QMessageBox box(this);
        box.setIcon(QMessageBox::Question);
        box.setWindowTitle(QStringLiteral("找到已下载的镜像包"));
        QString text = QStringLiteral("在『下载』文件夹发现官方镜像包：\n%1\n\n"
                                     "它包含当前板型（%2）需要的 Bootloader 和 Linux 镜像。")
                           .arg(QFileInfo(zips.first()).fileName(), activeBoard().name);
        if (zips.size() > 1)
            text += QStringLiteral("\n共找到 %1 个可用包，这里用最新的一个。").arg(zips.size());
        text += QStringLiteral("\n\n要直接自动提取吗？大文件需要几分钟。");
        box.setText(text);
        auto useZip = box.addButton(QStringLiteral("自动提取（推荐）"), QMessageBox::AcceptRole);
        auto manual = box.addButton(QStringLiteral("手动选择文件…"), QMessageBox::ActionRole);
        box.addButton(QStringLiteral("取消"), QMessageBox::RejectRole);
        box.exec();
        if (box.clickedButton() == useZip) {
            runZipExtract(zips.first());
            return;
        }
        if (box.clickedButton() != manual)
            return;
    }

    const QString current = bootloader ? m_bootEdit->text() : m_linuxEdit->text();
    const QString currentDir = QFileInfo(current).absolutePath();
    QString dir;
    if (!current.isEmpty() && QFileInfo::exists(currentDir))
        dir = currentDir;
    else if (!downloads.isEmpty() && QFileInfo::exists(downloads))
        dir = downloads;
    else
        dir = m_tasks.config().lastDir();

    QString preselect;
    if (!zips.isEmpty() && QDir::cleanPath(dir) == QDir::cleanPath(downloads))
        preselect = zips.first();

    const QString filter = bootloader
        ? QStringLiteral("Bootloader 或官方镜像包 (*.bin* *.zip);;Bootloader (*.bin*);;官方镜像包 (*.zip);;所有文件 (*)")
        : QStringLiteral("Linux 镜像或官方镜像包 (*.wic *.wic.zst *.zip);;Linux 镜像 (*.wic *.wic.zst);;官方镜像包 (*.zip);;所有文件 (*)");
    const QString title = bootloader ? QStringLiteral("使用本地文件 - 选择 Bootloader")
                                   : QStringLiteral("使用本地文件 - 选择 Linux 镜像");
    const QString path = pickImageFileDialog(title, dir, filter, preselect);
    if (!path.isEmpty())
        applyLocalFile(path);
}

void MainWindow::applyLocalFile(const QString& path)
{
    if (path.endsWith(QLatin1String(".zip"), Qt::CaseInsensitive)) {
        runZipExtract(path);
        return;
    }

    if (path.endsWith(QLatin1String(".wic.zst"), Qt::CaseInsensitive)) {
        QMessageBox::warning(this, QStringLiteral("暂不支持压缩镜像"),
            QStringLiteral("选的是压缩镜像（.wic.zst），uuu 不能直接烧录。\n"
                           "请先解压成 .wic 文件后再选择。"));
        return;
    }

    if (path.endsWith(QLatin1String(".wic"), Qt::CaseInsensitive)) {
        m_linuxEdit->setText(path);
        m_log->appendPlainText(QStringLiteral("已填入 Linux 镜像：%1").arg(path));
        updateUi();
        return;
    }

    const QString bootName = activeBoard().bootloader;
    const QString fileName = QFileInfo(path).fileName();
    if (!bootName.isEmpty() && fileName.startsWith(QLatin1String("imx-boot"), Qt::CaseInsensitive)
        && fileName.compare(bootName, Qt::CaseInsensitive) != 0) {
        QMessageBox box(this);
        box.setIcon(QMessageBox::Warning);
        box.setWindowTitle(QStringLiteral("Bootloader 可能不匹配"));
        box.setText(QStringLiteral("选择的文件：%1\n当前板型需要：%2\n\n"
                                   "文件名不一致，烧录后可能无法启动。仍要使用吗？")
                        .arg(fileName, bootName));
        auto useAnyway = box.addButton(QStringLiteral("仍然使用"), QMessageBox::AcceptRole);
        box.addButton(QStringLiteral("重新选择"), QMessageBox::RejectRole);
        box.exec();
        if (box.clickedButton() != useAnyway)
            return;
    }

    m_bootEdit->setText(path);
    m_log->appendPlainText(QStringLiteral("已填入 Bootloader：%1").arg(path));
    updateUi();
}

QString MainWindow::findFileByName(const QString& name)
{
    if (name.isEmpty())
        return QString();

    QStringList roots;
    roots << m_tasks.config().lastDir()
          << QStandardPaths::writableLocation(QStandardPaths::DownloadLocation)
          << QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);

    for (const QString& root : roots) {
        if (root.isEmpty() || !QFileInfo::exists(root))
            continue;
        QStringList pending;
        pending << root;
        for (int depth = 0; depth < 4 && !pending.isEmpty(); ++depth) {
            QStringList next;
            for (const QString& dir : pending) {
                const QString direct = QDir(dir).filePath(name);
                if (QFileInfo::exists(direct))
                    return direct;
                const QFileInfoList subdirs =
                    QDir(dir).entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);
                for (const QFileInfo& subdir : subdirs)
                    next << subdir.absoluteFilePath();
            }
            pending = next;
        }
    }
    return QString();
}

void MainWindow::exportConfig()
{
    const BoardProfile board = activeBoard();
    const QString boot = m_bootEdit->text().trimmed();
    const QString linux = m_linuxEdit->text().trimmed();

    QStringList missing;
    if (boot.isEmpty())
        missing << QStringLiteral("Bootloader：还没选");
    else if (!QFileInfo::exists(boot))
        missing << QStringLiteral("Bootloader：%1").arg(QDir::toNativeSeparators(boot));
    if (linux.isEmpty())
        missing << QStringLiteral("Linux 镜像：还没选");
    else if (!QFileInfo::exists(linux))
        missing << QStringLiteral("Linux 镜像：%1").arg(QDir::toNativeSeparators(linux));
    if (!missing.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("导出配置"),
            QStringLiteral("先选好两个文件再导出，点「使用本地文件…」重新选择：\n%1")
                .arg(missing.join(QLatin1Char('\n'))));
        return;
    }

    FlashPreset::Data data;
    data.boardId = board.id;
    data.bootloaderPath = boot;
    data.linuxImagePath = linux;

    QString name = QStringLiteral("flash-config.json");
    if (!board.id.isEmpty())
        name = QStringLiteral("flash-config-%1.json").arg(board.id);
    QString dir = m_tasks.config().lastDir();
    if (dir.isEmpty() || !QFileInfo::exists(dir))
        dir = QDir::homePath();
    const QString path = QFileDialog::getSaveFileName(this, QStringLiteral("导出配置"),
                                                      QDir(dir).filePath(name),
                                                      QStringLiteral("配置文件 (*.json)"));
    if (path.isEmpty())
        return;

    const QByteArray bytes = FlashPreset::encode(data).toUtf8();
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly) || file.write(bytes) != bytes.size() || !file.commit()) {
        QMessageBox::warning(this, QStringLiteral("导出配置"),
            QStringLiteral("无法写入文件：\n%1").arg(QDir::toNativeSeparators(path)));
        return;
    }

    m_log->appendPlainText(QStringLiteral("已导出配置：%1").arg(path));
    QMessageBox::information(this, QStringLiteral("导出配置"),
        QStringLiteral("已导出配置：\n%1\n\n板型：%2\n把这个文件发给同事，"
                       "对方用「导入配置…」就能得到同样的选择。")
            .arg(QDir::toNativeSeparators(path),
                 board.name.isEmpty() ? QStringLiteral("（未选）") : board.name));
}

void MainWindow::importConfig()
{
    QString dir = m_tasks.config().lastDir();
    if (dir.isEmpty() || !QFileInfo::exists(dir))
        dir = QDir::homePath();
    const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("导入配置"), dir,
                                                      QStringLiteral("配置文件 (*.json)"));
    if (path.isEmpty())
        return;

    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::warning(this, QStringLiteral("导入配置"),
            QStringLiteral("无法读取文件：\n%1").arg(QDir::toNativeSeparators(path)));
        return;
    }
    const QString text = QString::fromUtf8(file.readAll());

    FlashPreset::Data data;
    QString error;
    if (!FlashPreset::decode(text, &data, &error)) {
        QMessageBox::warning(this, QStringLiteral("导入配置"), error);
        return;
    }

    applyPreset(data, path);
}

void MainWindow::applyPreset(const FlashPreset::Data& data, const QString& path)
{
    QStringList notes;

    if (data.boardId.isEmpty()) {
        notes << QStringLiteral("板型：配置里没有，保留现在的选择（%1）。")
                     .arg(m_boardBox->currentText());
    } else {
        const int index = m_boardBox->findData(data.boardId);
        if (index >= 0) {
            m_boardBox->setCurrentIndex(index);
            notes << QStringLiteral("板型：%1").arg(m_boardBox->itemText(index));
        } else {
            notes << QStringLiteral("板型：%1 不在当前列表，保留现在的选择（%2）。")
                         .arg(data.boardId, m_boardBox->currentText());
        }
    }

    const auto applyFile = [&](const QString& saved, QLineEdit* edit, const QString& what) {
        if (saved.isEmpty()) {
            notes << QStringLiteral("%1：配置里没有，保留现在的内容。").arg(what);
            return;
        }
        if (QFileInfo::exists(saved)) {
            edit->setText(saved);
            notes << QStringLiteral("%1：已填入 %2").arg(what, QFileInfo(saved).fileName());
            return;
        }
        const QString fileName = QFileInfo(saved).fileName();
        const QString found = findFileByName(fileName);
        if (!found.isEmpty()) {
            edit->setText(found);
            notes << QStringLiteral("%1：已在本机找到 %2").arg(what, fileName);
            return;
        }
        edit->setText(saved);
        notes << QStringLiteral("%1：未找到 %2，请点「使用本地文件…」选择。").arg(what, fileName);
    };
    applyFile(data.bootloaderPath, m_bootEdit, QStringLiteral("Bootloader"));
    applyFile(data.linuxImagePath, m_linuxEdit, QStringLiteral("Linux 镜像"));

    saveFiles();
    updateUi();

    m_log->appendPlainText(QStringLiteral("已导入配置：%1").arg(path));
    for (const QString& note : notes)
        m_log->appendPlainText(note);
    QMessageBox::information(this, QStringLiteral("导入配置"),
        QStringLiteral("已导入配置：%1\n\n%2")
            .arg(QFileInfo(path).fileName(), notes.join(QLatin1Char('\n'))));
}

QStringList MainWindow::downloadedZips()
{
    QStringList result;
    const QString downloads = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);
    const BoardProfile board = activeBoard();
    if (downloads.isEmpty() || board.id.isEmpty())
        return result;
    QDir dir(downloads);
    if (!dir.exists())
        return result;
    const QStringList names = dir.entryList({QStringLiteral("LF_v*.zip")}, QDir::Files, QDir::Time);
    for (const QString& name : names) {
        const QString path = dir.filePath(name);
        QVector<BspZipEntry> entries;
        QString error;
        if (!BspPackage::readEntries(path, &entries, &error))
            continue;
        const QStringList candidates = BspPackage::bootloaderCandidates(entries);
        if (candidates.isEmpty())
            continue;
        // 有可识别的 Bootloader 和整盘镜像才算可用的镜像包。
        if (BspPackage::imageCandidates(entries).isEmpty())
            continue;
        result << path;
    }
    return result;
}

QString MainWindow::pickImageFileDialog(const QString& title, const QString& dir,
                                       const QString& filter, const QString& preselect)
{
    QFileDialog dialog(this, title, dir, filter);
    dialog.setFileMode(QFileDialog::ExistingFile);
    if (!preselect.isEmpty())
        dialog.selectFile(preselect);
    if (dialog.exec() != QDialog::Accepted)
        return QString();
    const QStringList files = dialog.selectedFiles();
    return files.isEmpty() ? QString() : files.first();
}

void MainWindow::chooseUuu()
{
#if defined(Q_OS_WIN)
    const QString filter = QStringLiteral("uuu (uuu.exe)");
#else
    const QString filter = QStringLiteral("uuu (*)");
#endif
    const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("选择 uuu"),
                                                      m_tasks.config().lastDir(), filter);
    if (path.isEmpty())
        return;
    m_tasks.setExecutable(path);
    m_holdResult = false;
    m_tasks.detect();
}

void MainWindow::downloadUuu()
{
    if (m_downloadReply) {
        QMessageBox::information(this, QStringLiteral("下载 UUU"), QStringLiteral("UUU 正在下载。"));
        return;
    }

    const QString defaultPath = QDir::homePath() + QStringLiteral("/uuu.exe");
    const QString path = QFileDialog::getSaveFileName(this, QStringLiteral("保存 UUU"),
                                                      defaultPath,
                                                      QStringLiteral("uuu (uuu.exe)"));
    if (path.isEmpty())
        return;

    m_downloadPath = path;
    m_banner->setText(QStringLiteral("正在获取 UUU 最新版本..."));
    m_hint->setText(QStringLiteral("正在连接 NXP 官方发布页"));
    QNetworkRequest request(QUrl(QStringLiteral(
        "https://api.github.com/repos/nxp-imx/mfgtools/releases/latest")));
    request.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("nxp-uuu-flash-console"));
    QNetworkReply* reply = m_network.get(request);
    m_downloadReply = reply;
    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        m_downloadReply = nullptr;
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            m_downloadPath.clear();
            m_banner->setText(QStringLiteral("获取 UUU 失败"));
            m_hint->setText(reply->errorString());
            return;
        }

        const QJsonDocument document = QJsonDocument::fromJson(reply->readAll());
        if (!document.isObject()) {
            m_downloadPath.clear();
            m_banner->setText(QStringLiteral("获取 UUU 失败"));
            m_hint->setText(QStringLiteral("官方发布页返回了无效响应"));
            return;
        }
        const QJsonArray assets = document.object().value(QStringLiteral("assets")).toArray();
        const QString assetName =
#if defined(Q_OS_WIN)
            QStringLiteral("uuu.exe");
#else
            QStringLiteral("uuu");
#endif
        QJsonObject asset;
        for (const QJsonValue& value : assets) {
            const QJsonObject candidate = value.toObject();
            if (candidate.value(QStringLiteral("name")).toString() == assetName) {
                asset = candidate;
                break;
            }
        }

        const QString url = asset.value(QStringLiteral("browser_download_url")).toString();
        const QString digest = asset.value(QStringLiteral("digest")).toString();
        if (url.isEmpty() || !digest.startsWith(QStringLiteral("sha256:"))) {
            m_downloadPath.clear();
            m_banner->setText(QStringLiteral("下载 UUU 失败"));
            m_hint->setText(QStringLiteral("官方发布未提供可校验的 SHA-256"));
            return;
        }

        m_banner->setText(QStringLiteral("正在下载 UUU..."));
        m_hint->setText(QStringLiteral("来源：NXP 官方发布页"));
        m_downloadReply = m_network.get(QNetworkRequest(QUrl(url)));
        connect(m_downloadReply, &QNetworkReply::downloadProgress, this,
                [this](qint64 received, qint64 total) {
            if (total > 0)
                m_banner->setText(QStringLiteral("正在下载 UUU：%1%").arg(received * 100 / total));
        });
        connect(m_downloadReply, &QNetworkReply::finished, this, [this, digest] {
            QNetworkReply* download = m_downloadReply;
            m_downloadReply = nullptr;
            download->deleteLater();
            const QByteArray data = download->readAll();
            const QByteArray actual = QCryptographicHash::hash(data, QCryptographicHash::Sha256).toHex();
            const QByteArray expected = digest.mid(qstrlen("sha256:")).toLatin1().toLower();
            if (download->error() != QNetworkReply::NoError) {
                m_banner->setText(QStringLiteral("下载 UUU 失败"));
                m_hint->setText(download->errorString());
                m_downloadPath.clear();
                return;
            }
            if (actual != expected) {
                m_banner->setText(QStringLiteral("下载 UUU 失败"));
                m_hint->setText(QStringLiteral("SHA-256 校验失败，文件未保存"));
                m_downloadPath.clear();
                return;
            }

            QSaveFile file(m_downloadPath);
            if (!file.open(QIODevice::WriteOnly) || file.write(data) != data.size() || !file.commit()) {
                m_banner->setText(QStringLiteral("保存 UUU 失败"));
                m_hint->setText(QStringLiteral("无法写入选择的文件"));
                m_downloadPath.clear();
                return;
            }
#if defined(Q_OS_UNIX)
            QFile::setPermissions(m_downloadPath, QFileDevice::ReadOwner | QFileDevice::WriteOwner
                | QFileDevice::ExeOwner);
#endif
            m_tasks.setExecutable(m_downloadPath);
            m_downloadPath.clear();
            m_banner->setText(QStringLiteral("UUU 下载完成，正在检测设备..."));
            m_tasks.detect();
        });
    });
}

void MainWindow::exportLog()
{
    const QString suggested = m_task.id.isEmpty()
        ? QStringLiteral("uuu-log.txt")
        : m_task.id + QStringLiteral(".txt");
    const QString path = QFileDialog::getSaveFileName(this, QStringLiteral("导出日志"), suggested,
                                                      QStringLiteral("Text (*.txt)"));
    if (path.isEmpty())
        return;

    QString content;
    if (!m_task.logPath.isEmpty() && QFileInfo::exists(m_task.logPath)) {
        QFile file(m_task.logPath);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text))
            content = QString::fromUtf8(file.readAll());
    } else {
        content = m_log->toPlainText();
    }
    QFile out(path);
    if (!out.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    out.write(content.toUtf8());
}

void MainWindow::openHistory()
{
    TaskHistoryDialog dialog(m_tasks.history(), this);
    dialog.exec();
}

void MainWindow::chooseDataDir()
{
    const QString current = m_tasks.storageDir();
    QMessageBox box(this);
    box.setIcon(QMessageBox::Information);
    box.setWindowTitle(QStringLiteral("数据保存位置"));
    box.setText(QStringLiteral(
        "烧录记录（tasks.json）和日志（logs 文件夹）保存在：\n%1\n\n"
        "当前共 %2 条记录。这是电脑上的文件，和板子的存储介质无关。")
        .arg(QDir::toNativeSeparators(current))
        .arg(m_tasks.history().size()));
    auto change = box.addButton(QStringLiteral("更改…"), QMessageBox::AcceptRole);
    auto open = box.addButton(QStringLiteral("打开文件夹"), QMessageBox::ActionRole);
    auto reset = box.addButton(QStringLiteral("恢复默认"), QMessageBox::ActionRole);
    box.addButton(QStringLiteral("关闭"), QMessageBox::RejectRole);
    box.exec();

    if (box.clickedButton() == open) {
        QDesktopServices::openUrl(QUrl::fromLocalFile(current));
        return;
    }
    if (box.clickedButton() == reset) {
        if (m_tasks.config().dataDir().isEmpty()) {
            QMessageBox::information(this, QStringLiteral("数据保存位置"),
                QStringLiteral("已经是默认位置：\n%1").arg(QDir::toNativeSeparators(current)));
            return;
        }
        m_tasks.config().setDataDir(QString());
        m_tasks.reloadHistory();
        updateUi();
        QMessageBox::information(this, QStringLiteral("数据保存位置"),
            QStringLiteral("已恢复默认位置：\n%1").arg(QDir::toNativeSeparators(m_tasks.storageDir())));
        return;
    }
    if (box.clickedButton() != change)
        return;
    if (m_tasks.isFlashing() || m_extractor.isRunning()) {
        QMessageBox::information(this, QStringLiteral("数据保存位置"),
            QStringLiteral("正在烧录或解包，等任务结束后再改。"));
        return;
    }

    const QString dir = QFileDialog::getExistingDirectory(
        this, QStringLiteral("选择数据保存文件夹"), current);
    if (dir.isEmpty() || QDir::cleanPath(dir) == QDir::cleanPath(current))
        return;
    if (!QFileInfo(dir).isWritable()) {
        QMessageBox::warning(this, QStringLiteral("数据保存位置"),
            QStringLiteral("这个文件夹不能写入，换一个试试：\n%1")
                .arg(QDir::toNativeSeparators(dir)));
        return;
    }

    QMessageBox ask(this);
    ask.setIcon(QMessageBox::Question);
    ask.setWindowTitle(QStringLiteral("数据保存位置"));
    ask.setText(QStringLiteral(
        "新位置：%1\n\n要把现有的记录和日志复制过去吗？原位置的文件不会删除。")
        .arg(QDir::toNativeSeparators(dir)));
    auto copyBtn = ask.addButton(QStringLiteral("复制过去（推荐）"), QMessageBox::AcceptRole);
    ask.addButton(QStringLiteral("不复制"), QMessageBox::ActionRole);
    auto cancelBtn = ask.addButton(QStringLiteral("取消"), QMessageBox::RejectRole);
    ask.exec();
    if (ask.clickedButton() == cancelBtn)
        return;

    if (ask.clickedButton() == copyBtn) {
        const QString oldLogs = m_tasks.logDirectory();
        const QString rel = QDir(current).relativeFilePath(oldLogs);
        const QString newLogs = rel.isEmpty() || rel.startsWith(QStringLiteral(".."))
            ? QDir(dir).filePath(QStringLiteral("logs"))
            : QDir(dir).filePath(rel);
        QDir().mkpath(newLogs);
        const QDir srcLogs(oldLogs);
        for (const QFileInfo& fi : srcLogs.entryInfoList(QDir::Files)) {
            const QString target = QDir(newLogs).filePath(fi.fileName());
            if (!QFileInfo::exists(target))
                QFile::copy(fi.absoluteFilePath(), target);
        }
        const QString oldTasks = QDir(current).filePath(QStringLiteral("tasks.json"));
        const QString newTasks = QDir(dir).filePath(QStringLiteral("tasks.json"));
        if (QFileInfo::exists(oldTasks) && !QFileInfo::exists(newTasks))
            QFile::copy(oldTasks, newTasks);
    }

    m_tasks.config().setDataDir(QDir::cleanPath(dir));
    m_tasks.reloadHistory();
    updateUi();
    QMessageBox::information(this, QStringLiteral("数据保存位置"),
        QStringLiteral("已切换。记录和日志现在保存在：\n%1")
            .arg(QDir::toNativeSeparators(m_tasks.storageDir())));
}

void MainWindow::goMaskrom()
{
    QMessageBox::information(this, QStringLiteral("进入串行下载"),
        QStringLiteral(
            "1. 断电：关掉电源开关，或拔掉供电线。\n"
            "2. 拨启动拨码到「串行下载」。\n"
            "   FRDM-IMX95-PRO：SW4 = x 0 0 1（1=ON，0=OFF）。\n"
            "   参考：串行下载 x001，SD 卡启动 x011，eMMC x010（拨码位置以板子手册为准）。\n"
            "3. USB 线插到下载口（不是调试串口，也不是 PD 供电口）。\n"
            "4. 上电或按复位（拨码要断电重上电才生效）。\n"
            "5. 回到主界面执行「检测」。\n\n"
            "检测不到时，打开设备管理器确认插的是哪个口：\n"
            "· 出现 CH9114 的四路 COM（USB-Enhanced-SERIAL-A/B/C/D）＝插了调试串口，换下载口。\n"
            "· 出现 Unknown USB Device（Descriptor Request Failed）＝换 USB 2.0 口、换数据线后重试。\n"
            "· 完全没有新设备＝口或线不对。"));
}

void MainWindow::openDownloadPage()
{
    const ChipConfig chip = activeChipConfig();
    const QString page = chip.downloadPage.isEmpty()
        ? QStringLiteral("https://www.nxp.com/design/design-center/software/embedded-software/i-mx-software/"
                         "embedded-linux-for-i-mx-applications-processors:IMXLINUX")
        : chip.downloadPage;
    QDesktopServices::openUrl(QUrl(page));
    m_log->appendPlainText(QStringLiteral("已打开 NXP 官网下载页。下载完成后回到这里点「使用本地文件…」，文件一般在『下载』文件夹。"));
}

void MainWindow::openGettingStarted()
{
    const ChipConfig chip = activeChipConfig();
    const QString page = chip.guidePage.isEmpty()
        ? QStringLiteral("https://www.nxp.com/design/design-center/development-boards-and-designs/FRDM-IMX95-PRO")
        : chip.guidePage;
    QDesktopServices::openUrl(QUrl(page));
    m_log->appendPlainText(QStringLiteral("已打开 NXP 官网下载页。下载完成后回到这里点「使用本地文件…」，文件一般在『下载』文件夹。"));
}

// 填充「脚本」下拉：内置脚本 + 「自定义脚本文件…」，保留当前选择。
void MainWindow::updateScriptBox()
{
    if (!m_scriptBox)
        return;
    const ChipConfig chip = activeChipConfig();
    const QString key = chip.name + QLatin1Char('|') + currentMedia()
        + QLatin1Char('|') + m_scriptChoice + QLatin1Char('|') + m_customScriptPath;
    if (key == m_scriptKey && m_scriptBox->count() > 0)
        return;
    m_scriptKey = key;

    const QSignalBlocker blocker(m_scriptBox);
    m_scriptBox->clear();
    for (const QString& name : chip.scriptNames())
        m_scriptBox->addItem(name, name);
    m_scriptBox->addItem(QStringLiteral("自定义脚本文件…"), QStringLiteral("__custom__"));

    QString want = m_customScriptPath.isEmpty() ? m_scriptChoice : QStringLiteral("__custom__");
    if (want.isEmpty())
        want = chip.scripts.value(currentMedia(), chip.script);
    int index = m_scriptBox->findData(want);
    if (index < 0)
        index = 0;
    m_scriptBox->setCurrentIndex(index);

    if (!m_customScriptPath.isEmpty()) {
        m_scriptHint->setText(QStringLiteral("自定义：%1").arg(QFileInfo(m_customScriptPath).fileName()));
        m_scriptHint->setToolTip(m_customScriptPath);
    } else {
        m_scriptHint->clear();
        m_scriptHint->setToolTip(QString());
    }
}

void MainWindow::updateBoards()
{
    const ChipConfig chip = activeChipConfig();
    updateScriptBox();
    if (m_boardChip == chip.name && m_boardBox->count() > 0)
        return;

    m_boardChip = chip.name;
    {
        const QSignalBlocker blocker(m_boardBox);
        m_boardBox->clear();
        for (const BoardProfile& board : chip.boards)
            m_boardBox->addItem(board.name, board.id);

        const QString saved = m_tasks.config().boardId();
        const QString want = saved.isEmpty() ? chip.defaultBoardId : saved;
        const int index = m_boardBox->findData(want);
        m_boardBox->setCurrentIndex(index >= 0 ? index : 0);
        m_tasks.config().setBoardId(m_boardBox->currentData().toString());
    }

    if (m_mediaBox) {
        const QSignalBlocker blocker(m_mediaBox);
        m_mediaBox->clear();
        for (const QString& media : chip.media)
            m_mediaBox->addItem(mediaDisplayName(media), media);
        int mediaIndex = m_mediaBox->findData(m_tasks.config().mediaId());
        if (mediaIndex < 0)
            mediaIndex = m_mediaBox->findData(chip.mediaDefault);
        m_mediaBox->setCurrentIndex(mediaIndex >= 0 ? mediaIndex : 0);
        m_tasks.config().setMediaId(m_mediaBox->currentData().toString());
    }

    if (m_stageTitles.size() == 4) {
        m_stageTitles[2] = QStringLiteral("写入 %1")
            .arg(mediaDisplayName(m_tasks.config().mediaId()));
        for (int i = 0; i < m_steps.size() && i < m_stageTitles.size(); ++i)
            m_steps[i]->setText(m_stageTitles[i]);
    }
}

void MainWindow::chooseZip()
{
    if (m_extractor.isRunning()) {
        QMessageBox::information(this, QStringLiteral("从官方 zip 提取"),
                                  QStringLiteral("正在解包，请稍候。"));
        return;
    }

    const BoardProfile board = activeBoard();
    if (board.id.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("从官方 zip 提取"),
                             QStringLiteral("配置里没有板型列表，无法自动挑选文件。"));
        return;
    }

    const QString downloads = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);
    QString dir = m_tasks.config().lastDir();
    if (!downloads.isEmpty() && QFileInfo::exists(downloads))
        dir = downloads;
    const QStringList zips = downloadedZips();
    const QString zipPath = pickImageFileDialog(QStringLiteral("选择官方镜像包"), dir,
                                               QStringLiteral("官方镜像包 (*.zip)"),
                                               zips.isEmpty() ? QString() : zips.first());
    if (!zipPath.isEmpty())
        runZipExtract(zipPath);
}

void MainWindow::runZipExtract(const QString& zipPath)
{
    if (m_extractor.isRunning()) {
        QMessageBox::information(this, QStringLiteral("从官方 zip 提取"),
                                  QStringLiteral("正在解包，请稍候。"));
        return;
    }

    const BoardProfile board = activeBoard();
    if (board.id.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("从官方 zip 提取"),
                             QStringLiteral("配置里没有板型列表，无法自动挑选文件。"));
        return;
    }

    QVector<BspZipEntry> entries;
    QString error;
    if (!BspPackage::readEntries(zipPath, &entries, &error)) {
        QMessageBox::warning(this, QStringLiteral("从官方 zip 提取"), error);
        return;
    }

    QString bootName;
    QString wicName;
    const QStringList bootCandidates = BspPackage::bootloaderCandidates(entries);
    if (bootCandidates.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("从官方 zip 提取"),
            QStringLiteral("镜像包里没有可识别的 Bootloader（imx-boot* / *flash*.bin）。\n当前板型：%1").arg(board.name));
        return;
    }
    const QStringList imageOptions = BspPackage::imageCandidates(entries);
    if (imageOptions.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("从官方 zip 提取"),
            QStringLiteral("镜像包里没有可识别的整盘镜像（*.wic / *.wic.zst / *.img）。\n当前板型：%1").arg(board.name));
        return;
    }

    // Bootloader：优先板型配置的名字，否则包里只有一个就用它，多个则列出来让操作员选/搜索。
    bootName = board.bootloader;
    if (!bootCandidates.contains(bootName, Qt::CaseInsensitive))
        bootName.clear();
    if (bootName.isEmpty() && bootCandidates.size() == 1)
        bootName = bootCandidates.first();
    if (bootName.isEmpty() || bootCandidates.size() > 1) {
        const int preselect = bootCandidates.indexOf(bootName);
        bool ok = false;
        const QString picked = QInputDialog::getItem(this,
            QStringLiteral("选择 Bootloader"),
            QStringLiteral("镜像包里的 Bootloader 变体（当前板型：%1）。请选择或输入后确认：").arg(board.name),
            bootCandidates, preselect >= 0 ? preselect : 0, true, &ok);
        if (!ok || picked.trimmed().isEmpty())
            return;
        bootName = picked.trimmed();
    }

    // 镜像：包里只有一个就直接用，多个则列出来让操作员选/搜索。
    wicName = imageOptions.size() == 1 ? imageOptions.first() : QString();
    if (wicName.isEmpty()) {
        bool ok = false;
        const QString picked = QInputDialog::getItem(this,
            QStringLiteral("选择镜像"),
            QStringLiteral("镜像包里的整盘镜像变体（当前板型：%1）。请选择后确认：").arg(board.name),
            imageOptions, 0, false, &ok);
        if (!ok || picked.trimmed().isEmpty())
            return;
        wicName = picked.trimmed();
    }

    QString matchedBoot;
    if (!BspPackage::selectImages(entries, bootName, wicName, &matchedBoot, &wicName, &error)) {
        QMessageBox::warning(this, QStringLiteral("从官方 zip 提取"),
                             error + QStringLiteral("\n当前板型：%1").arg(board.name));
        return;
    }
    bootName = matchedBoot;

    const QFileInfo zipInfo(zipPath);
    const QString destDir = QDir(zipInfo.absolutePath()).filePath(zipInfo.completeBaseName());
    const QString bootPath = QDir(destDir).filePath(bootName);
    const QString wicPath = QDir(destDir).filePath(wicName);

    if (QFileInfo::exists(bootPath) && QFileInfo::exists(wicPath)) {
        m_bootEdit->setText(bootPath);
        m_linuxEdit->setText(wicPath);
        m_log->appendPlainText(QStringLiteral("已有解包结果，直接使用：%1").arg(destDir));
        updateUi();
        return;
    }

    quint64 needed = 0;
    for (const BspZipEntry& entry : entries) {
        if (entry.name == bootName || entry.name == wicName)
            needed += entry.size;
    }
    const QStorageInfo storage(zipInfo.absolutePath());
    const double margin = 1073741824.0;
    if (storage.isValid() && needed > 0
        && static_cast<double>(storage.bytesAvailable()) < static_cast<double>(needed) + margin) {
        QMessageBox::warning(this, QStringLiteral("磁盘空间不足"),
            QStringLiteral("解包需要约 %1 GB，当前可用 %2 GB。\n请清理空间或换一个磁盘后再试。")
                .arg(static_cast<double>(needed) / margin, 0, 'f', 1)
                .arg(static_cast<double>(storage.bytesAvailable()) / margin, 0, 'f', 1));
        return;
    }

    const QString version = BspPackage::inferVersion(zipPath);
    QStringList members;
    members << bootName << wicName;
    if (!m_extractor.start(zipPath, members, destDir, &error)) {
        QMessageBox::warning(this, QStringLiteral("从官方 zip 提取"), error);
        return;
    }

    m_extractZip = zipPath;
    m_extractDir = destDir;
    m_extractMembers = members;
    m_extractStart = QDateTime::currentDateTime();
    m_log->appendPlainText(QStringLiteral("开始解包：%1").arg(zipPath));
    m_log->appendPlainText(QStringLiteral("板型：%1").arg(board.name));
    m_log->appendPlainText(QStringLiteral("Bootloader：%1").arg(bootName));
    m_log->appendPlainText(QStringLiteral("Linux 镜像：%1").arg(wicName));
    m_log->appendPlainText(QStringLiteral("解包目录：%1（版本 %2）")
                               .arg(destDir, version.isEmpty() ? QStringLiteral("未识别") : version));
    m_log->appendPlainText(QStringLiteral("大文件需要几分钟，请勿关闭程序。"));
    updateUi();
}

void MainWindow::onExtractFinished(bool ok, const QString& message)
{
    const QString zipPath = m_extractZip;
    const QString destDir = m_extractDir;
    const QStringList members = m_extractMembers;
    m_extractZip.clear();
    m_extractDir.clear();
    m_extractMembers.clear();

    if (!ok) {
        m_log->appendPlainText(QStringLiteral("解包失败：%1").arg(message));
        QMessageBox::warning(this, QStringLiteral("从官方 zip 提取"), message);
        updateUi();
        return;
    }

    QString bootPath;
    QString wicPath;
    for (const QString& member : members) {
        const QString path = QDir(destDir).filePath(member);
        if (member.contains(QStringLiteral(".wic")))
            wicPath = path;
        else
            bootPath = path;
    }
    if (!bootPath.isEmpty())
        m_bootEdit->setText(bootPath);
    if (!wicPath.isEmpty())
        m_linuxEdit->setText(wicPath);

    m_log->appendPlainText(QStringLiteral("解包完成：%1").arg(destDir));
    QMessageBox::information(this, QStringLiteral("从官方 zip 提取"),
        QStringLiteral("已解出并填入两个文件：\n%1\n%2\n\n来源包：%3")
            .arg(QFileInfo(bootPath).fileName(), QFileInfo(wicPath).fileName(),
                 QFileInfo(zipPath).fileName()));
    updateUi();
}

void MainWindow::about()
{
    const QString api = m_api && m_api->port() != 0
        ? QStringLiteral("http://127.0.0.1:%1/v1/health").arg(m_api->port())
        : QStringLiteral("未启动");
    QMessageBox::about(this, QStringLiteral("关于"),
                       QStringLiteral("NXP UUU Flash Console\n"
                                      "烧录 i.MX 8 / i.MX 9。介质：SD、eMMC、NAND、QSPI NOR、SPI NAND、NVMe。\n"
                                      "多块板同时烧录。\n"
                                      "本机 API：%1").arg(api));
}

void MainWindow::onTask(const TaskRecord& task)
{
    m_task = task;
    const bool busy = m_tasks.isFlashing();
    const QVector<TaskRecord> batch = m_tasks.lastBatch();
    if (busy) {
        m_holdResult = false;
        int sum = 0;
        TaskStage stage = TaskStage::Finish;
        for (const TaskRecord& item : m_tasks.running()) {
            sum += item.percent;
            if (static_cast<int>(item.stage) < static_cast<int>(stage))
                stage = item.stage;
        }
        const int count = m_tasks.running().size();
        const int percent = count == 0 ? task.percent : sum / count;
        TaskRecord view = task;
        view.state = TaskState::Running;
        view.stage = stage;
        view.percent = percent;
        view.message = QStringLiteral("烧录中（%1 台）").arg(count);
        updateStages(stage, TaskState::Running);
        updateResult(view);
        m_progress->setValue(percent);
    } else if (batch.size() > 1
               && (task.state == TaskState::Succeeded || task.state == TaskState::Failed
                   || task.state == TaskState::Cancelled)) {
        int ok = 0;
        int failed = 0;
        int cancelled = 0;
        for (const TaskRecord& item : batch) {
            if (item.state == TaskState::Succeeded)
                ++ok;
            else if (item.state == TaskState::Cancelled)
                ++cancelled;
            else if (item.state == TaskState::Failed)
                ++failed;
        }
        m_holdResult = true;
        m_task.state = failed ? TaskState::Failed
                              : (ok == 0 && cancelled > 0 ? TaskState::Cancelled : TaskState::Succeeded);
        m_task.message = QStringLiteral("成功 %1 台，失败 %2 台，取消 %3 台").arg(ok).arg(failed).arg(cancelled);
        updateStages(TaskStage::Finish, m_task.state);
        m_result->setText(m_task.message);
        m_bootCheck->setVisible(false);
        m_progress->setValue(100);
    } else {
        if (task.state == TaskState::Succeeded || task.state == TaskState::Failed
            || task.state == TaskState::Cancelled)
            m_holdResult = true;
        updateStages(task.stage, task.state);
        updateResult(task);
        m_progress->setValue(task.state == TaskState::Idle ? 0 : task.percent);
    }
    updateUi();
    if (m_tasks.isQuitting() && !m_tasks.isFlashing())
        close();
}

void MainWindow::onLog(const QString& taskId, const QString& text)
{
    Q_UNUSED(taskId);
    m_log->appendPlainText(text);
}

void MainWindow::onUtility(const QString& title, bool ok, const QString& message)
{
    if (ok) {
        m_utilityResult->setStyleSheet(QStringLiteral("color:#067647;font-weight:400;"));
        if (title == QStringLiteral("读回校验")) {
            m_utilityResult->setText(
                QStringLiteral("读回校验成功：卡上 8MB 之后的内容与文件一致（uuu 逐段比对 CRC32，退出码 0）。\n"
                               "前 8MB 是启动区：单独烧的 Bootloader，不在比对范围内。"));
        } else {
            m_utilityResult->setText(
                QStringLiteral("重启设备成功：uuu 输出 %1，板子会重新启动。")
                    .arg(message.isEmpty() ? QStringLiteral("Okay") : message));
        }
    } else {
        m_utilityResult->setStyleSheet(QStringLiteral("color:#b42318;font-weight:400;"));
        m_utilityResult->setText(QStringLiteral("%1失败：%2")
                                    .arg(title,
                                         message.isEmpty() ? QStringLiteral("uuu 退出码非 0") : message)
                                 + utilityFixHint(message));
    }
    updateUi();
}

QString MainWindow::utilityFixHint(const QString& message) const
{
    // 只在 uuu 报「等不到设备」时给修复意见；依据本机检测到的设备状态，不猜测。
    if (!message.contains(QStringLiteral("Wait for Known USB Device")))
        return QString();

    const QVector<DeviceInfo> devices = m_tasks.devices();
    if (devices.isEmpty()) {
        return QStringLiteral("\n修复意见：uuu 现在检测不到设备（检测列表为空）。"
                              "读回校验 / 重启设备要求板子停在 Fastboot 模式："
                              "先完成一次烧录，设备会停在 Fastboot；"
                              "如果板子已断电或已从介质启动，把启动拨码拨到 x 0 0 1（串行下载），"
                              "断电重新上电，再重新烧录。");
    }
    if (devices.size() > 1) {
        return QStringLiteral("\n修复意见：检测到多台设备（%1 台），只接一台再试。")
            .arg(devices.size());
    }

    const DeviceInfo& device = devices.first();
    if (device.protocol.compare(QStringLiteral("SDPS"), Qt::CaseInsensitive) == 0) {
        return QStringLiteral("\n修复意见：板子当前是串行下载模式（uuu 检测到：芯片 %1，协议 %2）。"
                              "读回校验 / 重启设备要求板子停在 Fastboot 模式："
                              "先完成一次烧录，设备会停在 Fastboot。")
            .arg(device.chip.isEmpty() ? QStringLiteral("未识别") : device.chip,
                 device.protocol.isEmpty() ? QStringLiteral("SDPS") : device.protocol);
    }

    return QString();
}

void MainWindow::updateStages(TaskStage stage, TaskState state)
{
    if (m_steps.size() != 4)
        return;
    const QStringList& titles = m_stageTitles;
    int current = -1;
    switch (stage) {
    case TaskStage::LoadBootloader: current = 0; break;
    case TaskStage::WaitFastboot: current = 1; break;
    case TaskStage::FlashImage: current = 2; break;
    case TaskStage::Finish: current = 3; break;
    case TaskStage::WaitDevice: current = -1; break;
    }
    for (int i = 0; i < 4; ++i) {
        QString mode = QStringLiteral("pending");
        if (state == TaskState::Succeeded) {
            mode = QStringLiteral("done");
        } else if (state == TaskState::Failed || state == TaskState::Cancelled) {
            const int failedAt = current < 0 ? 0 : current;
            if (i < failedAt)
                mode = QStringLiteral("done");
            else if (i == failedAt)
                mode = QStringLiteral("failed");
        } else if (state == TaskState::Running) {
            const int active = current < 0 ? 0 : current;
            if (i < active)
                mode = QStringLiteral("done");
            else if (i == active)
                mode = QStringLiteral("current");
        }
        paintStep(m_steps.at(i), titles.at(i), mode);
    }
}

void MainWindow::updateResult(const TaskRecord& task)
{
    if (task.state == TaskState::Succeeded) {
        m_result->setText(QStringLiteral("成功，退出码 %1，耗时 %2")
                              .arg(task.exitCode)
                              .arg(durationText(task.startedAt, task.endedAt)));
        m_bootCheck->setVisible(true);
        const QSignalBlocker blocker(m_bootCheck);
        m_bootCheck->setChecked(task.bootChecked);
    } else if (task.state == TaskState::Failed) {
        const QString code = flashErrorText(task.errorCode);
        m_result->setText(code.isEmpty()
            ? QStringLiteral("失败，退出码 %1，%2").arg(task.exitCode).arg(task.message)
            : QStringLiteral("失败，退出码 %1，%2（%3）").arg(task.exitCode).arg(task.message, code));
        m_bootCheck->setVisible(false);
    } else if (task.state == TaskState::Cancelled) {
        m_result->setText(QStringLiteral("已取消"));
        m_bootCheck->setVisible(false);
    } else if (task.state == TaskState::Running) {
        m_result->setText(task.message.isEmpty() ? QStringLiteral("烧录中") : task.message);
        m_bootCheck->setVisible(false);
    } else {
        m_result->setText(QStringLiteral("—"));
        m_bootCheck->setVisible(false);
    }
}

void MainWindow::updateSdInfo()
{
    const QVector<TaskRecord> history = m_tasks.history();
    const TaskRecord* last = nullptr;
    for (const TaskRecord& task : history) {
        if (task.state == TaskState::Succeeded || task.state == TaskState::Failed
            || task.state == TaskState::Cancelled) {
            last = &task;
            break;
        }
    }

    if (!last) {
        m_sdInfo->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
        m_sdInfo->setText(
            QStringLiteral("无烧录记录。"));
        return;
    }

    QString version = BspPackage::inferVersion(last->linuxImagePath);
    if (version.isEmpty())
        version = BspPackage::inferVersion(last->bootloaderPath);

    QStringList parts;
    if (!version.isEmpty())
        parts << QStringLiteral("LF %1").arg(version);
    if (!last->boardName.isEmpty())
        parts << last->boardName;
    const QDateTime when = last->endedAt.isValid() ? last->endedAt : last->startedAt;
    if (when.isValid())
        parts << when.toString(QStringLiteral("MM-dd HH:mm"));

    if (last->state == TaskState::Succeeded)
        parts << QStringLiteral("成功");
    else if (last->state == TaskState::Cancelled)
        parts << QStringLiteral("未完成（已取消），需要重新烧录");
    else
        parts << QStringLiteral("未完成，这张卡需要重新烧录");

    m_sdInfo->setStyleSheet(last->state == TaskState::Succeeded
        ? QStringLiteral("color:#067647;font-weight:400;")
        : QStringLiteral("color:#b42318;font-weight:400;"));
    m_sdInfo->setText(QStringLiteral("上次烧录：%1").arg(parts.join(QStringLiteral(" · "))));
}

void MainWindow::updateUi()
{
    const bool flashing = m_tasks.isFlashing();
    const bool detecting = m_tasks.isDetecting();
    const bool extracting = m_extractor.isRunning();
    const bool utilityRunning = m_tasks.isUtilityRunning();
    const QVector<DeviceInfo> devices = m_tasks.devices();
    const QString error = m_tasks.detectError();
    const FlashError errorCode = m_tasks.detectErrorCode();
    const bool toolMissing = errorCode == FlashError::ToolMissing;
    const bool configBad = !m_tasks.config().chipConfigValid();
    const QString media = currentMedia();

    updateBoards();
    updateSdInfo();

    // 板子停在 Fastboot 后自动读一次分区表（用于 FAT 分区文件写入）。
    const bool fbDevice = devices.size() == 1 && isFastbootDevice(devices.first());
    if (mediaSupportsFat(media) && !flashing && !detecting && !extracting && !utilityRunning) {
        const QString key = fatPartsKey();
        if (key != m_partsKey) {
            m_partsKey = key;
            m_tasks.listFatPartitions(media);
        }
    }

    m_detectBtn->setEnabled(!flashing && !detecting && !extracting);
    m_cancelBtn->setEnabled(flashing || extracting);
    m_bootEdit->setEnabled(!flashing && !extracting);
    m_linuxEdit->setEnabled(!flashing && !extracting);
    m_bootBrowse->setEnabled(!flashing && !extracting);
    m_linuxBrowse->setEnabled(!flashing && !extracting);
    m_boardBox->setEnabled(!flashing && !extracting);
    if (m_mediaBox)
        m_mediaBox->setEnabled(!flashing && !extracting);
    if (m_scriptBox)
        m_scriptBox->setEnabled(!flashing && !extracting);
    if (m_importBtn)
        m_importBtn->setEnabled(!flashing && !extracting);
    if (m_exportBtn)
        m_exportBtn->setEnabled(!flashing && !extracting);
    m_zipBtn->setEnabled(!flashing && !detecting && !extracting);
    m_zipBtn->setText(extracting ? QStringLiteral("正在解包…")
                                 : QStringLiteral("选择镜像包…"));

    const auto markMissing = [](QLabel* label, const QString& path) {
        if (!path.isEmpty() && !QFileInfo::exists(path))
            label->setText(QStringLiteral("文件不存在"));
        else
            label->clear();
    };
    const auto showFile = [](QLabel* name, const QString& path) {
        if (path.isEmpty()) {
            name->setText(QStringLiteral("未选择"));
            name->setToolTip(QString());
            return;
        }
        name->setText(QFileInfo(path).fileName());
        name->setToolTip(path);
    };
    showFile(m_bootName, m_bootEdit->text());
    showFile(m_linuxName, m_linuxEdit->text());
    markMissing(m_bootMissing, m_bootEdit->text());
    markMissing(m_linuxMissing, m_linuxEdit->text());

    const QString bootVersion = BspPackage::inferVersion(m_bootEdit->text());
    const QString linuxVersion = BspPackage::inferVersion(m_linuxEdit->text());
    m_versionMismatch = !bootVersion.isEmpty() && !linuxVersion.isEmpty()
        && bootVersion != linuxVersion;
    if (m_versionMismatch) {
        m_versionHint->setStyleSheet(QStringLiteral("color:#b42318;font-weight:400;"));
        m_versionHint->setText(
            QStringLiteral("版本不一致：启动文件 %1，系统镜像 %2。请重新选择镜像包。")
                .arg(bootVersion, linuxVersion));
    } else if (!bootVersion.isEmpty()) {
        m_versionHint->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
        m_versionHint->setText(QStringLiteral("版本：%1").arg(bootVersion));
    } else if (!linuxVersion.isEmpty()) {
        m_versionHint->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
        m_versionHint->setText(QStringLiteral("版本：%1").arg(linuxVersion));
    } else if (QFileInfo::exists(m_bootEdit->text())) {
        m_versionHint->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
        m_versionHint->setText(QStringLiteral("文件已就绪。"));
    } else {
        m_versionHint->setStyleSheet(QStringLiteral("color:#667085;font-weight:400;"));
        m_versionHint->setText(QStringLiteral("未选择镜像。使用「选择镜像包…」。"));
    }

    QVector<DeviceInfo> ready;
    QVector<DeviceInfo> skipped;
    for (const DeviceInfo& device : devices) {
        if (m_tasks.isFlashTarget(device))
            ready.push_back(device);
        else
            skipped.push_back(device);
    }

    QString chip = QStringLiteral("—");
    QString protocol = QStringLiteral("—");
    QString usb = QStringLiteral("—");
    QString hint;
    QString banner = QStringLiteral("未连接");
    QString bannerBg = QStringLiteral("#eef2f6");
    QString bannerFg = QStringLiteral("#344054");
    QString dot = QStringLiteral("#98a2b3");

    if (flashing && m_tasks.running().size() > 1) {
        chip = QStringLiteral("%1 台烧录中").arg(m_tasks.running().size());
    } else if (flashing) {
        chip = QStringLiteral("烧录中");
    } else if (ready.size() == 1) {
        chip = QStringLiteral("已连接");
    } else if (ready.size() > 1) {
        chip = QStringLiteral("%1 台已连接").arg(ready.size());
    } else if (!devices.isEmpty()) {
        chip = QStringLiteral("已连接，不可烧录");
    }

    if (utilityRunning) {
        banner = m_tasks.utilityTitle() + QStringLiteral("中");
        bannerBg = QStringLiteral("#fffaeb");
        bannerFg = QStringLiteral("#b54708");
        dot = QStringLiteral("#f79009");
    } else if (extracting) {
        banner = QStringLiteral("正在解包");
        hint = QStringLiteral("正在从官方镜像包解出文件，大文件需要几分钟，请勿关闭程序。");
        bannerBg = QStringLiteral("#fffaeb");
        bannerFg = QStringLiteral("#b54708");
        dot = QStringLiteral("#f79009");
    } else if (toolMissing) {
        banner = error;
        hint = error;
        bannerBg = QStringLiteral("#fef3f2");
        bannerFg = QStringLiteral("#b42318");
        dot = QStringLiteral("#f04438");
    } else if (flashing) {
        banner = QStringLiteral("烧录中（%1 台）").arg(qMax(1, m_tasks.running().size()));
        bannerBg = QStringLiteral("#fffaeb");
        bannerFg = QStringLiteral("#b54708");
        dot = QStringLiteral("#f79009");
    } else if (devices.isEmpty()) {
        if (!error.isEmpty()) {
            banner = error;
            hint = error;
        } else {
            hint = QStringLiteral("未检测到设备。串行下载步骤见菜单「进入串行下载」。");
        }
        bannerBg = QStringLiteral("#fef3f2");
        bannerFg = QStringLiteral("#b42318");
        dot = QStringLiteral("#f04438");
    } else if (ready.isEmpty()) {
        banner = flashErrorText(FlashError::WrongDevice);
        QStringList rows;
        for (const DeviceInfo& device : devices)
            rows << device.raw;
        rows << flashErrorText(FlashError::WrongDevice);
        const DeviceInfo& device = devices.first();
        if (isSerialDownload(device.protocol) && !m_tasks.config().hasChip(device.chip))
            rows << QStringLiteral("uuu 检测到芯片 %1，没有对应的配置文件。").arg(device.chip);
        else
            rows << QStringLiteral("uuu 检测到：协议 %1，芯片 %2；烧录要求：协议 SDPS 或 SDP，且芯片已有配置。")
                        .arg(device.protocol.isEmpty() ? QStringLiteral("（空）") : device.protocol,
                             device.chip.isEmpty() ? QStringLiteral("未识别") : device.chip);
        if (device.protocol.compare(QStringLiteral("FB"), Qt::CaseInsensitive) == 0)
            rows << QStringLiteral("修复意见：断电后保持拨码并重新上电，回到串行下载后执行「检测」。");
        hint = rows.join(QLatin1Char('\n'));
        bannerBg = QStringLiteral("#fef3f2");
        bannerFg = QStringLiteral("#b42318");
        dot = QStringLiteral("#f04438");
    } else {
        banner = ready.size() == 1
            ? QStringLiteral("已连接可烧录")
            : QStringLiteral("已连接 %1 台可烧录").arg(ready.size());
        QStringList rows;
        for (const DeviceInfo& device : ready)
            rows << QStringLiteral("%1  %2  %3").arg(device.usbPath, device.chip, device.protocol);
        if (!skipped.isEmpty()) {
            rows << QStringLiteral("以下设备本次不烧：");
            for (const DeviceInfo& device : skipped)
                rows << device.raw;
        }
        hint = ready.size() > 1 || !skipped.isEmpty() ? rows.join(QLatin1Char('\n')) : QString();
        bannerBg = QStringLiteral("#ecfdf3");
        bannerFg = QStringLiteral("#067647");
        dot = QStringLiteral("#12b76a");
    }

    if (!flashing && m_holdResult) {
        if (m_task.state == TaskState::Succeeded) {
            banner = QStringLiteral("烧录成功");
            bannerBg = QStringLiteral("#ecfdf3");
            bannerFg = QStringLiteral("#067647");
            dot = QStringLiteral("#12b76a");
        } else if (m_task.state == TaskState::Failed) {
            banner = QStringLiteral("烧录失败");
            bannerBg = QStringLiteral("#fef3f2");
            bannerFg = QStringLiteral("#b42318");
            dot = QStringLiteral("#f04438");
        } else if (m_task.state == TaskState::Cancelled) {
            banner = QStringLiteral("已取消");
            bannerBg = QStringLiteral("#eef2f6");
            bannerFg = QStringLiteral("#344054");
            dot = QStringLiteral("#98a2b3");
        }
    }

    if (configBad) {
        const QString configError = m_tasks.config().configError().isEmpty()
            ? flashErrorText(FlashError::ConfigMissing)
            : m_tasks.config().configError();
        hint = hint.isEmpty() ? configError : hint + QLatin1Char('\n') + configError;
    }

    m_chip->setText(chip);
    m_protocol->setText(protocol);
    m_usb->setText(usb);
    m_hint->setText(hint);
    const bool imageOk = !mediaNeedsImage(media) || QFileInfo::exists(m_linuxEdit->text());
    const bool filesOk = QFileInfo::exists(m_bootEdit->text()) && imageOk;
    const QString where = mediaDisplayName(media);
    m_bootCheck->setText(QStringLiteral("已断电，从%1启动，串口能进入系统").arg(where));
    const ChipConfig chipCfg = activeChipConfig();
    const QString scriptName = !m_customScriptPath.isEmpty()
        ? QFileInfo(m_customScriptPath).fileName()
        : (!m_scriptChoice.isEmpty() ? m_scriptChoice
                                     : chipCfg.scripts.value(media, chipCfg.script));
    QString kind = QStringLiteral("整卡烧录");
    QString detail = QStringLiteral("写入启动文件与系统镜像到%1，覆盖目标介质。").arg(where);
    QString button = QStringLiteral("开始整卡烧录");
    if (!m_customScriptPath.isEmpty()) {
        kind = QStringLiteral("自定义脚本");
        detail = QStringLiteral("执行 %1。").arg(scriptName);
        button = QStringLiteral("按脚本烧录");
    } else if (!mediaNeedsImage(media)) {
        kind = QStringLiteral("启动文件");
        detail = QStringLiteral("仅写入启动文件到%1。").arg(where);
        button = QStringLiteral("烧录启动文件");
    }
    m_jobKind->setText(kind);
    m_jobDetail->setText(detail);
    m_jobScript->setText(m_customScriptPath.isEmpty()
        ? QStringLiteral("脚本 %1，由目标介质确定。")
              .arg(scriptName.isEmpty() ? QStringLiteral("—") : scriptName)
        : QStringLiteral("自定义脚本 %1").arg(scriptName));
    m_startBtn->setText(button);
    QString step = banner;
    if (utilityRunning)
        step = m_tasks.utilityTitle() + QStringLiteral("进行中，请等待。");
    else if (extracting)
        step = QStringLiteral("正在解包。请勿关闭程序。");
    else if (toolMissing)
        step = QStringLiteral("未找到 uuu。请在菜单「UUU 路径」中指定。");
    else if (flashing)
        step = QStringLiteral("烧录中。请保持 USB 连接与供电。");
    else if (!flashing && m_holdResult && m_task.state == TaskState::Succeeded)
        step = QStringLiteral("烧录完成。断电后将拨码拨至「%1」并上电。串口进入系统后勾选确认。").arg(where);
    else if (!flashing && m_holdResult && m_task.state == TaskState::Failed)
        step = QStringLiteral("烧录失败。查看任务区说明。设备回到串行下载后执行「%1」。").arg(button);
    else if (!flashing && m_holdResult && m_task.state == TaskState::Cancelled)
        step = QStringLiteral("已取消。设备仍处于串行下载时可执行「%1」。").arg(button);
    else if (devices.isEmpty())
        step = QStringLiteral("步骤 1：拨码置于串行下载，USB 接下载口，上电。");
    else if (ready.isEmpty())
        step = devices.first().protocol.compare(QStringLiteral("FB"), Qt::CaseInsensitive) == 0
            ? QStringLiteral("设备停在 Fastboot。断电后保持串行下载拨码并重新上电。")
            : QStringLiteral("当前设备不可烧录。见下方说明。");
    else if (m_versionMismatch)
        step = QStringLiteral("启动文件与系统镜像版本不一致。请重新选择镜像包。");
    else if (!filesOk)
        step = QStringLiteral("步骤 2：选择镜像包。");
    else if (ready.size() > 1)
        step = QStringLiteral("步骤 3：%1 台设备将写入同一镜像。执行「%2」。").arg(ready.size()).arg(button);
    else
        step = QStringLiteral("步骤 3：执行「%1」。").arg(button);

    m_banner->setText(QStringLiteral("  ") + step);
    m_banner->setStyleSheet(QStringLiteral(
        "background:%1;color:%2;border-radius:6px;font-weight:600;font-size:13px;padding:8px;")
                                .arg(bannerBg, bannerFg));
    m_dot->setStyleSheet(QStringLiteral("background:%1;border-radius:5px;").arg(dot));

    const bool deviceOk = !ready.isEmpty();
    m_startBtn->setEnabled(!flashing && !detecting && !extracting && !utilityRunning && !toolMissing
                          && !configBad && deviceOk && filesOk && !m_versionMismatch);
    const bool startIsNext = m_startBtn->isEnabled();
    m_startBtn->setObjectName(startIsNext ? QStringLiteral("startButton") : QString());
    m_zipBtn->setObjectName(startIsNext ? QString() : QStringLiteral("startButton"));
    for (QWidget* button : {static_cast<QWidget*>(m_startBtn), static_cast<QWidget*>(m_zipBtn)}) {
        button->style()->unpolish(button);
        button->style()->polish(button);
    }
    m_verifyBtn->setEnabled(!flashing && !detecting && !extracting && !utilityRunning
                            && mediaSupportsCrcVerify(media)
                            && QFileInfo::exists(m_linuxEdit->text()));
    m_resetBtn->setEnabled(!flashing && !detecting && !extracting && !utilityRunning);

    if (m_fatReadBtn) {
        const bool fatOk = mediaSupportsFat(media);
        m_fatReadBtn->setEnabled(!flashing && !detecting && !extracting && !utilityRunning
                                  && fbDevice);
        m_fatWriteBtn->setEnabled(!flashing && !detecting && !extracting && !utilityRunning
                                   && fbDevice && fatOk);
        m_fatDrop->setActive(fbDevice && fatOk && !flashing && !extracting && !utilityRunning);
    }
    if (m_fatMedia)
        m_fatMedia->setText(QStringLiteral("目标介质：%1。整卡烧录在「烧录」页。")
                                .arg(mediaDisplayName(media)));
}

// 高级页给维修 / 工程用：默认显示，可在菜单「显示高级页」里隐藏，流水线工人不用管。
void MainWindow::updateAdvancedTab()
{
    if (!m_tabs || !m_advTab)
        return;
    const bool wanted = m_tasks.config().advancedTab();
    const int index = m_tabs->indexOf(m_advTab);
    if (wanted && index < 0)
        m_tabs->addTab(m_advTab, QStringLiteral("高级"));
    else if (!wanted && index >= 0)
        m_tabs->removeTab(index);
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    if (m_tasks.isFlashing()) {
        event->ignore();
        m_tasks.beginQuit();
        return;
    }
    event->accept();
}
