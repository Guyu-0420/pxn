#include "gui/DropZone.h"

#include <QDragEnterEvent>
#include <QDropEvent>
#include <QList>
#include <QMimeData>
#include <QUrl>

DropZone::DropZone(QWidget* parent)
    : QLabel(parent)
{
    setAlignment(Qt::AlignCenter);
    setMinimumHeight(52);
    setAcceptDrops(true);
    refreshStyle(false);
}

void DropZone::setActive(bool active)
{
    m_active = active;
    setAcceptDrops(active);
    refreshStyle(m_hovering);
}

void DropZone::refreshStyle(bool hovering)
{
    const bool highlight = m_active && hovering;
    QString border = QStringLiteral("#c5ced9");
    QString bg = QStringLiteral("#f9fafb");
    QString fg = QStringLiteral("#667085");
    if (!m_active) {
        bg = QStringLiteral("#f2f4f7");
        fg = QStringLiteral("#98a2b3");
    } else if (highlight) {
        border = QStringLiteral("#0f6b4c");
        bg = QStringLiteral("#e8f6f0");
        fg = QStringLiteral("#0f6b4c");
    }
    setStyleSheet(QStringLiteral(
        "border:1px dashed %1;border-radius:8px;background:%2;color:%3;padding:12px;font-weight:400;")
        .arg(border, bg, fg));
}

void DropZone::dragEnterEvent(QDragEnterEvent* event)
{
    if (!m_active || !event->mimeData()->hasUrls())
        return;
    event->acceptProposedAction();
    m_hovering = true;
    refreshStyle(true);
}

void DropZone::dragLeaveEvent(QDragLeaveEvent* event)
{
    Q_UNUSED(event);
    m_hovering = false;
    refreshStyle(false);
}

void DropZone::dropEvent(QDropEvent* event)
{
    m_hovering = false;
    refreshStyle(false);
    if (!m_active || !event->mimeData()->hasUrls())
        return;
    const QList<QUrl> urls = event->mimeData()->urls();
    if (urls.isEmpty())
        return;
    const QString path = urls.first().toLocalFile();
    if (!path.isEmpty())
        emit fileDropped(path);
}