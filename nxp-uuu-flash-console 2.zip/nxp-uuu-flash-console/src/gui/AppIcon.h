#pragma once

#include <QPixmap>

QPixmap appIconPixmap(int size);