#pragma once

#include "api/FlashApiServer.h"
#include "config/AppConfig.h"
#include "config/FlashPreset.h"
#include "gui/DropZone.h"
#include "task/BspExtractor.h"
#include "task/TaskManager.h"

#include <QCloseEvent>
#include <QAction>
#include <QComboBox>
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMainWindow>
#include <QTextEdit>
#include <QNetworkAccessManager>
#include <QPlainTextEdit>
#include <QProgressBar>
#include <QPushButton>
#include <QCheckBox>
#include <QTabWidget>
#include <QTimer>
#include <QVector>

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    void buildUi();
    void loadSettings();
    void saveFiles();
    void detect();
    void startFlash();
    void onFatFileChosen(const QString& path);
    void onFatWriteClicked();
    void refreshFatPartitions();
    void onPartitionsChanged();
    void writeFat(const QString& path, const QString& partitionId);
    void onScriptChanged(int index);
    void updateScriptBox();
    void updateAdvancedTab();
    QString currentMedia() const;
    QString fatDeviceVar() const;
    QString fatPartsKey() const;
    void chooseBootloader();
    void chooseLinux();
    void chooseUuu();
    void downloadUuu();
    void exportLog();
    void openHistory();
    void chooseDataDir();
    void goMaskrom();
    void openDownloadPage();
    void openGettingStarted();
    void showGuide(int index);
    void openGuideTarget();
    void chooseZip();
    void importConfig();
    void exportConfig();
    void applyPreset(const FlashPreset::Data& data, const QString& path);
    QString findFileByName(const QString& name);
    void pickLocalFile(bool bootloader);
    void applyLocalFile(const QString& path);
    void runZipExtract(const QString& zipPath);
    void updateBoards();
    void onExtractFinished(bool ok, const QString& message);
    void about();
    void onTask(const TaskRecord& task);
    void onLog(const QString& taskId, const QString& text);
    void onUtility(const QString& title, bool ok, const QString& message);
    QString utilityFixHint(const QString& message) const;
    void updateUi();
    void updateStages(TaskStage stage, TaskState state);
    void updateResult(const TaskRecord& task);
    void updateSdInfo();
    ChipConfig activeChipConfig();
    BoardProfile activeBoard();
    QStringList downloadedZips();
    QString pickImageFileDialog(const QString& title, const QString& dir, const QString& filter,
                                const QString& preselect);

    TaskManager m_tasks;
    FlashApiServer* m_api = nullptr;
    TaskRecord m_task;
    bool m_holdResult = false;

    QLabel* m_banner = nullptr;
    QLabel* m_dot = nullptr;
    QLabel* m_chip = nullptr;
    QLabel* m_protocol = nullptr;
    QLabel* m_usb = nullptr;
    QLabel* m_hint = nullptr;
    QPushButton* m_detectBtn = nullptr;

    QLineEdit* m_bootEdit = nullptr;
    QLineEdit* m_linuxEdit = nullptr;
    QLabel* m_bootName = nullptr;
    QLabel* m_linuxName = nullptr;
    QLabel* m_bootMissing = nullptr;
    QLabel* m_linuxMissing = nullptr;
    QPushButton* m_bootBrowse = nullptr;
    QPushButton* m_linuxBrowse = nullptr;
    QComboBox* m_boardBox = nullptr;
    QComboBox* m_mediaBox = nullptr;
    QComboBox* m_scriptBox = nullptr;
    QLabel* m_scriptHint = nullptr;
    QString m_scriptChoice;      // 选中的内置脚本名；空 = 跟随介质默认
    QString m_customScriptPath;   // 自定义 .lst 脚本路径；非空时优先
    QString m_scriptKey;
    QComboBox* m_fatPartBox = nullptr;
    QLabel* m_fatStatus = nullptr;
    QLabel* m_fatMedia = nullptr;
    QPushButton* m_fatReadBtn = nullptr;
    QPushButton* m_fatWriteBtn = nullptr;
    DropZone* m_fatDrop = nullptr;
    QString m_pendingFatFile;
    QString m_partsKey;
    QPushButton* m_importBtn = nullptr;
    QPushButton* m_exportBtn = nullptr;
    QPushButton* m_zipBtn = nullptr;
    QLabel* m_versionHint = nullptr;

    QLabel* m_jobKind = nullptr;
    QLabel* m_jobDetail = nullptr;
    QLabel* m_jobScript = nullptr;
    QPushButton* m_startBtn = nullptr;
    QPushButton* m_cancelBtn = nullptr;
    QVector<QLabel*> m_steps;
    QStringList m_stageTitles;
    QProgressBar* m_progress = nullptr;
    QLabel* m_result = nullptr;
    QLabel* m_sdInfo = nullptr;
    QCheckBox* m_bootCheck = nullptr;
    QPushButton* m_verifyBtn = nullptr;
    QPushButton* m_resetBtn = nullptr;
    QLabel* m_utilityResult = nullptr;

    QPlainTextEdit* m_log = nullptr;
    QTabWidget* m_tabs = nullptr;
    QWidget* m_flashTab = nullptr;
    QWidget* m_guideTab = nullptr;
    QListWidget* m_guideList = nullptr;
    QGroupBox* m_guideCard = nullptr;
    QTextEdit* m_guideHow = nullptr;
    QPushButton* m_guideGo = nullptr;
    int m_guideTarget = 0;
    QWidget* m_advTab = nullptr;
    QAction* m_advAction = nullptr;
    QNetworkAccessManager m_network;
    QNetworkReply* m_downloadReply = nullptr;
    QString m_downloadPath;

    BspExtractor m_extractor;
    QString m_extractDir;
    QStringList m_extractMembers;
    QString m_boardChip;
    QString m_extractZip;
    QTimer* m_extractTimer = nullptr;
    QTimer* m_autoDetectTimer = nullptr;
    QDateTime m_extractStart;
    bool m_versionMismatch = false;
};
