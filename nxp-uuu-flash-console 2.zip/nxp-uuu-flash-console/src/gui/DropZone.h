#pragma once

#include <QLabel>

// 接受文件拖放的标签：拖入本地文件时发出 fileDropped(路径)。
class DropZone : public QLabel {
    Q_OBJECT
public:
    explicit DropZone(QWidget* parent = nullptr);

    // 可用时高亮边框并接受拖放；不可用时置灰、拒绝拖放。
    void setActive(bool active);
    bool isActive() const { return m_active; }

signals:
    void fileDropped(QString path);

protected:
    void dragEnterEvent(QDragEnterEvent* event) override;
    void dragLeaveEvent(QDragLeaveEvent* event) override;
    void dropEvent(QDropEvent* event) override;

private:
    void refreshStyle(bool hovering);
    bool m_active = false;
    bool m_hovering = false;
};