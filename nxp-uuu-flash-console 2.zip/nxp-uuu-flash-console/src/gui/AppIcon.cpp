#include "gui/AppIcon.h"

#include <QLinearGradient>
#include <QPainter>
#include <QPainterPath>

QPixmap appIconPixmap(int size)
{
    QPixmap pixmap(size, size);
    pixmap.fill(Qt::transparent);

    QPainter painter(&pixmap);
    painter.setRenderHint(QPainter::Antialiasing, true);
    const qreal s = size / 64.0;

    QLinearGradient gradient(0, 0, size, size);
    gradient.setColorAt(0.0, QColor(0x16, 0x8a, 0x5e));
    gradient.setColorAt(1.0, QColor(0x0a, 0x4d, 0x36));
    painter.setPen(Qt::NoPen);
    painter.setBrush(gradient);
    painter.drawRoundedRect(QRectF(0, 0, size, size), 14 * s, 14 * s);

    painter.setBrush(QColor(255, 255, 255));

    QPainterPath arrow;
    arrow.moveTo(32 * s, 9 * s);
    arrow.lineTo(43 * s, 24 * s);
    arrow.lineTo(36 * s, 24 * s);
    arrow.lineTo(36 * s, 32 * s);
    arrow.lineTo(28 * s, 32 * s);
    arrow.lineTo(28 * s, 24 * s);
    arrow.lineTo(21 * s, 24 * s);
    arrow.closeSubpath();
    painter.drawPath(arrow);

    QPainterPath card;
    card.moveTo(16 * s, 38 * s);
    card.lineTo(42 * s, 38 * s);
    card.lineTo(48 * s, 44 * s);
    card.lineTo(48 * s, 55 * s);
    card.lineTo(16 * s, 55 * s);
    card.closeSubpath();
    painter.drawPath(card);

    painter.setBrush(QColor(0x0a, 0x4d, 0x36));
    painter.drawRoundedRect(QRectF(21 * s, 43 * s, 8 * s, 8 * s), 1.5 * s, 1.5 * s);

    return pixmap;
}