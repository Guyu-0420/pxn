#pragma once

#include <QHash>
#include <QObject>
#include <QTcpServer>

class QTcpSocket;
class TaskManager;

class FlashApiServer : public QObject {
    Q_OBJECT
public:
    explicit FlashApiServer(TaskManager* tasks, QObject* parent = nullptr);

    bool listen(quint16 port);
    quint16 port() const;
    QString errorString() const;

private:
    void onNewConnection();
    void onReadyRead(QTcpSocket* socket);
    void handle(QTcpSocket* socket, const QByteArray& method, const QByteArray& path,
                const QByteArray& body);
    void reply(QTcpSocket* socket, int status, const QByteArray& body);

    TaskManager* m_tasks = nullptr;
    QTcpServer m_server;
    QHash<QTcpSocket*, QByteArray> m_buffers;
    QString m_error;
};
