#include "api/FlashApiServer.h"

#include "task/TaskManager.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTcpSocket>

namespace {

QJsonObject deviceJson(const DeviceInfo& device, bool flashable)
{
    QJsonObject obj;
    obj.insert(QStringLiteral("usbPath"), device.usbPath);
    obj.insert(QStringLiteral("chip"), device.chip);
    obj.insert(QStringLiteral("protocol"), device.protocol);
    obj.insert(QStringLiteral("vid"), device.vid);
    obj.insert(QStringLiteral("pid"), device.pid);
    obj.insert(QStringLiteral("flashable"), flashable);
    return obj;
}

QJsonObject taskJson(const TaskRecord& task)
{
    QJsonObject obj;
    obj.insert(QStringLiteral("id"), task.id);
    obj.insert(QStringLiteral("usbPath"), task.device.usbPath);
    obj.insert(QStringLiteral("chip"), task.device.chip);
    obj.insert(QStringLiteral("protocol"), task.device.protocol);
    obj.insert(QStringLiteral("board"), task.boardName);
    obj.insert(QStringLiteral("target"), task.target);
    obj.insert(QStringLiteral("state"), taskStateName(task.state));
    obj.insert(QStringLiteral("stage"), static_cast<int>(task.stage));
    obj.insert(QStringLiteral("percent"), task.percent);
    obj.insert(QStringLiteral("exitCode"), task.exitCode);
    obj.insert(QStringLiteral("errorCode"), flashErrorName(task.errorCode));
    obj.insert(QStringLiteral("message"), task.message);
    obj.insert(QStringLiteral("bootloader"), task.bootloaderPath);
    obj.insert(QStringLiteral("image"), task.linuxImagePath);
    return obj;
}

QByteArray jsonBytes(const QJsonObject& obj)
{
    return QJsonDocument(obj).toJson(QJsonDocument::Compact);
}

} // namespace

FlashApiServer::FlashApiServer(TaskManager* tasks, QObject* parent)
    : QObject(parent)
    , m_tasks(tasks)
{
    connect(&m_server, &QTcpServer::newConnection, this, &FlashApiServer::onNewConnection);
}

bool FlashApiServer::listen(quint16 port)
{
    if (m_server.listen(QHostAddress::LocalHost, port))
        return true;
    m_error = m_server.errorString();
    return false;
}

quint16 FlashApiServer::port() const
{
    return m_server.serverPort();
}

QString FlashApiServer::errorString() const
{
    return m_error;
}

void FlashApiServer::onNewConnection()
{
    while (QTcpSocket* socket = m_server.nextPendingConnection()) {
        connect(socket, &QTcpSocket::readyRead, this, [this, socket] { onReadyRead(socket); });
        connect(socket, &QTcpSocket::disconnected, this, [this, socket] {
            m_buffers.remove(socket);
            socket->deleteLater();
        });
    }
}

void FlashApiServer::onReadyRead(QTcpSocket* socket)
{
    m_buffers[socket] += socket->readAll();
    const QByteArray& buf = m_buffers[socket];
    const int headerEnd = buf.indexOf("\r\n\r\n");
    if (headerEnd < 0)
        return;
    const QByteArray head = buf.left(headerEnd);
    const int lineEnd = head.indexOf("\r\n");
    const QByteArray requestLine = lineEnd < 0 ? head : head.left(lineEnd);
    const QList<QByteArray> parts = requestLine.split(' ');
    if (parts.size() < 2) {
        reply(socket, 400, jsonBytes({{QStringLiteral("ok"), false},
                                      {QStringLiteral("error"), QStringLiteral("bad request")}}));
        return;
    }
    int length = 0;
    for (const QByteArray& line : head.mid(lineEnd + 2).split('\n')) {
        if (line.toLower().startsWith("content-length:"))
            length = line.mid(line.indexOf(':') + 1).trimmed().toInt();
    }
    if (buf.size() < headerEnd + 4 + length)
        return;
    const QByteArray body = buf.mid(headerEnd + 4, length);
    m_buffers.remove(socket);
    handle(socket, parts.at(0), parts.at(1), body);
}

void FlashApiServer::handle(QTcpSocket* socket, const QByteArray& method, const QByteArray& path,
                            const QByteArray& body)
{
    const QString route = QString::fromUtf8(path).section(QLatin1Char('?'), 0, 0);
    if (method == "GET" && route == QLatin1String("/v1/health")) {
        reply(socket, 200, jsonBytes({{QStringLiteral("ok"), true},
                                      {QStringLiteral("port"), port()}}));
        return;
    }
    if (method == "GET" && route == QLatin1String("/v1/devices")) {
        QJsonArray devices;
        for (const DeviceInfo& device : m_tasks->devices())
            devices.append(deviceJson(device, m_tasks->isFlashTarget(device)));
        QJsonObject obj;
        obj.insert(QStringLiteral("ok"), true);
        obj.insert(QStringLiteral("devices"), devices);
        reply(socket, 200, jsonBytes(obj));
        return;
    }
    if (method == "GET" && route == QLatin1String("/v1/tasks")) {
        QJsonArray tasks;
        for (const TaskRecord& task : m_tasks->history())
            tasks.append(taskJson(task));
        QJsonObject obj;
        obj.insert(QStringLiteral("ok"), true);
        obj.insert(QStringLiteral("tasks"), tasks);
        reply(socket, 200, jsonBytes(obj));
        return;
    }
    if (method == "GET" && route.startsWith(QLatin1String("/v1/tasks/"))) {
        const QString id = route.mid(QStringLiteral("/v1/tasks/").size());
        for (const TaskRecord& task : m_tasks->history()) {
            if (task.id == id) {
                QJsonObject obj = taskJson(task);
                obj.insert(QStringLiteral("ok"), true);
                reply(socket, 200, jsonBytes(obj));
                return;
            }
        }
        reply(socket, 404, jsonBytes({{QStringLiteral("ok"), false},
                                      {QStringLiteral("error"), QStringLiteral("task not found")}}));
        return;
    }
    if (method == "POST" && route == QLatin1String("/v1/detect")) {
        m_tasks->detect();
        reply(socket, 200, jsonBytes({{QStringLiteral("ok"), true}}));
        return;
    }
    if (method == "POST" && route == QLatin1String("/v1/cancel")) {
        const QJsonObject obj = QJsonDocument::fromJson(body).object();
        if (obj.value(QStringLiteral("all")).toBool() || obj.value(QStringLiteral("taskId")).toString().isEmpty())
            m_tasks->cancelAll();
        else
            m_tasks->cancel(obj.value(QStringLiteral("taskId")).toString());
        reply(socket, 200, jsonBytes({{QStringLiteral("ok"), true}}));
        return;
    }
    if (method == "POST" && route == QLatin1String("/v1/flash")) {
        const QJsonObject obj = QJsonDocument::fromJson(body).object();
        FlashRequest request;
        request.bootloaderPath = obj.value(QStringLiteral("bootloader")).toString();
        request.linuxImagePath = obj.value(QStringLiteral("image")).toString();
        request.media = obj.value(QStringLiteral("media")).toString(QStringLiteral("sd"));
        request.boardName = obj.value(QStringLiteral("board")).toString();
        request.scriptName = obj.value(QStringLiteral("script")).toString();
        request.scriptPath = obj.value(QStringLiteral("scriptPath")).toString();
        request.usbPath = obj.value(QStringLiteral("usbPath")).toString();
        const QStringList ids = m_tasks->submit(request);
        QJsonArray idArray;
        for (const QString& id : ids)
            idArray.append(id);
        QJsonObject out;
        out.insert(QStringLiteral("ok"), !ids.isEmpty());
        out.insert(QStringLiteral("taskIds"), idArray);
        if (ids.isEmpty())
            out.insert(QStringLiteral("error"), m_tasks->submitError());
        reply(socket, ids.isEmpty() ? 400 : 200, jsonBytes(out));
        return;
    }
    reply(socket, 404, jsonBytes({{QStringLiteral("ok"), false},
                                  {QStringLiteral("error"), QStringLiteral("not found")}}));
}

void FlashApiServer::reply(QTcpSocket* socket, int status, const QByteArray& body)
{
    const char* text = status == 200 ? "OK" : status == 404 ? "Not Found" : "Bad Request";
    const QByteArray head = QStringLiteral(
        "HTTP/1.1 %1 %2\r\n"
        "Content-Type: application/json; charset=utf-8\r\n"
        "Content-Length: %3\r\n"
        "Connection: close\r\n\r\n").arg(status).arg(QLatin1String(text)).arg(body.size()).toUtf8();
    socket->write(head);
    socket->write(body);
    socket->disconnectFromHost();
}
