#pragma once

#include <QObject>
#include <QMap>
#include <QString>
#include <QVector>

// 板型，对应 <chip>-config.cfg 的 [board]。
struct BoardProfile {
    QString id;
    QString name;
    QString bootloader;
};

// 每芯片配置，对应 <chip>-config.cfg。
struct ChipConfig {
    QString name;
    QString protocol;
    QString script;                       // 默认介质的 uuu 脚本（兼容旧用法，= scripts[mediaDefault]）
    QStringList media;                    // 本芯片可选的介质：sd/emmc/nand/qspi/spi_nand/nvme
    QString mediaDefault;                 // 默认介质
    QMap<QString, QString> scripts;       // 介质 → uuu 内置脚本（sd→sd_all 等）
    QString bootloaderFilter;
    QString linuxFilter;
    QString defaultBoardId;
    QVector<BoardProfile> boards;
    QString downloadPage;
    QString guidePage;
    bool valid = false;

    // 去重后的内置脚本名（取 [script] 的值，保持稳定顺序），供界面「脚本」下拉使用。
    QStringList scriptNames() const
    {
        QStringList out;
        for (auto it = scripts.constBegin(); it != scripts.constEnd(); ++it) {
            if (!out.contains(it.value()))
                out << it.value();
        }
        return out;
    }
};

// 程序与配置存放目录：exe 同目录，不可写时回落到用户数据目录。
QString appStorageDir();

// 全局 config.ini 与每芯片 <chip>-config.cfg 的读写。
class AppConfig : public QObject {
    Q_OBJECT
public:
    explicit AppConfig(QObject* parent = nullptr);

    void load();

    QString configDir() const;

    QString uuuPath() const;
    void setUuuPath(const QString& path);

    QString lastDir() const;
    void setLastDir(const QString& dir);

    QString bootloaderPath() const;
    void setBootloaderPath(const QString& path);

    QString linuxImagePath() const;
    void setLinuxImagePath(const QString& path);

    QString boardId() const;
    void setBoardId(const QString& id);

    QString mediaId() const;
    void setMediaId(const QString& id);

    QString logDir() const;
    QString dataDir() const;
    void setDataDir(const QString& dir);
    int timeoutSeconds() const;

    bool resetAfterFlash() const;
    bool verifyAfterFlash() const;
    QString language() const;
    bool advancedTab() const;
    void setAdvancedTab(bool on);

    bool apiEnabled() const;
    int apiPort() const;

    bool chipConfigValid() const;
    bool hasChip(const QString& chip) const;
    QString configError() const;

    ChipConfig chipConfig(const QString& chip) const;
    ChipConfig defaultChipConfig() const;

private:
    void loadGlobal();
    void saveGlobal();
    void loadChips();
    void writeDefaultChip();

    QString m_dir;
    QString m_uuuPath;
    QString m_lastDir;
    QString m_bootloaderPath;
    QString m_linuxImagePath;
    QString m_boardId;
    QString m_mediaId = QStringLiteral("sd");
    QString m_logDir = QStringLiteral("logs");
    QString m_dataDir;
    int m_timeoutSeconds = 30;
    bool m_resetAfterFlash = true;
    bool m_verifyAfterFlash = true;
    bool m_advancedTab = false;
    bool m_apiEnabled = true;
    int m_apiPort = 8765;
    QString m_language = QStringLiteral("zh_CN");
    QVector<ChipConfig> m_chips;
    bool m_chipConfigValid = false;
    QString m_configError;
};
