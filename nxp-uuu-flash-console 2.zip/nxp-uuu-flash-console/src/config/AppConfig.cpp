#include "config/AppConfig.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QSettings>
#include <QStandardPaths>

namespace {

const char* kGlobalFile = "config.ini";
const char* kDefaultChipFile = "imx95-config.cfg";

QString normalize(const QString& value)
{
    QString out;
    for (const QChar& ch : value) {
        if (ch.isLetterOrNumber())
            out.append(ch.toLower());
    }
    return out;
}

// 精确匹配优先。允许 IMX95 对上 MX95；拒绝 MX95 对上 MX952、MX8 对上 MX865。
bool chipNamesMatch(const QString& have, const QString& want)
{
    if (have.isEmpty() || want.isEmpty())
        return false;
    if (have == want)
        return true;
    const QString& longer = have.size() >= want.size() ? have : want;
    const QString& shorter = have.size() >= want.size() ? want : have;
    if (!longer.endsWith(shorter))
        return false;
    const QChar prev = longer.at(longer.size() - shorter.size() - 1);
    return !prev.isDigit();
}

// 一阶段支持的四块 i.MX 95 板，与官方镜像包里的 Bootloader 文件名一一对应。
QVector<BoardProfile> defaultBoards()
{
    QVector<BoardProfile> boards;
    const auto add = [&boards](const QString& id, const QString& name, const QString& bootloader) {
        BoardProfile board;
        board.id = id;
        board.name = name;
        board.bootloader = bootloader;
        boards.push_back(board);
    };
    add(QStringLiteral("frdm-imx95-pro"), QStringLiteral("FRDM i.MX 95 PRO（19x19，LPDDR5）"),
        QStringLiteral("imx-boot-imx95-19x19-lpddr5-frdm-pro-sd.bin-flash_a55"));
    add(QStringLiteral("evk-imx95-19x19"), QStringLiteral("i.MX 95 EVK（19x19，LPDDR5）"),
        QStringLiteral("imx-boot-imx95-19x19-lpddr5-evk-sd.bin-flash_a55"));
    add(QStringLiteral("frdm-imx95-15x15"), QStringLiteral("FRDM i.MX 95（15x15，LPDDR4X）"),
        QStringLiteral("imx-boot-imx95-15x15-lpddr4x-frdm-sd.bin-flash_a55"));
    add(QStringLiteral("evk-imx95-15x15"), QStringLiteral("i.MX 95 EVK（15x15，LPDDR4X）"),
        QStringLiteral("imx-boot-imx95-15x15-lpddr4x-evk-sd.bin-flash_a55"));
    return boards;
}

QString defaultDownloadPage()
{
    return QStringLiteral(
        "https://www.nxp.com/webapp/Download?colCode=LF_v6.18.37-2.1.0_MX95&appType=license");
}

QString defaultGuidePage()
{
    return QStringLiteral("https://www.nxp.com/document/guide/"
                          "getting-started-with-the-frdm-imx95-pro-evaluation-board:GS-FRDM-IMX95-PRO");
}

// 介质固定顺序，界面下拉与 cfg 都按这个顺序显示。
QStringList canonicalMedia()
{
    return {QStringLiteral("sd"), QStringLiteral("emmc"), QStringLiteral("nand"),
            QStringLiteral("qspi"), QStringLiteral("spi_nand"), QStringLiteral("nvme")};
}

// 介质 → uuu 内置脚本；未知介质按 <介质>_all 兜底。
QString defaultScriptForMedia(const QString& media)
{
    if (media == QLatin1String("sd")) return QStringLiteral("sd_all");
    if (media == QLatin1String("emmc")) return QStringLiteral("emmc_all");
    if (media == QLatin1String("nand")) return QStringLiteral("nand");
    if (media == QLatin1String("qspi")) return QStringLiteral("qspi");
    if (media == QLatin1String("spi_nand")) return QStringLiteral("spi_nand");
    if (media == QLatin1String("nvme")) return QStringLiteral("nvme_all");
    return media + QStringLiteral("_all");
}

} // namespace

QString appStorageDir()
{
    const QString appDir = QCoreApplication::applicationDirPath();
    if (QFileInfo(appDir).isWritable())
        return appDir;
    const QString fallback = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(fallback);
    return fallback;
}

AppConfig::AppConfig(QObject* parent)
    : QObject(parent)
    , m_dir(appStorageDir())
{
}

QString AppConfig::configDir() const
{
    return m_dir;
}

QString AppConfig::uuuPath() const { return m_uuuPath; }
QString AppConfig::lastDir() const { return m_lastDir; }
QString AppConfig::bootloaderPath() const { return m_bootloaderPath; }
QString AppConfig::linuxImagePath() const { return m_linuxImagePath; }
QString AppConfig::boardId() const { return m_boardId; }
QString AppConfig::mediaId() const { return m_mediaId; }
void AppConfig::setMediaId(const QString& id) { m_mediaId = id; saveGlobal(); }
QString AppConfig::logDir() const { return m_logDir; }
QString AppConfig::dataDir() const { return m_dataDir; }

void AppConfig::setDataDir(const QString& dir)
{
    m_dataDir = dir;
    saveGlobal();
}
int AppConfig::timeoutSeconds() const { return m_timeoutSeconds; }
bool AppConfig::resetAfterFlash() const { return m_resetAfterFlash; }
bool AppConfig::verifyAfterFlash() const { return m_verifyAfterFlash; }
QString AppConfig::language() const { return m_language; }
bool AppConfig::chipConfigValid() const { return m_chipConfigValid; }
bool AppConfig::apiEnabled() const { return m_apiEnabled; }
int AppConfig::apiPort() const { return m_apiPort; }

bool AppConfig::hasChip(const QString& chip) const
{
    const QString want = normalize(chip);
    if (want.isEmpty())
        return false;
    for (const ChipConfig& cfg : m_chips) {
        if (chipNamesMatch(normalize(cfg.name), want))
            return true;
    }
    return false;
}
QString AppConfig::configError() const { return m_configError; }

bool AppConfig::advancedTab() const { return m_advancedTab; }

void AppConfig::setAdvancedTab(bool on)
{
    m_advancedTab = on;
    saveGlobal();
}

void AppConfig::setUuuPath(const QString& path)
{
    m_uuuPath = path;
    saveGlobal();
}

void AppConfig::setLastDir(const QString& dir)
{
    m_lastDir = dir;
    saveGlobal();
}

void AppConfig::setBootloaderPath(const QString& path)
{
    m_bootloaderPath = path;
    saveGlobal();
}

void AppConfig::setLinuxImagePath(const QString& path)
{
    m_linuxImagePath = path;
    saveGlobal();
}

void AppConfig::setBoardId(const QString& id)
{
    m_boardId = id;
    saveGlobal();
}

void AppConfig::load()
{
    m_dir = appStorageDir();
    QDir().mkpath(m_dir);
    loadGlobal();
    loadChips();
}

void AppConfig::loadGlobal()
{
    const QString path = QDir(m_dir).filePath(QString::fromLatin1(kGlobalFile));
    const bool existed = QFileInfo::exists(path);
    QSettings settings(path, QSettings::IniFormat);
    m_language = settings.value(QStringLiteral("General/Language"), m_language).toString();
    m_uuuPath = settings.value(QStringLiteral("Tool/UUU_PATH"), m_uuuPath).toString();
    m_lastDir = settings.value(QStringLiteral("Tool/LastDir"), m_lastDir).toString();
    m_bootloaderPath = settings.value(QStringLiteral("Tool/Bootloader"), m_bootloaderPath).toString();
    m_linuxImagePath = settings.value(QStringLiteral("Tool/LinuxImage"), m_linuxImagePath).toString();
    m_boardId = settings.value(QStringLiteral("Tool/Board"), m_boardId).toString();
    m_mediaId = settings.value(QStringLiteral("Tool/Media"), m_mediaId).toString();
    m_resetAfterFlash = settings.value(QStringLiteral("Flash/ResetAfterFlash"), m_resetAfterFlash).toBool();
    m_verifyAfterFlash = settings.value(QStringLiteral("Flash/VerifyAfterFlash"), m_verifyAfterFlash).toBool();
    m_advancedTab = settings.value(QStringLiteral("Ui/AdvancedTab"), m_advancedTab).toBool();
    m_apiEnabled = settings.value(QStringLiteral("Api/Enabled"), m_apiEnabled).toBool();
    m_apiPort = settings.value(QStringLiteral("Api/Port"), m_apiPort).toInt();
    if (m_apiPort <= 0 || m_apiPort > 65535)
        m_apiPort = 8765;
    m_logDir = settings.value(QStringLiteral("Log/LogDir"), m_logDir).toString();
    if (m_logDir.isEmpty())
        m_logDir = QStringLiteral("logs");
    m_dataDir = settings.value(QStringLiteral("Data/Dir"), m_dataDir).toString();
    m_timeoutSeconds = settings.value(QStringLiteral("Device/TimeoutSeconds"), m_timeoutSeconds).toInt();
    if (m_timeoutSeconds <= 0)
        m_timeoutSeconds = 30;
    if (!existed)
        saveGlobal();
}

void AppConfig::saveGlobal()
{
    const QString path = QDir(m_dir).filePath(QString::fromLatin1(kGlobalFile));
    QSettings settings(path, QSettings::IniFormat);
    settings.setValue(QStringLiteral("General/Language"), m_language);
    settings.setValue(QStringLiteral("Tool/UUU_PATH"), m_uuuPath);
    settings.setValue(QStringLiteral("Tool/LastDir"), m_lastDir);
    settings.setValue(QStringLiteral("Tool/Bootloader"), m_bootloaderPath);
    settings.setValue(QStringLiteral("Tool/LinuxImage"), m_linuxImagePath);
    settings.setValue(QStringLiteral("Tool/Board"), m_boardId);
    settings.setValue(QStringLiteral("Tool/Media"), m_mediaId);
    settings.setValue(QStringLiteral("Flash/ResetAfterFlash"), m_resetAfterFlash);
    settings.setValue(QStringLiteral("Flash/VerifyAfterFlash"), m_verifyAfterFlash);
    settings.setValue(QStringLiteral("Ui/AdvancedTab"), m_advancedTab);
    settings.setValue(QStringLiteral("Api/Enabled"), m_apiEnabled);
    settings.setValue(QStringLiteral("Api/Port"), m_apiPort);
    settings.setValue(QStringLiteral("Log/LogDir"), m_logDir);
    settings.setValue(QStringLiteral("Data/Dir"), m_dataDir);
    settings.setValue(QStringLiteral("Device/TimeoutSeconds"), m_timeoutSeconds);
    settings.sync();
}

void AppConfig::writeDefaultChip()
{
    const QString path = QDir(m_dir).filePath(QString::fromLatin1(kDefaultChipFile));
    if (QFileInfo::exists(path))
        return;
    QSettings settings(path, QSettings::IniFormat);
    settings.setValue(QStringLiteral("chip/name"), QStringLiteral("MX95"));
    settings.setValue(QStringLiteral("chip/protocol"), QStringLiteral("SDPS"));
    for (const QString& media : canonicalMedia())
        settings.setValue(QStringLiteral("script/") + media, defaultScriptForMedia(media));
    settings.setValue(QStringLiteral("media/default"), QStringLiteral("sd"));
    settings.setValue(QStringLiteral("image/bootloader"), QStringLiteral("*.bin imx-boot*"));
    settings.setValue(QStringLiteral("image/linux"), QStringLiteral("*.wic *.wic.zst"));
    settings.setValue(QStringLiteral("download/page"), defaultDownloadPage());
    settings.setValue(QStringLiteral("download/guide"), defaultGuidePage());
    const QVector<BoardProfile> boards = defaultBoards();
    settings.setValue(QStringLiteral("board/default"), QStringLiteral("frdm-imx95-pro"));
    settings.setValue(QStringLiteral("board/count"), boards.size());
    for (int i = 0; i < boards.size(); ++i) {
        const QString prefix = QStringLiteral("board/b%1.").arg(i);
        settings.setValue(prefix + QStringLiteral("id"), boards.at(i).id);
        settings.setValue(prefix + QStringLiteral("name"), boards.at(i).name);
        settings.setValue(prefix + QStringLiteral("bootloader"), boards.at(i).bootloader);
    }
    settings.sync();
}

void AppConfig::loadChips()
{
    m_chips.clear();
    m_chipConfigValid = false;
    m_configError.clear();

    QDir dir(m_dir);
    if (dir.entryList({QStringLiteral("*-config.cfg")}, QDir::Files).isEmpty())
        writeDefaultChip();

    const QStringList files =
        dir.entryList({QStringLiteral("*-config.cfg")}, QDir::Files, QDir::Name);
    for (const QString& file : files) {
        QSettings settings(dir.filePath(file), QSettings::IniFormat);
        ChipConfig chip;
        chip.name = settings.value(QStringLiteral("chip/name")).toString();
        chip.protocol = settings.value(QStringLiteral("chip/protocol")).toString();
        settings.beginGroup(QStringLiteral("script"));
        const QStringList scriptKeys = settings.childKeys();
        for (const QString& key : scriptKeys)
            chip.scripts.insert(key.toLower(), settings.value(key).toString());
        settings.endGroup();
        if (chip.scripts.isEmpty())
            chip.scripts.insert(QStringLiteral("sd"), QStringLiteral("sd_all"));
        chip.mediaDefault = settings.value(QStringLiteral("media/default"),
                                          QStringLiteral("sd")).toString().toLower();
        if (!chip.scripts.contains(chip.mediaDefault))
            chip.mediaDefault = chip.scripts.firstKey();
        for (const QString& media : canonicalMedia()) {
            if (chip.scripts.contains(media))
                chip.media << media;
        }
        for (auto it = chip.scripts.constBegin(); it != chip.scripts.constEnd(); ++it) {
            if (!chip.media.contains(it.key()))
                chip.media << it.key();
        }
        chip.script = chip.scripts.value(chip.mediaDefault);
        chip.bootloaderFilter = settings.value(QStringLiteral("image/bootloader")).toString();
        chip.linuxFilter = settings.value(QStringLiteral("image/linux")).toString();
        chip.downloadPage = settings.value(QStringLiteral("download/page")).toString();
        chip.guidePage = settings.value(QStringLiteral("download/guide")).toString();
        chip.defaultBoardId = settings.value(QStringLiteral("board/default")).toString();
        const int boardCount = settings.value(QStringLiteral("board/count"), 0).toInt();
        for (int i = 0; i < boardCount; ++i) {
            const QString prefix = QStringLiteral("board/b%1.").arg(i);
            BoardProfile board;
            board.id = settings.value(prefix + QStringLiteral("id")).toString();
            board.name = settings.value(prefix + QStringLiteral("name")).toString();
            board.bootloader = settings.value(prefix + QStringLiteral("bootloader")).toString();
            // Bootloader 名字允许留空：官方包里的 imx-boot* 文件名随版本变化，
            // 留空时由「从官方 zip 提取」在解包后列出候选让操作员选。
            if (!board.id.isEmpty() && !board.name.isEmpty())
                chip.boards.push_back(board);
        }
        chip.valid = !chip.name.isEmpty() && !chip.protocol.isEmpty() && !chip.script.isEmpty();
        if (chip.valid)
            m_chips.push_back(chip);
        else
            m_configError = QStringLiteral("配置缺项：%1").arg(file);
    }
    m_chipConfigValid = !m_chips.isEmpty() && m_configError.isEmpty();
}

ChipConfig AppConfig::defaultChipConfig() const
{
    for (const ChipConfig& chip : m_chips) {
        if (chip.valid && normalize(chip.name).contains(QStringLiteral("mx95")))
            return chip;
    }
    if (!m_chips.isEmpty())
        return m_chips.first();
    ChipConfig fallback;
    fallback.name = QStringLiteral("MX95");
    fallback.protocol = QStringLiteral("SDPS");
    for (const QString& media : canonicalMedia())
        fallback.scripts.insert(media, defaultScriptForMedia(media));
    fallback.media = canonicalMedia();
    fallback.mediaDefault = QStringLiteral("sd");
    fallback.script = fallback.scripts.value(fallback.mediaDefault);
    fallback.bootloaderFilter = QStringLiteral("*.bin imx-boot*");
    fallback.linuxFilter = QStringLiteral("*.wic *.wic.zst");
    fallback.boards = defaultBoards();
    fallback.defaultBoardId = QStringLiteral("frdm-imx95-pro");
    fallback.downloadPage = defaultDownloadPage();
    fallback.guidePage = defaultGuidePage();
    fallback.valid = true;
    return fallback;
}

ChipConfig AppConfig::chipConfig(const QString& chip) const
{
    const QString want = normalize(chip);
    const ChipConfig* exact = nullptr;
    const ChipConfig* loose = nullptr;
    int looseLen = -1;
    if (!want.isEmpty()) {
        for (const ChipConfig& cfg : m_chips) {
            const QString have = normalize(cfg.name);
            if (have == want)
                exact = &cfg;
            else if (chipNamesMatch(have, want) && have.size() > looseLen) {
                loose = &cfg;
                looseLen = have.size();
            }
        }
    }
    if (exact)
        return *exact;
    if (loose)
        return *loose;
    return defaultChipConfig();
}
