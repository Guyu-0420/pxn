#include "config/FlashPreset.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>

namespace FlashPreset {

namespace {

const QString kAppName = QStringLiteral("nxp-uuu-flash-console");
const QString kTypeName = QStringLiteral("flash-config");

} // namespace

QString encode(const Data& data)
{
    QJsonObject object;
    object.insert(QStringLiteral("app"), kAppName);
    object.insert(QStringLiteral("type"), kTypeName);
    object.insert(QStringLiteral("version"), 1);
    object.insert(QStringLiteral("board"), data.boardId);
    object.insert(QStringLiteral("bootloader"), data.bootloaderPath);
    object.insert(QStringLiteral("linuxImage"), data.linuxImagePath);
    return QString::fromUtf8(QJsonDocument(object).toJson(QJsonDocument::Indented));
}

bool decode(const QString& text, Data* data, QString* error)
{
    QJsonParseError parseError;
    const QJsonDocument document = QJsonDocument::fromJson(text.toUtf8(), &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject()) {
        *error = QStringLiteral("文件不是有效的 JSON，可能已损坏。");
        return false;
    }

    const QJsonObject object = document.object();
    if (object.value(QStringLiteral("app")).toString() != kAppName
        || object.value(QStringLiteral("type")).toString() != kTypeName) {
        *error = QStringLiteral("这不是本程序导出的配置文件。");
        return false;
    }

    data->boardId = object.value(QStringLiteral("board")).toString();
    data->bootloaderPath = object.value(QStringLiteral("bootloader")).toString();
    data->linuxImagePath = object.value(QStringLiteral("linuxImage")).toString();
    if (data->boardId.isEmpty() && data->bootloaderPath.isEmpty()
        && data->linuxImagePath.isEmpty()) {
        *error = QStringLiteral("配置文件里没有板型和文件信息。");
        return false;
    }
    return true;
}

} // namespace FlashPreset