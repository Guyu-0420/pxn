#pragma once

#include <QString>

// 烧录配置（板型 + 两个文件路径）的导出与导入。
// 导出的文件可发给同事，对方导入后得到同样的板型和文件选择。
namespace FlashPreset {

struct Data {
    QString boardId;
    QString bootloaderPath;
    QString linuxImagePath;
};

// 序列化成 JSON 文本，带程序标记，导入时用来识别是不是本程序导出的文件。
QString encode(const Data& data);

// 解析 JSON 文本。不是本程序导出的配置文件时返回 false，error 是给用户看的原因。
bool decode(const QString& text, Data* data, QString* error);

} // namespace FlashPreset