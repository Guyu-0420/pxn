#include "gui/MainWindow.h"

#include <QApplication>
#include <QString>
#include <QVector>

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    QApplication::setOrganizationName(QStringLiteral("UUUFlashConsole"));
    QApplication::setApplicationName(QStringLiteral("UUUFlashConsole"));
    qRegisterMetaType<DeviceInfo>();
    qRegisterMetaType<TaskRecord>();
    qRegisterMetaType<FlashError>();
    qRegisterMetaType<QVector<DeviceInfo>>();

    bool headless = false;
    for (int i = 1; i < argc; ++i) {
        if (QString::fromLocal8Bit(argv[i]) == QLatin1String("--headless"))
            headless = true;
    }
    MainWindow window;
    if (!headless)
        window.show();
    return app.exec();
}