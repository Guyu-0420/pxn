#include "uuu/UUUAdapter.h"

#include "uuu/OutputParser.h"

#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QProcessEnvironment>
#include <QStandardPaths>
#include <QStringList>
#include <QTimer>

#if defined(Q_OS_UNIX)
#include <signal.h>
#include <unistd.h>
#endif

#if defined(Q_OS_WIN)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace {

QString toolFileName()
{
#if defined(Q_OS_WIN)
    return QStringLiteral("uuu.exe");
#else
    return QStringLiteral("uuu");
#endif
}

QString missingToolText()
{
#if defined(Q_OS_WIN)
    return QStringLiteral("未找到 uuu.exe");
#else
    return QStringLiteral("未找到 uuu");
#endif
}

} // namespace

UUUAdapter::UUUAdapter(QObject* parent)
    : QObject(parent)
    , m_proc(new QProcess(this))
    , m_stageTimer(new QTimer(this))
{
    m_proc->setProcessChannelMode(QProcess::MergedChannels);
#if defined(Q_OS_WIN)
    m_proc->setCreateProcessArgumentsModifier([](QProcess::CreateProcessArguments* args) {
        args->flags |= CREATE_NEW_PROCESS_GROUP;
    });
#endif
    m_stageTimer->setSingleShot(true);
    connect(m_proc, &QProcess::readyRead, this, &UUUAdapter::drain);
    connect(m_proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &UUUAdapter::onFinished);
    connect(m_proc, &QProcess::errorOccurred, this, &UUUAdapter::onError);
    connect(m_stageTimer, &QTimer::timeout, this, &UUUAdapter::onStageTimeout);
}

void UUUAdapter::setExecutable(const QString& path)
{
    m_override = path;
}

QString UUUAdapter::executable() const
{
    return resolveExecutable();
}

bool UUUAdapter::executableFound() const
{
    return !resolveExecutable().isEmpty();
}

void UUUAdapter::setTimeoutSeconds(int seconds)
{
    m_timeoutSeconds = seconds > 0 ? seconds : 30;
}

QString UUUAdapter::resolveExecutable() const
{
    if (!m_override.isEmpty())
        return QFileInfo::exists(m_override) ? QFileInfo(m_override).absoluteFilePath() : QString();

    const QString name = toolFileName();
    const QString local = QDir(QCoreApplication::applicationDirPath()).filePath(name);
    if (QFileInfo::exists(local))
        return local;

    const QString env = qEnvironmentVariable("UUU_PATH");
    if (!env.isEmpty() && QFileInfo::exists(env))
        return QFileInfo(env).absoluteFilePath();

#if !defined(Q_OS_WIN)
    if (QFileInfo::exists(QStringLiteral("/usr/bin/uuu")))
        return QStringLiteral("/usr/bin/uuu");
#endif
    return QStandardPaths::findExecutable(name);
}

void UUUAdapter::listDevices()
{
    if (isRunning())
        return;
    const QString exe = resolveExecutable();
    if (exe.isEmpty()) {
        emit devicesReady({}, missingToolText());
        return;
    }
    ++m_runId;
    m_mode = Mode::List;
    m_buffer.clear();
    m_listText.clear();
    m_cancel = false;
    m_proc->setProgram(exe);
    m_proc->setArguments({QStringLiteral("-lsusb")});
    m_proc->setWorkingDirectory(QDir::tempPath());
    m_proc->start();
}

// 读分区表：跑 uuu -b <脚本>，脚本里 FB: ucmd mmc dev / mmc part，输出交给 parseMmcParts 解析。
void UUUAdapter::listPartitions(const QString& scriptPath)
{
    if (isRunning())
        return;
    const QString exe = resolveExecutable();
    if (exe.isEmpty()) {
        emit partitionsReady({}, missingToolText());
        return;
    }
    ++m_runId;
    m_mode = Mode::ListParts;
    m_buffer.clear();
    m_listText.clear();
    m_cancel = false;
    m_proc->setProgram(exe);
    m_proc->setArguments({QStringLiteral("-t"), QString::number(m_timeoutSeconds),
                          QStringLiteral("-b"), scriptPath});
    m_proc->setWorkingDirectory(QDir::tempPath());
    m_proc->start();
}

void UUUAdapter::start(const DeviceInfo& device, const FlashRequest& request)
{
    if (isRunning())
        return;
    const QString exe = resolveExecutable();
    if (exe.isEmpty()) {
        emit output(missingToolText());
        emit finished(-1, false, FlashError::ToolMissing);
        return;
    }
    ++m_runId;
    m_mode = Mode::Flash;
    m_buffer.clear();
    m_cancel = false;
    m_timedOut = false;
    m_successEvidence = false;
    m_failureEvidence = false;
    m_permissionEvidence = false;
    m_verifyEvidence = false;
    m_stage = TaskStage::WaitDevice;
    m_failureStage = TaskStage::WaitDevice;

    const QString script = request.scriptName.isEmpty() ? QStringLiteral("sd_all") : request.scriptName;
    QStringList args;
    if (!device.usbPath.isEmpty())
        args << QStringLiteral("-m") << device.usbPath;
    if (m_timeoutSeconds > 0) {
        args << QStringLiteral("-t") << QString::number(m_timeoutSeconds)
             << QStringLiteral("-T") << QString::number(m_timeoutSeconds);
    }
    args << QStringLiteral("-b") << script
         << request.bootloaderPath;
    // NAND/QSPI/SPI NAND 只烧 Bootloader，镜像参数可省。
    if (!request.linuxImagePath.isEmpty())
        args << request.linuxImagePath;

    m_proc->setProgram(exe);
    m_proc->setArguments(args);
    // NAND/QSPI/SPI NAND 只烧 Bootloader，没有镜像文件，工作目录退回 Bootloader 所在目录。
    const QString workDir = request.linuxImagePath.isEmpty()
        ? QFileInfo(request.bootloaderPath).absolutePath()
        : QFileInfo(request.linuxImagePath).absolutePath();
    m_proc->setWorkingDirectory(workDir);
    m_proc->start();
}

void UUUAdapter::runUtility(const QStringList& args, const QString& workingDir)
{
    if (isRunning())
        return;
    const QString exe = resolveExecutable();
    if (exe.isEmpty()) {
        emit output(missingToolText());
        emit utilityFinished(-1, false, missingToolText());
        return;
    }
    ++m_runId;
    m_mode = Mode::Utility;
    m_buffer.clear();
    m_cancel = false;
    m_timedOut = false;
    m_utilityError.clear();
    m_utilityLast.clear();
    m_proc->setProgram(exe);
    m_proc->setArguments(args);
    m_proc->setWorkingDirectory(workingDir.isEmpty() ? QDir::tempPath() : workingDir);
    m_proc->start();
}

void UUUAdapter::cancel()
{
    if (!isRunning() || m_mode != Mode::Flash)
        return;
    m_cancel = true;
    m_stageTimer->stop();
    const int runId = m_runId;
    const qint64 pid = m_proc->processId();
#if defined(Q_OS_WIN)
    bool sent = false;
    if (pid > 0 && AttachConsole(static_cast<DWORD>(pid))) {
        SetConsoleCtrlHandler(nullptr, TRUE);
        sent = GenerateConsoleCtrlEvent(CTRL_BREAK_EVENT, static_cast<DWORD>(pid));
        FreeConsole();
    }
    if (!sent)
        m_proc->terminate();
#elif defined(Q_OS_UNIX)
    if (pid > 0)
        ::kill(static_cast<pid_t>(pid), SIGINT);
    else
        m_proc->terminate();
#else
    m_proc->terminate();
#endif
    QTimer::singleShot(2000, this, [this, runId] {
        if (runId == m_runId && isRunning())
            m_proc->kill();
    });
}

bool UUUAdapter::isRunning() const
{
    return m_proc->state() != QProcess::NotRunning;
}

void UUUAdapter::drain()
{
    m_buffer += QString::fromLocal8Bit(m_proc->readAll());
    m_buffer.replace(QStringLiteral("\r\n"), QStringLiteral("\n"));
    m_buffer.replace(QLatin1Char('\r'), QLatin1Char('\n'));
    int pos = 0;
    while ((pos = m_buffer.indexOf(QLatin1Char('\n'))) >= 0) {
        const QString line = m_buffer.left(pos).trimmed();
        m_buffer.remove(0, pos + 1);
        if (!line.isEmpty())
            handleLine(line);
    }
}

void UUUAdapter::handleLine(const QString& line)
{
    if (m_mode == Mode::List) {
        m_listText += line;
        m_listText += QLatin1Char('\n');
        return;
    }
    if (m_mode == Mode::ListParts) {
        m_listText += line;
        m_listText += QLatin1Char('\n');
        emit output(line);
        return;
    }
    if (m_mode == Mode::Utility) {
        emit output(line);
        if (line.startsWith(QStringLiteral("Error:"), Qt::CaseInsensitive))
            m_utilityError = line;
        m_utilityLast = line;
        return;
    }
    if (m_mode != Mode::Flash)
        return;

    emit output(line);
    const LineEffect effect = OutputParser::parseLine(line);
    if (effect.permissionEvidence)
        m_permissionEvidence = true;
    if (effect.verifyEvidence)
        m_verifyEvidence = true;
    if (effect.failureEvidence) {
        if (!m_failureEvidence)
            m_failureStage = m_stage;
        m_failureEvidence = true;
    }
    if (effect.successEvidence)
        m_successEvidence = true;
    if (!effect.matched)
        return;
    const int percent = effect.hasPercent ? effect.percent : OutputParser::stageStartPercent(effect.stage);
    setStage(effect.stage, percent);
}

void UUUAdapter::setStage(TaskStage stage, int percent)
{
    const bool changed = stage != m_stage;
    m_stage = stage;
    if (stage == TaskStage::WaitFastboot) {
        if (changed && m_timeoutSeconds > 0)
            m_stageTimer->start(m_timeoutSeconds * 1000);
    } else {
        m_stageTimer->stop();
    }
    emit stageChanged(stage, percent);
}

void UUUAdapter::onStageTimeout()
{
    if (!isRunning() || m_mode != Mode::Flash || m_stage != TaskStage::WaitFastboot)
        return;
    m_timedOut = true;
    emit output(QStringLiteral("等待 Fastboot 超时"));
    m_proc->kill();
}

FlashError UUUAdapter::classifyFailure() const
{
    if (m_permissionEvidence)
        return FlashError::PermissionDenied;
    if (m_verifyEvidence)
        return FlashError::VerifyFailed;
    const TaskStage stage = m_failureEvidence ? m_failureStage : m_stage;
    switch (stage) {
    case TaskStage::WaitFastboot:
        return FlashError::WaitFastbootTimeout;
    case TaskStage::FlashImage:
    case TaskStage::Finish:
        return FlashError::FlashImageFailed;
    case TaskStage::LoadBootloader:
    case TaskStage::WaitDevice:
    default:
        return FlashError::LoadBootloaderFailed;
    }
}

void UUUAdapter::onFinished(int exitCode, QProcess::ExitStatus status)
{
    drain();
    if (!m_buffer.trimmed().isEmpty()) {
        handleLine(m_buffer.trimmed());
        m_buffer.clear();
    }
    m_stageTimer->stop();

    const Mode mode = m_mode;
    const bool cancelled = m_cancel;
    const bool timedOut = m_timedOut;
    const bool successEvidence = m_successEvidence;
    const bool failureEvidence = m_failureEvidence;
    m_mode = Mode::Idle;
    m_cancel = false;
    m_timedOut = false;

    if (mode == Mode::List) {
        const QVector<DeviceInfo> devices = OutputParser::parseLsusb(m_listText);
        m_listText.clear();
        QString error;
        if ((status != QProcess::NormalExit || exitCode != 0) && devices.isEmpty())
            error = QStringLiteral("检测失败");
        emit devicesReady(devices, error);
        return;
    }
    if (mode == Mode::ListParts) {
        const QVector<FatPartition> partitions = OutputParser::parseMmcParts(m_listText);
        m_listText.clear();
        QString error;
        if ((status != QProcess::NormalExit || exitCode != 0) && partitions.isEmpty())
            error = QStringLiteral("读取分区失败");
        emit partitionsReady(partitions, error);
        return;
    }
    if (mode == Mode::Utility) {
        const bool ok = !cancelled && status == QProcess::NormalExit && exitCode == 0
            && m_utilityError.isEmpty();
        const QString message = ok ? m_utilityLast : m_utilityError;
        m_utilityError.clear();
        m_utilityLast.clear();
        emit utilityFinished(exitCode, ok, message);
        return;
    }
    if (mode == Mode::Flash) {
        if (cancelled) {
            emit finished(exitCode, false, FlashError::Cancelled);
            return;
        }
        if (timedOut) {
            emit finished(exitCode, false, FlashError::WaitFastbootTimeout);
            return;
        }
        const bool ok = status == QProcess::NormalExit && exitCode == 0
            && successEvidence && !failureEvidence;
        emit finished(exitCode, ok, ok ? FlashError::None : classifyFailure());
    }
}

void UUUAdapter::onError(QProcess::ProcessError error)
{
    if (error != QProcess::FailedToStart || m_mode == Mode::Idle)
        return;
    const Mode mode = m_mode;
    m_mode = Mode::Idle;
    m_stageTimer->stop();
    if (mode == Mode::List) {
        m_listText.clear();
        emit devicesReady({}, QStringLiteral("无法启动 uuu"));
        return;
    }
    if (mode == Mode::ListParts) {
        m_listText.clear();
        emit partitionsReady({}, QStringLiteral("无法启动 uuu"));
        return;
    }
    if (mode == Mode::Utility) {
        emit utilityFinished(-1, false, QStringLiteral("无法启动 uuu"));
        return;
    }
    emit output(QStringLiteral("无法启动 uuu"));
    const FlashError code = m_cancel ? FlashError::Cancelled : FlashError::PermissionDenied;
    emit finished(-1, false, code);
}
