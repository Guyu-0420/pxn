#include "uuu/OutputParser.h"

#include <QRegularExpression>

namespace {

QStringList columns(const QString& line)
{
    return line.trimmed().split(QRegularExpression(QStringLiteral("\\s+")), Qt::SkipEmptyParts);
}

int columnIndex(const QStringList& header, const QString& name, int fallback)
{
    const int index = header.indexOf(name);
    return index >= 0 ? index : fallback;
}

// DOS 分区类型码 → 是否 FAT（01/04/06/0b/0c/0e 及隐藏变体）。
bool isFatType(const QString& type)
{
    if (type.isEmpty())
        return false;
    QString key = type.toLower();
    if (key.startsWith(QStringLiteral("0x")))
        key = key.mid(2);
    if (key.size() == 1)
        key.prepend(QLatin1Char(48));
    static const QStringList kFat = {
        QStringLiteral("01"), QStringLiteral("04"), QStringLiteral("06"),
        QStringLiteral("0b"), QStringLiteral("0c"), QStringLiteral("0e"),
        QStringLiteral("11"), QStringLiteral("14"), QStringLiteral("16"),
        QStringLiteral("1b"), QStringLiteral("1c"), QStringLiteral("1e")
    };
    return kFat.contains(key);
}

} // namespace

QVector<DeviceInfo> OutputParser::parseLsusb(const QString& text)
{
    int pathCol = 0;
    int chipCol = 1;
    int proCol = 2;
    int vidCol = 3;
    int pidCol = 4;
    bool headerFound = false;
    QVector<DeviceInfo> devices;
    const QRegularExpression pathRe(QStringLiteral("^\\d+:\\d+$"));
    const QStringList lines = text.split(QRegularExpression(QStringLiteral("[\\r\\n]+")), Qt::SkipEmptyParts);

    for (const QString& rawLine : lines) {
        const QString line = rawLine.trimmed();
        if (line.isEmpty() || line.startsWith(QLatin1Char('=')))
            continue;
        const QStringList cols = columns(line);
        if (cols.isEmpty())
            continue;

        if (!headerFound) {
            QStringList lower;
            lower.reserve(cols.size());
            for (const QString& col : cols)
                lower << col.toLower();
            if (lower.contains(QStringLiteral("path")) && lower.contains(QStringLiteral("chip"))
                && lower.contains(QStringLiteral("pro"))) {
                pathCol = columnIndex(lower, QStringLiteral("path"), 0);
                chipCol = columnIndex(lower, QStringLiteral("chip"), 1);
                proCol = columnIndex(lower, QStringLiteral("pro"), 2);
                vidCol = columnIndex(lower, QStringLiteral("vid"), 3);
                pidCol = columnIndex(lower, QStringLiteral("pid"), 4);
                headerFound = true;
                continue;
            }
        }

        const int need = qMax(pathCol, qMax(chipCol, qMax(proCol, qMax(vidCol, pidCol))));
        if (cols.size() <= need || !pathRe.match(cols.at(pathCol)).hasMatch())
            continue;
        if (!cols.at(chipCol).at(0).isLetter())
            continue;

        DeviceInfo device;
        device.usbPath = cols.at(pathCol);
        // 芯片列为空时（例如 Fastboot 模式），空列被跳过，chip 位置实际是协议，vid/pid 前移一位。
        if (cols.at(chipCol).endsWith(QLatin1Char(':')) && cols.size() > pidCol - 1) {
            device.protocol = cols.at(chipCol);
            device.vid = cols.at(vidCol - 1);
            device.pid = cols.at(pidCol - 1);
        } else {
            device.chip = cols.at(chipCol);
            device.protocol = cols.at(proCol);
            device.vid = cols.at(vidCol);
            device.pid = cols.at(pidCol);
        }
        if (device.protocol.endsWith(QLatin1Char(':')))
            device.protocol.chop(1);
        device.raw = line;
        devices.push_back(device);
    }
    return devices;
}

// 解析 u-boot mmc part 输出：先记住 "Partition Map for MMC device N"，再按表头区分 DOS / GPT。
// DOS 表有 Type 列（十六进制类型码）；GPT 表只有 Name 列，类型未知 → fat 判 false，由界面回退列出全部。
QVector<FatPartition> OutputParser::parseMmcParts(const QString& text)
{
    QVector<FatPartition> parts;
    int device = -1;
    int headerKind = 0; // 0 未知，1 DOS（有 Type 列），2 GPT（有 Name 列）
    const QRegularExpression deviceRe(
        QStringLiteral("Partition Map for MMC device\\s+(\\d+)"),
        QRegularExpression::CaseInsensitiveOption);
    const QStringList lines = text.split(QRegularExpression(QStringLiteral("[\\r\\n]+")));

    for (const QString& rawLine : lines) {
        const QString line = rawLine.trimmed();
        if (line.isEmpty())
            continue;

        const QRegularExpressionMatch devMatch = deviceRe.match(line);
        if (devMatch.hasMatch()) {
            device = devMatch.captured(1).toInt();
            headerKind = 0;
            continue;
        }

        const QStringList cols = columns(line);
        if (cols.isEmpty())
            continue;

        // 表头行：DOS 表有 Type 列，GPT 表有 Name 列。
        if (cols.first().compare(QStringLiteral("Part"), Qt::CaseInsensitive) == 0) {
            headerKind = 0;
            for (const QString& col : cols) {
                if (col.compare(QStringLiteral("Type"), Qt::CaseInsensitive) == 0)
                    headerKind = 1;
                else if (col.compare(QStringLiteral("Name"), Qt::CaseInsensitive) == 0)
                    headerKind = 2;
            }
            continue;
        }

        bool ok = false;
        const int number = cols.first().toInt(&ok);
        if (!ok || number <= 0)
            continue;

        FatPartition part;
        part.device = device;
        part.number = number;
        if (headerKind == 2) {
            // GPT：没有类型码，最后一列是分区名（可能带引号）。
            QString name = cols.last();
            name.remove(QLatin1Char(34));
            part.name = name;
        } else {
            // DOS：第 5 列是类型码（十六进制），第 6 列可能是 Boot 标志。
            if (cols.size() > 4)
                part.type = cols.at(4).toLower();
            if (cols.size() > 5)
                part.name = cols.at(5);
        }
        part.fat = isFatType(part.type);
        parts.push_back(part);
    }
    return parts;
}

QVector<FatPartition> OutputParser::fatPartitions(const QVector<FatPartition>& all)
{
    QVector<FatPartition> fat;
    for (const FatPartition& part : all) {
        if (part.fat)
            fat.push_back(part);
    }
    return fat;
}

LineEffect OutputParser::parseLine(const QString& line)
{
    LineEffect effect;
    const QString text = line.trimmed();
    if (text.isEmpty())
        return effect;

    static const QRegularExpression permissionRe(
        QStringLiteral("access is denied|access denied|permission denied|not permitted|libusb_open|libusb_error_access|insufficient permission"),
        QRegularExpression::CaseInsensitiveOption);
    if (permissionRe.match(text).hasMatch())
        effect.permissionEvidence = true;

    static const QRegularExpression verifyRe(
        QStringLiteral("verify failed|verification failed|hash mismatch|sha\\w* mismatch|check image failed"),
        QRegularExpression::CaseInsensitiveOption);
    if (verifyRe.match(text).hasMatch())
        effect.verifyEvidence = true;

    static const QRegularExpression summary(
        QStringLiteral("Success\\s+(\\d+)\\s+Failure\\s+(\\d+)"),
        QRegularExpression::CaseInsensitiveOption);
    const QRegularExpressionMatch sum = summary.match(text);
    if (sum.hasMatch()) {
        const int successCount = sum.captured(1).toInt();
        const int failureCount = sum.captured(2).toInt();
        if (failureCount == 0 && successCount >= 1) {
            effect.matched = true;
            effect.successEvidence = true;
            effect.stage = TaskStage::Finish;
            effect.hasPercent = true;
            effect.percent = 100;
        } else if (failureCount > 0) {
            effect.failureEvidence = true;
        }
        return effect;
    }

    static const QRegularExpression percentRe(QStringLiteral("(?:^|\\s)(\\d{1,3})\\s*%=>"));
    const QRegularExpressionMatch percent = percentRe.match(text);
    if (percent.hasMatch()) {
        effect.hasPercent = true;
        effect.percent = qBound(0, percent.captured(1).toInt(), 100);
    }

    const bool fb = text.contains(QStringLiteral("FB:"), Qt::CaseInsensitive);
    const bool sdp = text.contains(QStringLiteral("SDPS:"), Qt::CaseInsensitive)
        || text.contains(QStringLiteral("SDPV:"), Qt::CaseInsensitive)
        || text.contains(QRegularExpression(QStringLiteral("\\bSDP:"), QRegularExpression::CaseInsensitiveOption));

    if (fb && text.contains(QRegularExpression(QStringLiteral("\\bdone\\b"), QRegularExpression::CaseInsensitiveOption))) {
        effect.matched = true;
        effect.successEvidence = true;
        effect.stage = TaskStage::Finish;
        effect.hasPercent = true;
        effect.percent = 100;
        return effect;
    }
    if (fb && text.contains(QStringLiteral("flash"), Qt::CaseInsensitive)) {
        effect.matched = true;
        effect.stage = TaskStage::FlashImage;
        return effect;
    }
    if (sdp) {
        effect.matched = true;
        effect.stage = TaskStage::LoadBootloader;
        return effect;
    }
    if (!fb && text.contains(QStringLiteral("wait"), Qt::CaseInsensitive)) {
        effect.matched = true;
        effect.stage = TaskStage::WaitFastboot;
        return effect;
    }
    return effect;
}

int OutputParser::stageStartPercent(TaskStage stage)
{
    switch (stage) {
    case TaskStage::LoadBootloader: return 0;
    case TaskStage::WaitFastboot: return 30;
    case TaskStage::FlashImage: return 45;
    case TaskStage::Finish: return 100;
    case TaskStage::WaitDevice: return 0;
    }
    return 0;
}
