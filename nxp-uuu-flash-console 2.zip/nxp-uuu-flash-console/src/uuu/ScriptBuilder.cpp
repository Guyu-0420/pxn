#include "uuu/ScriptBuilder.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QStringList>
#include <QTextStream>

namespace ScriptBuilder {

namespace {

// 一期只放开 sd_all（与现有 -b sd_all 行为零差异）；其余未真机验证，
// enabled=false → 界面置灰、build() 拒绝生成。真机验证一个、放开一个。
const FeatureItem kFeatures[] = {
    {QStringLiteral("sd_all"),   QStringLiteral("烧录整盘系统到 SD 卡"),
     QStringLiteral("下载 Bootloader 并启动，然后把整盘 .wic 镜像写入 SD 卡，烧完可直接从 SD 启动。"),
     true,  false, true},
    {QStringLiteral("emmc_all"), QStringLiteral("烧录整盘系统到 eMMC"),
     QStringLiteral("下载 Bootloader 并启动，然后把整盘 .wic 镜像写入板载 eMMC。"),
     true,  false, false},
    {QStringLiteral("sd"),       QStringLiteral("只写 Bootloader 到 SD 卡"),
     QStringLiteral("仅把 Bootloader 写入 SD 卡，不写整盘镜像。用于调试或先验证启动链。"),
     false, false, false},
    {QStringLiteral("fat_write"),QStringLiteral("传输文件到板子 FAT 分区"),
     QStringLiteral("把指定文件写入已启动系统的 FAT 分区根目录，用于调试传文件（要求板子已烧过系统并进入 Fastboot）。"),
     false, true,  false},
    {QStringLiteral("spl"),      QStringLiteral("启动 SPL + U-Boot（调试）"),
     QStringLiteral("只下载并启动 U-Boot，不写存储；用于调试启动过程。"),
     false, false, false},
};

// 各内置脚本模板 = 锁定版本 uuu(1.5.243) 的 `uuu -bshow <name>` 真实输出。
// 模板**保留占位符**：_flash.bin / _image 由 uuu 的 -b 位置参数替换（真机验证）。
// 首行必须是 uuu_version（真机验证：否则 uuu 不认脚本）。
const char* kTemplate(const QString& media)
{
    if (media == QLatin1String("sd_all"))
        return R"__(uuu_version 1.4.149
# 功能项 = 烧录整盘系统到 SD 卡
SDPS: boot -scanterm -f _flash.bin -scanlimited 0x800000
SDP: boot -f _flash.bin -scanlimited 0x800000
SDPU: delay 1000
SDPU: write -f _flash.bin -offset 0x57c00 -scanlimited 0x800000
SDPU: jump -scanlimited 0x800000
SDPV: delay 1000
SDPV: write -f _flash.bin -skipspl -scanterm -scanlimited 0x800000
SDPV: jump -scanlimited 0x800000
FB: ucmd setenv fastboot_dev mmc
FB: ucmd setenv mmcdev ${sd_dev}
FB: ucmd mmc dev ${sd_dev}
FB: flash -raw2sparse all _image
FB: flash -scanterm -scanlimited 0x800000 bootloader _flash.bin
FB: done
)__";
    if (media == QLatin1String("emmc_all"))
        return R"__(uuu_version 1.4.149
# 功能项 = 烧录整盘系统到 eMMC
SDPS: boot -scanterm -f _flash.bin -scanlimited 0x800000
SDP: boot -f _flash.bin -scanlimited 0x800000
SDPU: delay 1000
SDPU: write -f _flash.bin -offset 0x57c00 -scanlimited 0x800000
SDPU: jump -scanlimited 0x800000
SDPV: delay 1000
SDPV: write -f _flash.bin -skipspl -scanterm -scanlimited 0x800000
SDPV: jump -scanlimited 0x800000
FB: ucmd setenv fastboot_dev mmc
FB: ucmd setenv mmcdev ${emmc_dev}
FB: ucmd mmc dev ${emmc_dev}
FB: flash -raw2sparse all _image
FB: flash -scanterm -scanlimited 0x800000 bootloader _flash.bin
FB: ucmd if env exists emmc_ack; then ; else setenv emmc_ack 0; fi;
FB: ucmd mmc partconf ${emmc_dev} ${emmc_ack} 1 0
FB: done
)__";
    if (media == QLatin1String("sd"))
        return R"__(uuu_version 1.2.39
# 功能项 = 只写 Bootloader 到 SD 卡
SDPS: boot -f _flash.bin
SDP: boot -f _flash.bin
SDPU: delay 1000
SDPU: write -f _flash.bin -offset 0x57c00
SDPU: jump
SDPV: delay 1000
SDPV: write -f _flash.bin -skipspl
SDPV: jump
FB: ucmd setenv fastboot_dev mmc
FB: ucmd setenv mmcdev ${sd_dev}
FB: ucmd mmc dev ${sd_dev}
FB: flash bootloader _image
FB: Done
)__";
    if (media == QLatin1String("fat_write"))
        return R"__(uuu_version 1.1.4
# 功能项 = 传输文件到板子 FAT 分区
FB: ucmd setenv fastboot_buffer ${loadaddr}
FB: download -f _image
FB: ucmd if test ! -n "$fastboot_bytes"; then setenv fastboot_bytes $filesize; else true; fi
FB[-t 20000]: ucmd fatwrite _device _partition ${fastboot_buffer} _filename  ${fastboot_bytes}
FB: done
)__";
    if (media == QLatin1String("spl"))
        return R"__(uuu_version 1.2.39
# 功能项 = 启动 SPL + U-Boot（调试）
SDPS[-t 10000]: boot -f _flash.bin
SDP: boot -f _flash.bin
SDPU: delay 1000
SDPU: write -f _flash.bin -offset 0x57c00
SDPU: jump
SDPU: done
SDPV: delay 1000
SDPV: write -f _flash.bin -skipspl
SDPV: jump
SDPV: done
)__";
    return nullptr;
}

// 需要 Bootloader 的功能项
bool needsBootloader(const QString& media)
{
    return media == QLatin1String("sd_all") || media == QLatin1String("emmc_all")
        || media == QLatin1String("sd") || media == QLatin1String("spl");
}

} // namespace

bool BuildOptions::build(BuildResult* result, QString* error) const
{
    // 双保险：界面已置灰，这里再挡一次，防止参数被外部直接构造。
    if (!isMediaEnabled(media)) {
        if (error) *error = QString("该功能项尚未启用（待真机验证）：") + media;
        return false;
    }
    const char* tpl = kTemplate(media);
    if (tpl == nullptr) {
        if (error) *error = QString("暂不支持的功能项：") + media;
        return false;
    }

    BuildResult r;
    r.scriptText = QString::fromUtf8(tpl);
    r.fileName = media + QStringLiteral(".auto");

    // 文件存在性校验（路径作为参数传给 uuu，含空格无妨）。
    if (needsBootloader(media)) {
        if (bootloaderPath.isEmpty() || !QFileInfo::exists(bootloaderPath)) {
            if (error) *error = QStringLiteral("缺少有效的 Bootloader 文件。");
            return false;
        }
        r.arguments << QFileInfo(bootloaderPath).absoluteFilePath(); // arg0 → _flash.bin
    }
    if (media == QLatin1String("sd_all") || media == QLatin1String("emmc_all")) {
        if (linuxImagePath.isEmpty() || !QFileInfo::exists(linuxImagePath)) {
            if (error) *error = QStringLiteral("缺少有效的整盘镜像（.wic）文件。");
            return false;
        }
        r.arguments << QFileInfo(linuxImagePath).absoluteFilePath(); // arg1 → _image
    }
    if (media == QLatin1String("sd")) {
        // sd 模板的 _image 复用 bootloader 路径（arg0 已是 bootloader，再补一份）
        r.arguments << QFileInfo(bootloaderPath).absoluteFilePath();
    }
    if (media == QLatin1String("fat_write")) {
        if (extraFilePath.isEmpty() || !QFileInfo::exists(extraFilePath)) {
            if (error) *error = QStringLiteral("缺少要传输的文件。");
            return false;
        }
        // fat_write 的占位符 _device/_partition/_filename 不是文件路径，
        // 无法用 -b 位置参数替换（uuu 只替换 _flash.bin/_image），
        // 故此项需在脚本内直接写死这三个值。
        r.scriptText.replace(QStringLiteral("_device"), QStringLiteral("mmc"));
        r.scriptText.replace(QStringLiteral("_partition"),
                             targetDir.isEmpty() ? QStringLiteral("1") : targetDir);
        r.scriptText.replace(QStringLiteral("_filename"),
                             QFileInfo(extraFilePath).fileName());
        r.arguments << QFileInfo(extraFilePath).absoluteFilePath(); // → _image
    }

    if (result) *result = r;
    return true;
}

QString BuildOptions::buildAndSave(const QString& diskDir, BuildResult* result, QString* error) const
{
    BuildResult r;
    QString buildError;
    if (!build(&r, &buildError)) {
        if (error) *error = buildError;
        return QString();
    }
    QDir dir(diskDir);
    if (!dir.exists() && !dir.mkpath(QStringLiteral("."))) {
        if (error) *error = QStringLiteral("无法创建脚本目录：") + diskDir;
        return QString();
    }
    const QString fullPath = dir.absoluteFilePath(r.fileName);
    QFile file(fullPath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        if (error) *error = QStringLiteral("无法写入脚本文件：") + fullPath;
        return QString();
    }
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Encoding::Utf8);
    // 首行必须是 uuu_version（真机验证）；可追溯头放它之后。
    const int versionEol = r.scriptText.indexOf(QChar('\n'));
    if (versionEol < 0) {
        if (error) *error = QStringLiteral("脚本缺少 uuu_version 首行。");
        return QString();
    }
    out << r.scriptText.left(versionEol + 1);
    out << QStringLiteral("# generated_by = nxp-uuu-flash-console\n");
    out << QString("# generated_at = ") + QDateTime::currentDateTime().toString(Qt::ISODate) + "\n";
    out << r.scriptText.mid(versionEol + 1);
    file.close();

    if (result) *result = r;
    return fullPath;
}

const FeatureItem* features(int* count)
{
    if (count) *count = int(sizeof(kFeatures) / sizeof(kFeatures[0]));
    return kFeatures;
}

bool isMediaEnabled(const QString& media)
{
    int count = 0;
    const FeatureItem* items = features(&count);
    for (int i = 0; i < count; ++i) {
        if (items[i].media == media)
            return items[i].enabled;
    }
    return false; // 未知项视为未启用
}

} // namespace ScriptBuilder
