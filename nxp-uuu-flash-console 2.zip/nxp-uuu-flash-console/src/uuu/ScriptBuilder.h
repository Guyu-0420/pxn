#pragma once

#include <QString>
#include <QStringList>

// 把"用户选择的功能项 + 文件路径"编译成一次 uuu 调用。
//
// 真机验证(1.5.243)确定的调用方式：
//   uuu -b <脚本文件> <arg0> <arg1> ...
//   uuu 把 arg0 替换脚本里的 _flash.bin、arg1 替换 _image（占位符替换由 uuu 自己做）。
//   ⚠️ 路径作为参数传入时含空格也没问题（uuu 自动加引号）；
//      但路径若写死在脚本里，含空格会报 "image file not found"。
//   → 因此本模块**不把路径写进脚本**：脚本保留占位符，路径走参数。
//
// 其它真机约束：
//  - 脚本首行必须是 uuu_version，否则 uuu 不认脚本、会把文件当 bootloader 下载。
//  - uuu 版本锁定时模板不漂移；升级 uuu 需同步核对模板。
namespace ScriptBuilder {

// 功能项清单（供界面渲染可选项，文案面向工人，不出现脚本语法）。
struct FeatureItem {
    QString media;      // 传给 BuildOptions.media
    QString name;       // 界面显示名
    QString description;// 一句话功能说明
    bool needsImage;    // 是否要求整盘镜像（.wic）
    bool needsFile;     // 是否要求"待传输文件 + 目标分区"
    bool enabled;       // false = 未真机验证，界面置灰、build() 拒绝
};

// 一次生成的产物：脚本全文（保留占位符）+ 传给 uuu 的位置参数。
struct BuildResult {
    QString scriptText;     // 脚本全文，保留 _flash.bin / _image 等占位符
    QStringList arguments;  // uuu 位置参数，顺序对应占位符
    QString fileName;       // 建议落盘文件名（如 sd_all.auto）
};

struct BuildOptions {
    QString bootloaderPath;   // imx-boot / flash.bin
    QString linuxImagePath;   // .wic 整盘镜像；fat_write 时为空
    QString extraFilePath;    // fat_write 的源文件；其他功能项为空
    QString targetDir;        // fat_write 的目标 FAT 分区号（如 "1"）
    QString media = QStringLiteral("sd_all");

    // 生成脚本 + 参数。不支持/未启用/文件缺失时返回 false 并填 error。
    bool build(BuildResult* result, QString* error) const;

    // 生成并写入 diskDir/<fileName>，返回文件绝对路径（失败返回空）。
    // 成功后 result 填好 scriptText/arguments，调用方用
    //   uuu -b <返回的路径> <result.arguments...>
    // 执行。
    QString buildAndSave(const QString& diskDir, BuildResult* result, QString* error) const;
};

// 某功能项当前是否启用（build() 与界面共用此判定，双保险）。
bool isMediaEnabled(const QString& media);

const FeatureItem* features(int* count);  // 静态数组，只读

} // namespace ScriptBuilder
