#pragma once

#include "task/TaskRecord.h"

#include <QObject>
#include <QProcess>
#include <QString>
#include <QStringList>

class QTimer;

class UUUAdapter : public QObject {
    Q_OBJECT
public:
    explicit UUUAdapter(QObject* parent = nullptr);

    void setExecutable(const QString& path);
    QString executable() const;
    bool executableFound() const;
    void setTimeoutSeconds(int seconds);

    void listDevices();
    void listPartitions(const QString& scriptPath);
    void start(const DeviceInfo& device, const FlashRequest& request);
    void runUtility(const QStringList& args, const QString& workingDir);
    void cancel();
    bool isRunning() const;

signals:
    void devicesReady(QVector<DeviceInfo> devices, QString error);
    void partitionsReady(QVector<FatPartition> partitions, QString error);
    void output(QString line);
    void stageChanged(TaskStage stage, int percent);
    void finished(int exitCode, bool success, FlashError error);
    void utilityFinished(int exitCode, bool success, QString message);

private:
    enum class Mode { Idle, List, ListParts, Flash, Utility };

    QString resolveExecutable() const;
    void drain();
    void handleLine(const QString& line);
    void setStage(TaskStage stage, int percent);
    void onStageTimeout();
    void onFinished(int exitCode, QProcess::ExitStatus status);
    void onError(QProcess::ProcessError error);
    FlashError classifyFailure() const;

    QString m_override;
    QProcess* m_proc = nullptr;
    QTimer* m_stageTimer = nullptr;
    Mode m_mode = Mode::Idle;
    QString m_buffer;
    QString m_listText;
    int m_timeoutSeconds = 30;
    bool m_cancel = false;
    bool m_timedOut = false;
    bool m_successEvidence = false;
    bool m_failureEvidence = false;
    bool m_permissionEvidence = false;
    bool m_verifyEvidence = false;
    QString m_utilityError;
    QString m_utilityLast;
    TaskStage m_stage = TaskStage::WaitDevice;
    TaskStage m_failureStage = TaskStage::WaitDevice;
    int m_runId = 0;
};
